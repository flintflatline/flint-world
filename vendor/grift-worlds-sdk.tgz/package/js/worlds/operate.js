// A WORLD'S OPERATOR, FROM ANYWHERE (docs/world-deployer.md): the checks an operator reads and the requests and transactions an operator
// makes, for the CLI (tools/worldnew.mjs) and the frontend (js/worlds/studio). It holds no key and no chain client of its own: it runs in
// a browser as it does on a server, and everything it reports it reads from the chain at the block it says.
//   worldStatus({ pub, index, id | worldId, commits })    what the chain says about a world, with what is wrong and what comes next
//   operatorMessage(world, action, args, { now, nonce })  the text of an operator's signed request (api/_worlds.js operator)
//   operatorTypedData(world, msg)                         what the owner signs for it
//   ADMIN                                                 every on-chain act an owner has, as { address, abi, functionName, args }
import * as viem from 'viem';
import * as P from './protocol.js';

export const NETWORKS = Object.freeze({
  31337: { name: 'Local sandbox', mainnet: false, deploy: true, explorer: null },
  46630: { name: 'Robinhood Chain testnet', mainnet: false, deploy: true, explorer: 'https://explorer.testnet.chain.robinhood.com', rpc: P.RPC_FOR[46630] },
  // MAINNET IS READ-ONLY HERE. Its index is closed to the listers its owner names, and a listing burns the fee; nothing in this
  // deployer sends a mainnet transaction (docs/worlds-mainnet.md is the only route, each step approved by hand)
  4663: { name: 'Robinhood Chain mainnet', mainnet: true, deploy: false, explorer: 'https://robinhoodchain.blockscout.com', rpc: P.RPC_FOR[4663] },
});
export const deployProblem = (chainId) => (!NETWORKS[chainId] ? `chain ${chainId} is not a network this deployer knows` : NETWORKS[chainId].deploy ? null : `${NETWORKS[chainId].name} is read-only here: this deployer sends no transaction there`);

export const COMMITS_ABI = viem.parseAbi([
  'function owner() view returns (address)', 'function pendingOwner() view returns (address)',
  'function streamOf(uint256 streamId) view returns (string name, uint32 cadence, address committer, uint256 latestEpoch, uint64 commitCount)',
  'function addStream(uint256 streamId, string name, uint32 cadence, address committer)', 'function setCommitter(uint256 streamId, address committer)',
  'function proposeOwner(address next)', 'function acceptOwner()',
]);
export const REGISTRY_ABI = viem.parseAbi([
  'function owner() view returns (address)', 'function pendingOwner() view returns (address)',
  'function activeKey(bytes32 role) view returns (address)', 'function pendingKey(bytes32 role) view returns (address key, uint256 effectiveAt)',
  'function proposeKey(bytes32 role, address key)', 'function activateKey(bytes32 role)', 'function cancelProposal(bytes32 role)', 'function revokeKey(bytes32 role)',
  'function proposeOwner(address next)', 'function acceptOwner()',
]);
export const INDEX_ABI = viem.parseAbi([
  'function worldOf(bytes32 worldId) view returns ((address lister, uint8 status, uint32 listings, uint64 listedAt, address commits, uint64 statusAt, address keyRegistry, uint64 checkedAt, bytes32 feeBurnTx, bytes32 evidenceHash, string manifestURI))', 'function worldCount() view returns (uint256)', 'function worldIds(uint256 start, uint256 count) view returns (bytes32[])',
  'function owner() view returns (address)', 'function listingOpen() view returns (bool)', 'function listerAllowed(address) view returns (bool)',
  'function list(bytes32 worldId, string manifestURI, address commits, address keyRegistry, bytes32 feeBurnTx)', 'function setManifest(bytes32 worldId, string manifestURI)', 'function claimLister(bytes32 worldId)',
  // what a refused listing says, by name, so a person can act on it
  'error DailyCapReached(uint256 day, uint256 cap)', 'error ListerNotAllowed(address account)', 'error AlreadyListed(bytes32 worldId)', 'error NotContractOwner(address target, address account)', 'error CodeNotAllowed(address target, bytes32 codehash)', 'error CommitsInUse(address commits, bytes32 worldId)', 'error BurnUsed(bytes32 feeBurnTx, bytes32 worldId)', 'error NotLister(bytes32 worldId)', 'error GenesisMarkerRequired(bytes32 worldId, bytes32 marker)', 'error NotGenesisLister(bytes32 worldId, address account)',
]);
export const STATUS = Object.freeze(['NONE', 'LISTED', 'STALE', 'DISPUTED', 'DELISTED']);
export const SIGNER_ROLE = viem.keccak256(viem.toBytes(P.ROLE_NAME));
export const worldIdOf = (id) => viem.keccak256(viem.toBytes(String(id)));
const ZERO = '0x0000000000000000000000000000000000000000';
const isZero = (a) => !a || a === ZERO;
const same = (a, b) => { try { return viem.getAddress(a) === viem.getAddress(b); } catch { return false; } };

export async function worldStatus({ pub, index = null, id = null, worldId = null, commits = null, keyRegistry = null, nowMs = Date.now() }) {
  const wid = worldId || (id ? worldIdOf(id) : null);
  const read = (address, abi, functionName, args = []) => pub.readContract({ address, abi, functionName, args });
  const block = await pub.getBlockNumber();
  const out = { asOfBlock: Number(block), chainId: await pub.getChainId(), id, worldId: wid, listing: null, commits: commits || null, keyRegistry: keyRegistry || null, owner: null, pendingOwner: null, registryOwner: null, signer: { active: null, pending: null }, streams: {}, problems: [], next: [] };
  if (index && wid) {
    const e = await read(index, INDEX_ABI, 'worldOf', [wid]);
    if (!isZero(e.commits) && Number(e.status) !== 0) {
      out.listing = { lister: viem.getAddress(e.lister), manifestURI: e.manifestURI, status: STATUS[Number(e.status)] ?? String(e.status), listedAt: Number(e.listedAt), feeBurnTx: e.feeBurnTx };
      out.commits = out.commits || viem.getAddress(e.commits);
      out.keyRegistry = out.keyRegistry || viem.getAddress(e.keyRegistry);
    }
  }
  if (!out.commits) { out.problems.push('this world has no contract yet'); out.next.push('deploy its contracts'); return out; }
  out.owner = viem.getAddress(await read(out.commits, COMMITS_ABI, 'owner'));
  const pend = await read(out.commits, COMMITS_ABI, 'pendingOwner');
  out.pendingOwner = isZero(pend) ? null : viem.getAddress(pend);
  for (const [sid, name] of Object.entries(P.STREAM_NAMES)) {
    try {
      const [, cadence, committer, latestEpoch, commitCount] = await read(out.commits, COMMITS_ABI, 'streamOf', [BigInt(sid)]);
      const epochNow = Math.floor(nowMs / 1000 / Number(cadence));
      const behind = Number(commitCount) ? epochNow - Number(latestEpoch) : null;
      out.streams[name] = { id: Number(sid), cadence: Number(cadence), committer: viem.getAddress(committer), latestEpoch: Number(latestEpoch), commits: Number(commitCount), behind, fresh: behind != null && behind <= 2 };
    } catch { out.problems.push(`stream ${sid} (${name}) is not on the contract`); }
  }
  if (out.keyRegistry) {
    out.registryOwner = viem.getAddress(await read(out.keyRegistry, REGISTRY_ABI, 'owner'));
    const active = await read(out.keyRegistry, REGISTRY_ABI, 'activeKey', [SIGNER_ROLE]);
    const [pk, at] = await read(out.keyRegistry, REGISTRY_ABI, 'pendingKey', [SIGNER_ROLE]);
    out.signer = { active: isZero(active) ? null : viem.getAddress(active), pending: isZero(pk) ? null : { key: viem.getAddress(pk), effectiveAt: Number(at) } };
    if (!out.signer.active) out.problems.push(out.signer.pending ? `its signer is proposed, effective at ${new Date(out.signer.pending.effectiveAt * 1000).toISOString()}: it signs nothing until it is activated` : 'its registry has no active signer');
    if (!same(out.registryOwner, out.owner)) out.problems.push(`its contracts have two owners: commits ${out.owner}, registry ${out.registryOwner}`);
  } else out.problems.push('it has no key registry');
  if (out.listing) {
    if (out.listing.status === 'DISPUTED' || out.listing.status === 'DELISTED') out.problems.push(`the index says ${out.listing.status}`);
    if (!same(out.listing.lister, out.owner)) out.next.push(`the lister is ${out.listing.lister}, the owner ${out.owner}: the owner claims the listing with claimLister`);
  } else if (index) out.next.push('list it on the index');
  const records = out.streams.records;
  if (records && !records.commits) out.next.push('run the world: nothing has been posted yet');
  else if (records && !records.fresh) out.problems.push(`its records are ${records.behind} periods behind: nothing is posting`);
  if (out.pendingOwner) out.next.push(`${out.pendingOwner} has been offered ownership and has not accepted`);
  return out;
}

// contract: this world's CityCommitsV2. It binds the owner's act to this deployment, so a signature for one world cannot be used on another with the same id
export const operatorMessage = (world, action, args = {}, { now = Date.now(), nonce, contract }) => JSON.stringify({ v: 1, op: 'operator', world, contract, action, args, ts: now, nonce });
export const operatorTypedData = (world, msg) => P.requestTypedData(world, msg);

// EVERY ON-CHAIN ACT AN OWNER HAS. Each returns what a wallet sends; none of them runs anything
export const ADMIN = Object.freeze({
  setCommitter: (commits, committer) => [P.STREAM.records, P.STREAM.decisions, P.STREAM.manifest].map((s) => ({ address: commits, abi: COMMITS_ABI, functionName: 'setCommitter', args: [BigInt(s), committer], label: `stream ${s}: a new committer` })),
  proposeSigner: (keyRegistry, key) => [{ address: keyRegistry, abi: REGISTRY_ABI, functionName: 'proposeKey', args: [SIGNER_ROLE, key], label: 'propose a new signer (it waits the registry\'s 7 days)' }],
  activateSigner: (keyRegistry) => [{ address: keyRegistry, abi: REGISTRY_ABI, functionName: 'activateKey', args: [SIGNER_ROLE], label: 'activate the proposed signer' }],
  cancelSigner: (keyRegistry) => [{ address: keyRegistry, abi: REGISTRY_ABI, functionName: 'cancelProposal', args: [SIGNER_ROLE], label: 'cancel the proposed signer' }],
  revokeSigner: (keyRegistry) => [{ address: keyRegistry, abi: REGISTRY_ABI, functionName: 'revokeKey', args: [SIGNER_ROLE], label: 'revoke the active signer: the world signs nothing until another is active' }],
  setManifest: (index, worldId, uri) => [{ address: index, abi: INDEX_ABI, functionName: 'setManifest', args: [worldId, uri], label: 'point the index at a new manifest URL' }],
  offerOwnership: (commits, keyRegistry, next) => [{ address: commits, abi: COMMITS_ABI, functionName: 'proposeOwner', args: [next], label: 'offer the commits contract' }, { address: keyRegistry, abi: REGISTRY_ABI, functionName: 'proposeOwner', args: [next], label: 'offer the key registry' }],
  acceptOwnership: (commits, keyRegistry) => [{ address: commits, abi: COMMITS_ABI, functionName: 'acceptOwner', args: [], label: 'accept the commits contract' }, { address: keyRegistry, abi: REGISTRY_ABI, functionName: 'acceptOwner', args: [], label: 'accept the key registry' }],
  claimLister: (index, worldId) => [{ address: index, abi: INDEX_ABI, functionName: 'claimLister', args: [worldId], label: 'take the listing' }],
});
