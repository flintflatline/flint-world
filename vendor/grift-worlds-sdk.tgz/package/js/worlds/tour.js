// AN AGENT'S TOUR, AND THE CLIENT IT USES (docs/world-deployer.md). What any agent does to use a world of this protocol, in a few lines and
// with nothing but a key, a URL and fetch: it runs in a browser as it does on a server, so the frontend's "try it" and `worldnew try`
// are the same code. Every step is the protocol's own: a signed Join, signed Requests, a departure cited from the world's own record.
import * as viem from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import * as P from './protocol.js';
import { verifyItem, citeOf } from './verifier.js';

const rnd = () => viem.toHex(globalThis.crypto.getRandomValues(new Uint8Array(32)));
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

// worlds: { [id]: base URL }, each world's manifest there is read once, for its name and chain (its EIP-712 domain) and its API path
export function agentClient({ key = generatePrivateKey(), agentId, worlds, signTypedData = null, address = null, fetchImpl = (...a) => globalThis.fetch(...a) }) {
  const acct = key ? privateKeyToAccount(key) : null;
  const sign = signTypedData || ((td) => acct.signTypedData(td));
  const seen = new Map();
  const call = async (url, opts) => { const r = await fetchImpl(url, opts); const body = await r.json().catch(() => ({})); return { code: r.status, ...body }; };
  const post = (url, body) => call(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
  const domain = async (id) => {
    if (seen.has(id)) return seen.get(id);
    const base = worlds[id];
    const m = (await call(`${base}/.well-known/world.json`)).manifest;
    if (!m) throw new Error(`no manifest at ${base}/.well-known/world.json`);
    const origin = new URL(base).origin;
    const w = { id, name: m.name, chainId: m.chain, commits: m.commits?.address, api: `${origin}${m.api}`, manifest: m };
    seen.set(id, w);
    return w;
  };
  const self = {
    agentId: String(agentId), address: address || acct?.address, domain,
    async join(id, name, from = null) {
      const w = await domain(id);
      const j = { agentId: self.agentId, world: id, name, challenge: rnd(), ts: Date.now() };
      return post(`${w.api}/join`, { join: j, sig: await sign(P.joinTypedData(w, j)), ...(from ? { from } : {}) });
    },
    async act(id, op, extra = {}) {
      const w = await domain(id);
      const msg = JSON.stringify({ v: 1, op, world: id, agentId: self.agentId, ts: Date.now(), nonce: rnd(), ...extra });
      return post(`${w.api}/${op}`, { msg, sig: await sign(P.requestTypedData(w, msg)) });
    },
    leave: (id) => self.act(id, 'leave'),
    async record(id) { const w = await domain(id); return call(`${w.api}/record?agentId=${self.agentId}`); },
    async read(id, op) { const w = await domain(id); return call(`${w.api}/${op}`); },
    // an item this agent sealed there, once its period is sealed and posted: { item, cite }, or null when time runs out
    async citeWhenPosted(id, match, { timeoutMs = 180_000, pollMs = 2_000, onWait = null } = {}) {
      const until = Date.now() + timeoutMs;
      for (;;) {
        const rec = await self.record(id);
        const item = (rec.items || []).filter(match).at(-1);
        const cite = item ? citeOf(id, item) : null;
        if (cite) { const w = await domain(id); return { item, cite: { ...cite, contract: item.verify.contract ?? w.manifest?.commits?.address } }; }
        if (Date.now() > until) return null;
        onWait?.();
        await sleep(pollMs);
      }
    },
  };
  return self;
}

// THE TOUR: out of `home`, into `target`, doing what `target` permits, and back, every crossing cited and every item re-checked by the
// independent verifier, which reads only the chain. invite(agentId): for a world that admits by invitation, its operator's act.
export async function runTour({ urls, home, target, agentId, pub, index, identity = null, setAgent = null, invite = null, key = generatePrivateKey(), timeoutMs = 180_000, log = () => {} }) {
  const a = agentClient({ key, agentId, worlds: urls });
  const steps = [];
  const step = (ok, what, detail = null) => { steps.push({ ok: !!ok, what, ...(detail ? { detail } : {}) }); log(`  ${ok ? '✓' : '✗'} ${what}${detail && !ok ? ` — ${String(detail).slice(0, 200)}` : ''}`); return !!ok; };
  if (setAgent) await setAgent(agentId, a.address);
  const verified = [];
  const check = async (cite, related = []) => {
    const v = await verifyItem({ pub, index, cite, related, identity });
    verified.push(v);
    step(v.ok, `verified from the chain alone: ${v.kind} in ${v.world}: ${v.facts.length} facts, ${v.claims.length} of the world's own claims, ${v.unverified.length} not checked`, v.ok ? null : v.checks.filter((c) => !c.ok).map((c) => c.statement).join('; '));
    return v;
  };
  try {
    const j0 = await a.join(home, 'Tourist');
    if (!step(j0.code === 201 || j0.code === 200, `joined ${home}`, JSON.stringify(j0).slice(0, 240))) return { ok: false, steps, verified };
    const l0 = await a.leave(home);
    if (!step(l0.code === 200, `left ${home}`, JSON.stringify(l0).slice(0, 240))) return { ok: false, steps, verified };
    log(`  waiting for ${home} to seal and post its period…`);
    const dep = await a.citeWhenPosted(home, (i) => i.kind === 'departed' && i.verify?.leaf === l0.item.leaf, { timeoutMs });
    if (!step(dep, `${home} posted the departure`)) return { ok: false, steps, verified };
    await check(dep.cite);

    const t = await a.domain(target);
    const mode = t.manifest.rules?.door || '';
    if (/invitation/.test(mode) && invite) { await invite(agentId); step(true, `${target}'s operator invited this agent`); }
    const j1 = await a.join(target, 'Tourist', dep.cite);
    if (!step(j1.code === 201 || j1.code === 200, `joined ${target}, citing the departure from ${home}`, JSON.stringify(j1).slice(0, 240))) return { ok: false, steps, verified };
    const ops = (t.manifest.ops || []).map((o) => o.op);
    if (ops.includes('note')) { const r = await a.act(target, 'note', { line: 'a tourist passed through' }); step(r.code === 200, `left a note in ${target}: the agent's say, sealed as a claim`, JSON.stringify(r).slice(0, 200)); }
    const about = ops.includes('about') ? await a.read(target, 'about') : null;
    for (const task of about?.tasks || []) {
      // the tour holds a departure from home: a task wanting anything else is left undone, and said so, never counted as done
      const canProve = task.proof !== 'foreign-item' || (task.kinds.includes('departed') && (!task.fromWorlds?.length || task.fromWorlds.includes(home)));
      if (!canProve) { log(`  • task ${task.id} in ${target}: left undone, because this tour holds no such item`); continue; }
      const r = await a.act(target, 'task', { taskId: task.id, ...(task.proof === 'foreign-item' ? { result: dep.cite } : {}) });
      step(r.code === 200, `task ${task.id} in ${target}: ${r.code === 200 ? `${r.proof}, weight ${r.weight}` : `refused (${String(r.reason).slice(0, 80)})`}`);
    }
    if (ops.includes('claim')) { const r = await a.act(target, 'claim', {}); step(r.code === 200 || /NOT_EARNED/.test(r.reason), r.code === 200 ? `earned ${r.credential.id} in ${target}, weight ${r.credential.weight}` : `no credential earned in ${target}: ${String(r.reason).slice(0, 80)}`); }
    const l1 = await a.leave(target);
    if (!step(l1.code === 200, `left ${target}`, JSON.stringify(l1).slice(0, 240))) return { ok: false, steps, verified };
    log(`  waiting for ${target} to seal and post its period…`);
    const dep1 = await a.citeWhenPosted(target, (i) => i.kind === 'departed' && i.verify?.leaf === l1.item.leaf, { timeoutMs });
    if (!step(dep1, `${target} posted the departure`)) return { ok: false, steps, verified };
    const arrival = await a.citeWhenPosted(target, (i) => i.kind === 'arrived' || i.kind === 'returned', { timeoutMs: 1000 });
    if (arrival) await check(arrival.cite, [dep.cite]);
    await check(dep1.cite);

    const back = await a.join(home, 'Tourist', dep1.cite);
    step(back.code === 200, `came back to ${home}, citing the departure from ${target}`, JSON.stringify(back).slice(0, 240));
    return { ok: steps.every((s) => s.ok) && verified.every((v) => v.ok), steps, verified, agent: { agentId: a.agentId, address: a.address } };
  } catch (e) { step(false, 'the tour stopped', String(e?.shortMessage || e?.message || e)); return { ok: false, steps, verified }; }
}
