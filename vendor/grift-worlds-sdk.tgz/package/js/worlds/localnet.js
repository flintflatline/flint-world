// A LOCAL NETWORK OF WORLDS (docs/worlds-sdk.md): one anvil chain, the index, and every world on it, each on its own
// contract and keys, served over HTTP and found through the index. What the end-to-end journey and the conformance runs
// stand on; nothing here touches a public chain (the deployer refuses any chain but 31337).
//
//   const net = await startLocalNet({ worlds: [definitions…], port, anvilPort })
//   net.urls[id]                 each world's base URL (its manifest at <url>/.well-known/world.json)
//   net.discover()               the index read and every world checked (js/worlds/discovery.js)
//   net.engines[id]              each world's engine (for the operator's door, e.g. posting jobs)
//   net.chain, net.c, net.core   the chain adapter, the deployer's clients, the index and identity addresses
//   net.stop()
// San Verano and ONE STREET run as the built-in worlds; San Verano on a city of its own in memory, WORLDS_ENABLED on
// for its engine only. Routes beyond the worlds': /index/worlds (discovery), /_local/agent (set an agent on the
// stand-in registry), /_local/down (make a world answer 503).
import * as viem from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import * as P from './protocol.js';
import { viemChain } from './chain.js';
import { worldEngine, WORLD_IDS, SIGNER_ROLE_OF } from '../../api/_worlds.js';
import { MemoryStore } from '../econ/store.js';
import { serveWorlds } from './serve.js';
import { startAnvil, deployCore, deployWorld, activateAfterDelay, devKey, artifact, LOCAL_CHAIN } from './deployer.js';
import { discover, learnKnown } from './discovery.js';

// registryMode: 'all' (every world signs as its registry's active key: San Verano under X402_RESPONSE_SIGNER, the others
// under RESPONSE_SIGNER) or 'sanverano' (only San Verano; the others pin their manifests in stream 16)
// release: the manifest release the BUILT-IN worlds serve here (kit worlds start at 0.2.0); the code's RELEASE is unchanged.
// Each world is operated by a lister key of its own (anvil's dev accounts 5, 6, 7, …): it owns its contracts and is its
// listing's lister, so no world's operator can act for another's (WorldJobs.offer, say, asks for the world's lister).
// builtIns false: ONLY the worlds given, with no San Verano, no ONE STREET and none of the city's code loaded. Each world's first key
// is then active at once (WorldKeyRegistry, as on mainnet), so nothing moves the chain's clock. net.addWorld adds one later.
export async function startLocalNet({ worlds = [], builtIns = true, port = 8790, anvilPort = 8550, cronMs = 5_000, log = () => {}, city = null, jobsOnChain = null, extra = null, registryMode = 'all', release = '0.2.0' } = {}) {
  const c = await startAnvil({ port: anvilPort });
  const stops = [c.stop];
  try {
    const core = await deployCore(c);
    const origin = `http://127.0.0.1:${port}`;
    const keys = { worlds: {} }, commits = {}, deployed = {};
    const firstIds = builtIns ? WORLD_IDS : [];
    const bases = { ...(builtIns ? { sanverano: '', onestreet: '/onestreet' } : {}), ...Object.fromEntries(worlds.map((d) => [d.id, d.base])) };
    // each world: its contract, its registry, its committer's gas, its listing, with keys of its own
    const listers = {};
    for (const [i, id] of [...firstIds, ...worlds.map((d) => d.id)].entries()) {
      listers[id] = devKey(5 + i);
      // WorldIndex lists at most listingsPerDay worlds a UTC day (decision 13): past it, the next listing waits for the next
      // day, which on anvil means moving its clock there (said in the log, as everything this harness does to the chain)
      const nowSec = Number((await c.pub.getBlock({ blockTag: 'latest' })).timestamp), day = BigInt(Math.floor(nowSec / 86400));
      const [cap, today] = await Promise.all([c.read(core.index, core.abis.index, 'listingsPerDay'), c.read(core.index, core.abis.index, 'listingsOn', [day])]);
      if (cap > 0n && today >= cap) { log(`  WorldIndex's daily cap (${cap}) is reached: ${id}'s listing waits for the next UTC day (anvil's clock moved)`); await c.warp((Number(day) + 1) * 86400 - nowSec + 60); }
      const d = await deployWorld(c, { id, cadence: worlds.find((x) => x.id === id)?.cadence ?? undefined, lister: listers[id], index: core.index, manifestURI: `${origin}${bases[id]}/.well-known/world.json`, streams: id === 'sanverano' ? [[1, 'records'], [2, 'decisions']] : undefined, role: id === 'sanverano' ? SIGNER_ROLE_OF.sanverano : undefined, immediateKey: !builtIns });
      deployed[id] = d; commits[id] = d.commits;
      if (id === 'sanverano') { keys.svCommitter = d.keys.committer; keys.svSigner = d.keys.signer; }
      else if (id === 'onestreet') { keys.osCommitter = d.keys.committer; keys.osSigner = d.keys.signer; }
      else keys.worlds[id] = d.keys;
      log(`  ${id}: CityCommitsV2 ${d.commits} · KeyRegistry ${d.keyRegistry} · listed ${d.listing?.tx}`);
    }
    // SAN VERANO IN REGISTRY MODE (decision K1, "map"): its signer is its registry's active X402_RESPONSE_SIGNER, activated
    // after the registry's 7 days (anvil's clock is moved; the worlds' epochs follow the wall clock, which it does not move)
    const inRegistry = registryMode === 'all' ? Object.keys(deployed) : ['sanverano'];
    if (builtIns) await activateAfterDelay(c, inRegistry.map((id) => deployed[id]));
    const registries = Object.fromEntries(inRegistry.map((id) => [id, { address: deployed[id].keyRegistry }]));
    const chain = viemChain({ ...viem, privateKeyToAccount }, { rpc: c.rpc, chainId: LOCAL_CHAIN, identityStandIn: core.identity });
    // `known` is what each world accepts in a `from`: filled from DISCOVERY below, not from this file's list
    const known = {};
    // the city's own code is loaded only for the network that has the city in it
    const theCity = builtIns ? (city || (await import('../city/cityrules.js')).makeCity(new MemoryStore())) : null;
    const deps = { store: new MemoryStore(), chain, city: theCity, env: { WORLDS_ENABLED: 'true' }, keys, commits, known, worlds, jobsOnChain, registries, release };
    const engines = Object.fromEntries([...firstIds, ...worlds.map((d) => d.id)].map((id) => [id, worldEngine(id, deps)]));
    const down = new Set();
    const setAgent = async (agentId, wallet) => { await c.write(devKey(0), core.identity, core.abis.identity, 'setAgent', [BigInt(agentId), wallet, wallet], `stand-in: set agent ${agentId}`); await c.mine(4); };
    let flushing = false;
    const flushAll = async () => {
      if (flushing) return; flushing = true;
      try { for (const [id, e] of Object.entries(engines)) { try { await e.flush(); } catch (err) { log(`flush ${id}: ${String(err?.shortMessage || err?.message || err).slice(0, 160)}`); } } } finally { flushing = false; }
    };
    const cron = setInterval(flushAll, cronMs);
    stops.push(() => clearInterval(cron));
    const net = { c, core, chain, deps, engines, deployed, listers, origin, urls: Object.fromEntries(Object.entries(bases).map(([id, b]) => [id, `${origin}${b}`])), setAgent, flushAll, known };
    net.discover = () => discover({ chain, pub: c.pub, index: core.index, chainId: LOCAL_CHAIN });
    const srv = await serveWorlds({ engines, port, log, extra: async (req, url, body) => {
      if (url.pathname === '/index/worlds') return [200, await net.discover()];
      // these move the harness: a page on another site gets nothing from them
      if (url.pathname.startsWith('/_local/') && req.headers.origin && req.headers.origin !== origin) return [403, { ok: false, reason: 'not from this machine\'s own pages' }];
      if (url.pathname === '/_local/agent' && req.method === 'POST') { await setAgent(body.agentId, body.wallet); return [200, { ok: true }]; }
      if (url.pathname === '/_local/down' && req.method === 'POST') { if (body?.down) down.add(body.world); else down.delete(body?.world); return [200, { ok: true, down: [...down] }]; }
      for (const id of down) if (url.pathname.startsWith(`${bases[id]}/.well-known`) || url.pathname.startsWith(engines[id].w.api + '/')) return [503, { ok: false, reason: 'down (local harness)' }];
      return extra ? extra(req, url, body, net) : null;
    } });
    stops.push(srv.close);
    // the worlds learn each other from the index: every listed world whose checks pass gives its commits to `known`
    net.learn = async () => { const d = await net.discover(); learnKnown(known, d.worlds); return d; };
    net.stop = async () => { for (const s of stops.reverse()) { try { await s(); } catch { /* stopping */ } } };
    // A WORLD ADDED TO A RUNNING NETWORK, deployed by whoever owns it (the frontend's wallet, say): it starts sealing and posting on the
    // next flush, and the other worlds learn it from the index
    net.addWorld = (def, { commits: at, keyRegistry, keys: worldKeys, role = P.ROLE_NAME }) => {
      if (engines[def.id]) throw new Error(`${def.id} is running already`);
      deps.worlds = [...deps.worlds, def];
      deps.keys.worlds[def.id] = worldKeys;
      deps.commits[def.id] = at;
      deps.registries = { ...deps.registries, [def.id]: { address: keyRegistry, role } };
      engines[def.id] = worldEngine(def.id, deps);
      bases[def.id] = def.base;
      net.urls[def.id] = `${origin}${def.base}`;
      return engines[def.id];
    };
    net.newAgentKey = () => generatePrivateKey();
    net.artifact = artifact;
    return net;
  } catch (e) { for (const s of stops.reverse()) { try { await s(); } catch { /* stopping */ } } throw e; }
}
