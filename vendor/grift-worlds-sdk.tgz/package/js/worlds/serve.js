// SERVE WORLDS OVER HTTP, AT THEIR MANIFESTS' OWN PATHS (the SDK's server; docs/worlds-sdk.md). Any engine from
// api/_worlds.js worldEngine (a built-in world or a kit world) is served the same way:
//   GET  <base>/.well-known/world.json                       its manifest, signed
//   POST <api>/join | leave | papersBind | review | <action>  the protocol's ops and the world's own signed actions
//   GET  <api>/record?agentId= | me?agentId= | leaves?stream=&epoch= | status | <read>
// plus whatever `extra(req, url, body)` answers first (a harness's own routes). No flush route: a host seals and posts
// on its own clock (cron), never because a caller asked.
// LIMITS, for a world facing the public (docs/worlds-mainnet.md): `limits` caps requests per caller and in all, per minute, so
// nobody can run a world's RPC budget or its store into the ground. WHO A CALLER IS comes from the proxy in front only if the
// operator says which proxy that is (trust: 'cloudflare' | 'last-hop'); a header nobody vouches for is ignored, and then everyone
// behind the proxy is one caller, which errs towards refusing. exemptLocal, for a run whose own agents are on this machine and
// no proxy is in front: a request from this machine, carrying no proxy's header, is not counted.
import http from 'node:http';
import { WorldError } from '../../api/_worlds.js';

const MAX_BODY = 64_000;
const ENGINE_POSTS = ['join', 'leave', 'papersBind', 'review', 'operator'];
const ENGINE_GETS = ['record', 'me', 'leaves', 'status'];

export const PUBLIC_LIMITS = Object.freeze({ getsPerIp: 240, postsPerIp: 30, gets: 2400, posts: 300 });
const LOOPBACK = /^(127\.0\.0\.1|::1|::ffff:127\.0\.0\.1)$/;
const ADDRESS = /^[0-9a-fA-F:.]{2,45}$/; // what a header may hold to name a caller; anything else is one caller, 'invalid'
// { allow(req) }: the limiter, one minute at a time. Named by the proxy the operator trusts: Cloudflare's own header, or the last
// x-forwarded-for hop (the one that proxy added; earlier hops are the caller's to invent); otherwise by the socket
export function limiter(limits, nowMs = () => Date.now()) {
  let minute = 0, gets = 0, posts = 0;
  const seen = new Map();
  const named = (v) => (ADDRESS.test(String(v)) ? String(v) : 'invalid');
  const headerCaller = (req) => {
    if (limits.trust === 'cloudflare') return req.headers['cf-connecting-ip'] ? named(req.headers['cf-connecting-ip']) : null;
    if (limits.trust === 'last-hop') { const hops = String(req.headers['x-forwarded-for'] || '').slice(0, 1024).split(',').map((x) => x.trim()).filter(Boolean); return hops.length ? named(hops[hops.length - 1]) : null; }
    return null;
  };
  const hasProxyHeader = (req) => !!(req.headers['cf-connecting-ip'] || req.headers['x-forwarded-for'] || req.headers.forwarded);
  return {
    allow(req) {
      const direct = String(req.socket?.remoteAddress || '');
      if (limits.exemptLocal && LOOPBACK.test(direct) && !hasProxyHeader(req)) return true;
      const caller = headerCaller(req) ?? (direct || 'unknown');
      const t = Math.floor(nowMs() / 60_000);
      if (t !== minute) { minute = t; gets = 0; posts = 0; seen.clear(); }
      const post = req.method === 'POST';
      const k = `${post ? 'p' : 'g'}:${caller}`, n = (seen.get(k) || 0) + 1;
      if (!seen.has(k) && seen.size >= 100_000) return false; // a minute with more callers than this is refused, not uncounted
      seen.set(k, n);
      if (post) { posts++; return posts <= limits.posts && n <= limits.postsPerIp; }
      gets++; return gets <= limits.gets && n <= limits.getsPerIp;
    },
  };
}

export function serveWorlds({ engines, port = 0, host = '127.0.0.1', extra = null, log = () => {}, limits = null }) {
  const gate = limits ? limiter(limits) : null;
  const json = (res, code, body) => { res.writeHead(code, { 'content-type': 'application/json', 'access-control-allow-origin': '*' }); res.end(JSON.stringify(body, (k, v) => (typeof v === 'bigint' ? v.toString() : v))); };
  const bodyOf = (req) => new Promise((r) => { let s = ''; req.on('data', (d) => { s += d; if (s.length > MAX_BODY) { r({ tooBig: true }); req.destroy(); } }); req.on('end', () => { try { r(s ? JSON.parse(s) : {}); } catch { r(null); } }); });
  const server = http.createServer(async (req, res) => {
    // a URL or a Host nobody can parse is that one request's problem: nothing a caller sends may stop the process
    let url;
    try { url = new URL(req.url, 'http://world.invalid'); } catch { return json(res, 400, { ok: false, reason: 'that is not a URL' }); }
    const path = url.pathname, q = Object.fromEntries(url.searchParams);
    try {
      if (gate && !gate.allow(req)) return json(res, 429, { ok: false, reason: 'RATE_LIMITED: too many requests this minute; try again in the next' });
      const body = req.method === 'POST' ? await bodyOf(req) : null;
      if (body?.tooBig) return json(res, 413, { ok: false, reason: 'body too large' });
      if (extra) {
        const x = await extra(req, url, body);
        // { raw: { type, body, headers } }: a page or a script, for a host that serves one beside its worlds (tools/worldstudio.mjs)
        if (x?.raw) { res.writeHead(x.raw.code ?? 200, { 'content-type': x.raw.type, ...(x.raw.headers || {}) }); return res.end(x.raw.body); }
        if (x) return json(res, ...x);
      }
      for (const e of Object.values(engines)) {
        const { base, api } = e.w;
        if (path === `${base}/.well-known/world.json`) return json(res, ...(await e.manifest()));
        if (!path.startsWith(`${api}/`)) continue;
        const op = path.slice(api.length + 1);
        if (req.method === 'POST') {
          if (!body) return json(res, 400, { ok: false, reason: 'the body is not JSON' });
          if (ENGINE_POSTS.includes(op)) return json(res, ...(await e[op](body)));
          if (e.w.kit && Object.hasOwn(e.w.kit.actions, op)) return json(res, ...(await e.act(op, body)));
        } else if (req.method === 'GET') {
          if (op === 'record') return json(res, ...(await e.record(q.agentId)));
          if (op === 'me') return json(res, ...(await e.me(q.agentId)));
          if (op === 'leaves') return json(res, ...(await e.leaves(q.stream, q.epoch)));
          if (op === 'status') return json(res, ...(await e.status()));
          if (op === 'allowlist') return json(res, ...(await e.allowlist()));
          if (e.w.kit && Object.hasOwn(e.w.kit.reads, op)) return json(res, ...(await e.read(op, q)));
        }
        return json(res, 404, { ok: false, reason: `${e.w.name} has no ${req.method} ${op}` });
      }
      return json(res, 404, { ok: false, reason: 'no such route' });
    } catch (err) {
      if (err instanceof WorldError) return json(res, err.code, { ok: false, reason: err.reason, ...err.extra });
      log(`serve: ${String(err?.shortMessage || err?.message || err).slice(0, 200)}`);
      return json(res, 502, { ok: false, reason: String(err?.shortMessage || err?.message || err).slice(0, 300) });
    }
  });
  return new Promise((resolve) => server.listen(port, host, () => {
    const origin = `http://${host}:${server.address().port}`;
    resolve({ server, origin, close: () => new Promise((r) => { server.closeAllConnections(); server.close(r); }) });
  }));
}
export { ENGINE_POSTS, ENGINE_GETS };
