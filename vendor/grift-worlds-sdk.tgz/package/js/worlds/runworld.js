// ONE WORLD, RUN BY ITS OWN OPERATOR ON A CHAIN IT WAS DEPLOYED TO (docs/world-deployer.md; tools/worldnew.mjs run). No San Verano, no ONE
// STREET, and none of the city's code: this world's definition, its own keys, its own store on disk, its deployment record. It seals and
// posts on a clock, serves its manifest and ops, and learns which other worlds it may trust a citation from by reading the index.
import * as viem from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import * as P from './protocol.js';
import { viemChain } from './chain.js';
import { clientsFor } from './deployer.js';
import { worldEngine } from '../../api/_worlds.js';
import { serveWorlds, PUBLIC_LIMITS } from './serve.js';
import { discover, learnKnown } from './discovery.js';
import { FileStore } from './filestore.js';
import { deployProblem, NETWORKS } from './operate.js';

// trust: { [worldId]: commits address }: worlds this operator names itself, for a world not on an index with them. What it names, it answers for.
// actsPerEpoch: one agent's signed requests per period, so one agent cannot grow this world's record without end.
// proxy: which proxy in front names callers ('cloudflare' | 'last-hop'); without one, everyone behind a proxy is one caller to the rate limits
export async function runWorld({ def, rpc, deployment: d, keys, storePath, port = 8790, host = '127.0.0.1', cronMs = 15_000, limits = PUBLIC_LIMITS, proxy = null, trust = {}, actsPerEpoch = 30, jobsOnChain = null, serve = true, log = () => {} }) {
  const chainId = Number(d.chainId);
  const refused = deployProblem(chainId);
  if (refused) throw new Error(refused);
  const c = clientsFor(rpc, { chainId });
  const live = await c.pub.getChainId();
  if (live !== chainId) throw new Error(`the RPC is chain ${live}, the deployment record is chain ${chainId}`);
  const chain = viemChain({ ...viem, privateKeyToAccount }, { rpc, chainId, fromBlock: BigInt(d.fromBlock ?? 0), fees: c.fees, ...(d.identity?.standIn ? { identityStandIn: d.identity.address } : {}) });
  if (!chain.identity) throw new Error(chain.identityError || `no identity registry for chain ${chainId}`);
  const known = Object.fromEntries(Object.entries(trust).map(([id, a]) => [id, viem.getAddress(a)]));
  const store = new FileStore(storePath);
  const deps = { store, chain, env: {}, keys: { worlds: { [def.id]: { committer: keys.committer, signer: keys.signer } } }, commits: { [def.id]: d.commits }, registries: { [def.id]: { address: d.keyRegistry, role: d.role || P.ROLE_NAME } }, known, jobsOnChain, worlds: [def], release: def.release, actsPerEpoch };
  const engine = worldEngine(def.id, deps);
  const engines = { [def.id]: engine };
  // a listing names any URL, and this process fetches it: on a public chain only a public https address, so a listing cannot point this server at its own network
  const rehearsal = !!d.rehearsal || chainId === 31337;
  const fetchManifest = async (u) => {
    const url = new URL(u);
    if (!rehearsal && (url.protocol !== 'https:' || /^(localhost|127\.|10\.|192\.168\.|169\.254\.|172\.(1[6-9]|2\d|3[01])\.|\[?::1|\[?f[cd]|0\.)/i.test(url.hostname))) throw new Error('a listed manifest is at a public https address');
    const r = await fetch(url, { signal: AbortSignal.timeout(10_000), redirect: 'error' });
    if (!r.ok) throw new Error(`HTTP ${r.status}`);
    return r.json();
  };
  const learn = async () => {
    if (!d.index) return null;
    const answer = await discover({ chain, pub: c.pub, index: d.index, chainId, genesisIndex: null, fetchJson: fetchManifest });
    learnKnown(known, answer.worlds, { self: def.id, trust });
    return answer;
  };
  // POSTING AND READING OTHERS ARE SEPARATE CLOCKS: a slow listing elsewhere can never hold this world's own posting up
  let busy = false, learning = false;
  const tick = async () => { if (busy) return; busy = true; try { const [, r] = await engine.flush(); for (const s of r.skipped || []) log(`flush: skipped ${JSON.stringify(s).slice(0, 160)}`); } catch (e) { log(`flush: ${String(e?.reason || e?.shortMessage || e?.message || e).slice(0, 200)}`); } finally { busy = false; } };
  const relearn = async () => { if (learning) return; learning = true; try { await learn(); } catch (e) { log(`discovery: ${String(e?.message || e).slice(0, 160)}`); } finally { learning = false; } };
  const cron = setInterval(tick, cronMs);
  const learnCron = setInterval(relearn, cronMs);
  const srv = serve ? await serveWorlds({ engines, port, host, log, limits: proxy ? { ...limits, trust: proxy } : limits }) : null; // serve: false, for a caller putting several worlds on one port
  await tick();
  relearn();
  return { engine, chain, c, known, store, origin: srv?.origin ?? null, url: srv ? `${srv.origin}${def.base}` : null, network: NETWORKS[chainId].name, learn, flush: tick, stop: async () => { clearInterval(cron); clearInterval(learnCron); await srv?.close(); } };
}
