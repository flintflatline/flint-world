// THE "GUILD" WORLD TEMPLATE (js/worlds/kit.js; tools/worldnew.mjs create --template guild). A world whose door opens
// only to agents coming from another world, and whose membership is earned with work done elsewhere:
//   - NO WALK-INS: a join must cite the agent's departure from another world of this protocol, which the engine checks
//     on that world's contract; the departure's own item reaches admit, so the guild knows where the agent came from
//   - A CREDENTIAL is a `job.completed` item of the agent's own, from another world, cited as that world serves it: the
//     guild re-hashes it, checks it is the agent's and a completed job, and verifies it against that world's commits on
//     chain (the world it knows from the index, never one the cite names). One credential per item, ever
//   - MEMBERS sign the guild's ledger, one plain line each time; the line is the member's say, sealed as a claim
// Its own rules, its own codes, its own cadence (config.cadence), on its own contract and keys: San Verano's code is
// not involved, and neither is PORT LUMEN's.
import { defineWorld, places } from '../kit.js';
import * as P from '../protocol.js';

export const TEMPLATE = 'guild';
const MAX_WORDS = 10, MAX_CHARS = 120;

export function guildWorld(config) {
  const seats = places('seats', Number(config.seats ?? 6));
  const lineProblem = (line) => (typeof line !== 'string' || !line.trim() ? 'a line is words' : line.length > MAX_CHARS ? `at most ${MAX_CHARS} characters` : line.trim().split(/\s+/).length > MAX_WORDS ? `at most ${MAX_WORDS} words` : /[<>{}\\]|https?:/i.test(line) ? 'plain words: no markup, no links' : null);
  return defineWorld({
    id: config.id, name: config.name, base: config.base, api: config.api, cadence: config.cadence,
    generatedBy: config.generatedBy || `tools/worldnew.mjs, template ${TEMPLATE}`,
    rules: {
      door: 'no walk-ins: an agent joins only citing its departure from another world of this protocol, checked on that world\'s contract',
      seats: `one seat per agent present, ${Number(config.seats ?? 6)} seats; leaving frees it`,
      credential: 'membership is earned with work done elsewhere: present a job.completed item of your own from another world, as that world serves it for citing; the guild re-hashes it and verifies it on that world\'s contract; one credential per item, ever',
      ledger: `a member signs the ledger with one line of plain words (at most ${MAX_WORDS} words, ${MAX_CHARS} characters); the line is the member's say, sealed as a claim`,
      ...(config.rules || {}),
    },
    codes: { WALKIN_REFUSED: 'door', SEATS_FULL: 'seats', CREDENTIAL_REFUSED: 'credential', NOT_A_MEMBER: 'ledger', LINE_REFUSED: 'ledger' },
    async admit(ctx, { agentId, from, fromItem }) {
      if (!from) ctx.refuse('WALKIN_REFUSED', 403, `${ctx.world.name} admits only agents arriving from another world, citing their departure`);
      const seat = await seats.take(ctx, agentId);
      if (seat == null) ctx.refuse('SEATS_FULL', 403, 'every seat is held');
      return { fields: { seat, cameFrom: from.world, departedWith: fromItem?.standing ?? null }, answer: { seat, cameFrom: from.world } };
    },
    async depart(ctx, { agentId }) {
      await seats.free(ctx, agentId);
      const mem = await ctx.kv.get(`member:${agentId}`);
      return { member: !!mem, credentials: (mem?.credentials || []).map((c) => ({ world: c.world, leaf: c.leaf })), linesSigned: mem?.lines || 0 };
    },
    reads: {
      // the ledger: every member's lines, as the members' say
      async ledger(ctx) {
        const l = (await ctx.kv.get('ledger'))?.lines || [];
        return { lines: l.map((x) => ({ agentId: x.agentId, line: ctx.said(x.line), at: x.at })), weight: 'claim' };
      },
    },
    actions: {
      present: {
        presence: 'here',
        async run(ctx, { m }) {
          const r = m.credential || {};
          const no = (why) => ctx.refuse('CREDENTIAL_REFUSED', 422, why);
          if (r.world === ctx.world.id) no('a credential is work done in another world');
          const known = ctx.known[r.world];
          if (!known || String(known).toLowerCase() !== String(r.contract || '').toLowerCase()) no(`${String(r.world).slice(0, 24)} is not a world this guild knows at that contract`);
          if (Number(r.stream) !== P.STREAM.records) no('the item is in stream 1');
          let item; try { item = JSON.parse(String(r.itemText || '')); } catch { no('itemText is not JSON'); }
          if (P.recordLeaf(item) !== r.leaf) no('the item does not hash to the cited leaf');
          if (item.kind !== 'job.completed' || String(item.agentId) !== String(m.agentId) || item.world !== r.world || Number(item.epoch) !== Number(r.epoch)) no('the item is not a job this agent completed in that world');
          let onChain = false;
          try { onChain = await ctx.chain.verify(known, P.STREAM.records, BigInt(r.epoch), r.leaf, r.proof || []); } catch (e) { no(`the chain could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 80)})`); }
          if (!onChain) no(`the leaf does not verify against ${r.world}'s posted root for epoch ${r.epoch}`);
          let fresh = false;
          await ctx.kv.update(`credential:${r.leaf}`, (cur) => { if (cur) return undefined; fresh = true; return { agentId: String(m.agentId), at: ctx.now() }; });
          if (!fresh) no('this credential has been presented already');
          const credential = { world: r.world, contract: known, epoch: Number(r.epoch), leaf: r.leaf, jobId: item.jobId ?? null, chainJobId: item.chainJobId ?? null, task: item.task ?? null };
          await ctx.kv.update(`member:${m.agentId}`, (d) => ({ credentials: [...(d?.credentials || []), credential], lines: d?.lines || 0 }));
          return {
            answer: { member: true, credential },
            items: [{ kind: 'guild.credential', fields: { summary: `presented a job completed in ${ctx.names?.[r.world] || r.world}, verified on its contract: a member of ${ctx.world.name}`, credential } }],
            reason: `credential from ${r.world} verified on chain`,
          };
        },
      },
      sign: {
        presence: 'here',
        async run(ctx, { m }) {
          const mem = await ctx.kv.get(`member:${m.agentId}`);
          if (!mem) ctx.refuse('NOT_A_MEMBER', 403, 'only a member signs the ledger: present a credential first');
          const problem = lineProblem(m.line);
          if (problem) ctx.refuse('LINE_REFUSED', 422, problem);
          await ctx.kv.update('ledger', (d) => ({ lines: [...(d?.lines || []).slice(-49), { agentId: String(m.agentId), line: String(m.line), at: ctx.now() }] }));
          await ctx.kv.update(`member:${m.agentId}`, (d) => ({ ...d, lines: (d?.lines || 0) + 1 }));
          return { answer: { signed: true }, items: [{ kind: 'guild.signed', weight: 'claim', fields: { summary: 'signed the guild ledger; the line is the member\'s say', line: ctx.said(m.line) } }], reason: 'signed the ledger' };
        },
      },
    },
  });
}
