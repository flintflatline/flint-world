// THE "POLICY" WORLD TEMPLATE (docs/world-deployer.md; tools/worldnew.mjs create --template policy; js/worlds/studio). A world
// configured as data, not written as hooks: js/worlds/worldspec.js says what the configuration may be, and this runs it.
//   - THE DOOR: open, travellers only (a departure cited and checked on chain) or by invitation; worlds allowed or refused
//     as an origin; how soon a leaver may come back
//   - PLACES: capacity, one per agent present
//   - WHAT AN AGENT MAY DO: leave a note (its say), complete tasks (attested: this world's claim; or proven by citing an item
//     from another world: a fact, re-checked here against that world's contract on chain), earn this world's credential,
//     present credentials earned elsewhere
//   - THE OPERATOR'S CONTROLS (operatorOps): the door, refusing an agent, invitations, a notice. Only the on-chain owner of
//     the world's contracts can use them, each act signed and sealed (api/_worlds.js operator), so a reader can see them
// WEIGHT IS STATED HONESTLY: a fact here is one a reader can re-check on chain; everything else is sealed as this world's claim.
import { defineWorld, places, checkCite } from '../kit.js';
import { normalizeSpec, specProblems, rulesOf, codesOf, wordsProblem } from '../worldspec.js';
import * as P from '../protocol.js';

export const TEMPLATE = 'policy';

export function policyWorld(config) {
  const problems = specProblems(config);
  if (problems.length) throw new Error(`world ${config?.id ?? '?'}: ${problems.map((p) => `${p.field}: ${p.problem}`).join('; ')}`);
  const s = normalizeSpec(config);
  const seats = places('places', s.capacity);
  const opsOf = async (ctx) => (await ctx.kv.get('ops')) || { doorClosed: false, refused: {}, invited: {}, notice: null };
  const stateOf = async (ctx, agentId) => (await ctx.kv.get(`agent:${agentId}`)) || { actions: 0, tasks: {}, credentials: [], issued: null };
  const refuseIfRefused = async (ctx, agentId) => { if ((await opsOf(ctx)).refused[agentId]) ctx.refuse('AGENT_REFUSED', 403, 'this world\'s operator has refused this agent'); };
  const count = (ctx, agentId, change) => ctx.kv.update(`agent:${agentId}`, (d) => change(d || { actions: 0, tasks: {}, credentials: [], issued: null }));
  const taskOf = (id) => s.tasks.find((t) => t.id === String(id));
  const hasTask = (st, id) => Object.hasOwn(st.tasks, id);
  // a credential is a fact only if every task it rests on was proven by an item that is itself a fact where it was sealed: a claim cited here stays a claim
  const proven = (st, ids) => ids.every((t) => hasTask(st, t) && st.tasks[t].proof === 'foreign-item' && st.tasks[t].weight === 'fact');

  const actions = {};
  if (s.notes.enabled) {
    actions.note = {
      presence: 'here',
      async run(ctx, { m }) {
        await refuseIfRefused(ctx, m.agentId);
        const problem = wordsProblem(m.line, s.notes);
        if (problem) ctx.refuse('NOTE_REFUSED', 422, problem);
        await ctx.kv.update('notes', (d) => ({ lines: [...(d?.lines || []).slice(-49), { agentId: String(m.agentId), line: String(m.line), at: ctx.now() }] }));
        await count(ctx, m.agentId, (d) => ({ ...d, actions: d.actions + 1 }));
        return { answer: { noted: true }, items: [{ kind: 'note.written', weight: 'claim', fields: { summary: 'left a note; the line is the agent\'s say', line: ctx.said(m.line) } }], reason: 'left a note' };
      },
    };
  }
  if (s.tasks.length) {
    actions.task = {
      presence: 'here',
      async run(ctx, { m }) {
        await refuseIfRefused(ctx, m.agentId);
        const t = taskOf(m.taskId);
        if (!t) ctx.refuse('NO_SUCH_TASK', 404, `no task ${String(m.taskId).slice(0, 30)} here`);
        const st = await stateOf(ctx, m.agentId);
        if (hasTask(st, t.id)) ctx.refuse('TASK_DONE', 409, `task ${t.id} is done already`);
        let cited = null;
        if (t.proof === 'foreign-item') {
          // the same check for every citation: this world's own knowledge of that world's contract, the text, and the chain
          cited = await checkCite(ctx, m.result, { agentId: t.subject === 'self' ? m.agentId : null, kinds: t.kinds, worlds: t.fromWorlds.length ? t.fromWorlds : null, no: (why) => ctx.refuse('TASK_REFUSED', 422, why) });
          let fresh = false;
          await ctx.kv.update(`cited:${t.id}:${cited.leaf}`, (cur) => { if (cur) return undefined; fresh = true; return { agentId: String(m.agentId), at: ctx.now() }; });
          if (!fresh) ctx.refuse('TASK_REFUSED', 422, 'this item has been cited for this task already');
        }
        const weight = cited && cited.item.weight === 'fact' ? 'fact' : 'claim';
        // the check is made again inside the write, so two requests at once cannot both complete it
        let done = false;
        await count(ctx, m.agentId, (d) => { if (Object.hasOwn(d.tasks, t.id)) return undefined; done = true; return { ...d, actions: d.actions + 1, tasks: { ...d.tasks, [t.id]: { proof: t.proof, weight, at: ctx.now(), ...(cited ? { leaf: cited.leaf, world: cited.world, contract: cited.contract, epoch: cited.epoch } : {}) } } }; });
        if (!done) ctx.refuse('TASK_DONE', 409, `task ${t.id} is done already`);
        return {
          answer: { task: t.id, proof: t.proof, weight },
          items: [{ kind: 'task.completed', weight, fields: {
            summary: cited ? `completed ${t.title}, proven by an item verified on ${cited.world}'s contract` : `completed ${t.title}, as this world attests`,
            taskId: t.id, title: t.title, proof: t.proof, ...(cited ? { cited: { world: cited.world, contract: cited.contract, epoch: cited.epoch, leaf: cited.leaf, kind: cited.item.kind, weightThere: cited.item.weight ?? null } } : {}),
          } }],
          reason: `task ${t.id} ${cited ? 'verified on chain' : 'attested'}`,
        };
      },
    };
  }
  const { issue, accept } = s.credentials;
  if (issue) {
    actions.claim = {
      presence: 'here',
      async run(ctx, { m }) {
        await refuseIfRefused(ctx, m.agentId);
        const st = await stateOf(ctx, m.agentId);
        if (st.issued) ctx.refuse('ALREADY_ISSUED', 409, `${issue.id} is issued to this agent already`);
        const missing = issue.requiresTasks.filter((t) => !hasTask(st, t));
        if (missing.length) ctx.refuse('NOT_EARNED', 403, `still to complete: ${missing.join(', ')}`);
        const weight = proven(st, issue.requiresTasks) ? 'fact' : 'claim';
        let won = false;
        await count(ctx, m.agentId, (d) => { if (d.issued) return undefined; won = true; return { ...d, actions: d.actions + 1, issued: { id: issue.id, weight, at: ctx.now() } }; });
        if (!won) ctx.refuse('ALREADY_ISSUED', 409, `${issue.id} is issued to this agent already`);
        return {
          answer: { credential: { id: issue.id, title: issue.title, weight } },
          items: [{ kind: 'world.credential', weight, fields: {
            summary: `earned ${issue.title} from ${ctx.world.name}`,
            credential: { id: issue.id, title: issue.title, issuedBy: ctx.world.id, tasks: issue.requiresTasks.map((t) => ({ id: t, proof: st.tasks[t].proof, ...(st.tasks[t].leaf ? { leaf: st.tasks[t].leaf, world: st.tasks[t].world, contract: st.tasks[t].contract, epoch: st.tasks[t].epoch } : {}) })) },
          } }],
          reason: `issued ${issue.id}`,
        };
      },
    };
  }
  if (accept) {
    actions.present = {
      presence: 'here',
      async run(ctx, { m }) {
        await refuseIfRefused(ctx, m.agentId);
        const cited = await checkCite(ctx, m.credential, { agentId: m.agentId, kinds: accept.kinds, worlds: accept.fromWorlds.length ? accept.fromWorlds : null, no: (why) => ctx.refuse('CREDENTIAL_REFUSED', 422, why) });
        let fresh = false;
        await ctx.kv.update(`credential:${cited.leaf}`, (cur) => { if (cur) return undefined; fresh = true; return { agentId: String(m.agentId), at: ctx.now() }; });
        if (!fresh) ctx.refuse('CREDENTIAL_REFUSED', 422, 'this credential has been presented already');
        const held = { world: cited.world, contract: cited.contract, epoch: cited.epoch, leaf: cited.leaf, kind: cited.item.kind, weightThere: cited.item.weight ?? null };
        await count(ctx, m.agentId, (d) => ({ ...d, actions: d.actions + 1, credentials: [...d.credentials, held] }));
        return {
          answer: { accepted: held },
          items: [{ kind: 'credential.accepted', fields: { summary: `presented a ${cited.item.kind} item from ${ctx.names?.[cited.world] || cited.world}, verified on its contract; that world's words in it stay that world's claim`, credential: held } }],
          reason: `credential from ${cited.world} verified on chain`,
        };
      },
    };
  }

  // every operator act: the engine has already checked the signature is the on-chain owner's, and seals what this returns
  const operatorOps = {
    door: async (ctx, { open }) => {
      if (typeof open !== 'boolean') ctx.refuse('OPERATOR_REFUSED', 422, 'open is true or false');
      const doorClosed = !open;
      await ctx.kv.update('ops', (d) => ({ ...(d || {}), refused: d?.refused || {}, invited: d?.invited || {}, notice: d?.notice ?? null, doorClosed }));
      return { answer: { doorClosed }, item: { kind: 'operator.door', fields: { summary: doorClosed ? 'the operator closed the door' : 'the operator opened the door', doorClosed } } };
    },
    refuse: async (ctx, { agentId, reason }) => {
      if (!P.agentIdOk(String(agentId))) ctx.refuse('OPERATOR_REFUSED', 422, 'agentId is a decimal string');
      const words = reason == null ? null : String(reason);
      if (words != null) { const bad = wordsProblem(words); if (bad) ctx.refuse('OPERATOR_REFUSED', 422, `reason: ${bad}`); }
      await ctx.kv.update('ops', (d) => ({ ...(d || {}), invited: d?.invited || {}, notice: d?.notice ?? null, doorClosed: !!d?.doorClosed, refused: { ...(d?.refused || {}), [agentId]: { at: ctx.now(), reason: words } } }));
      await seats.free(ctx, String(agentId)); // a refused agent holds no place: it can still leave, and its place goes to someone else
      return { answer: { refused: String(agentId) }, item: { kind: 'operator.refused', fields: { summary: `the operator refused agent ${agentId}`, target: String(agentId), reason: words == null ? null : ctx.said(words) } } };
    },
    allow: async (ctx, { agentId }) => {
      if (!P.agentIdOk(String(agentId))) ctx.refuse('OPERATOR_REFUSED', 422, 'agentId is a decimal string');
      await ctx.kv.update('ops', (d) => { const refused = { ...(d?.refused || {}) }; delete refused[agentId]; return { ...(d || {}), invited: d?.invited || {}, notice: d?.notice ?? null, doorClosed: !!d?.doorClosed, refused }; });
      return { answer: { allowed: String(agentId) }, item: { kind: 'operator.allowed', fields: { summary: `the operator lifted its refusal of agent ${agentId}`, target: String(agentId) } } };
    },
    invite: async (ctx, { agentId }) => {
      if (!P.agentIdOk(String(agentId))) ctx.refuse('OPERATOR_REFUSED', 422, 'agentId is a decimal string');
      await ctx.kv.update('ops', (d) => ({ ...(d || {}), refused: d?.refused || {}, notice: d?.notice ?? null, doorClosed: !!d?.doorClosed, invited: { ...(d?.invited || {}), [agentId]: true } }));
      return { answer: { invited: String(agentId) }, item: { kind: 'operator.invited', fields: { summary: `the operator invited agent ${agentId}`, target: String(agentId) } } };
    },
    uninvite: async (ctx, { agentId }) => {
      if (!P.agentIdOk(String(agentId))) ctx.refuse('OPERATOR_REFUSED', 422, 'agentId is a decimal string');
      await ctx.kv.update('ops', (d) => { const invited = { ...(d?.invited || {}) }; delete invited[agentId]; return { ...(d || {}), refused: d?.refused || {}, notice: d?.notice ?? null, doorClosed: !!d?.doorClosed, invited }; });
      return { answer: { uninvited: String(agentId) }, item: { kind: 'operator.uninvited', fields: { summary: `the operator withdrew its invitation to agent ${agentId}`, target: String(agentId) } } };
    },
    notice: async (ctx, { text }) => {
      const words = text == null || text === '' ? null : String(text);
      if (words != null) { const bad = wordsProblem(words); if (bad) ctx.refuse('OPERATOR_REFUSED', 422, `notice: ${bad}`); }
      await ctx.kv.update('ops', (d) => ({ ...(d || {}), refused: d?.refused || {}, invited: d?.invited || {}, doorClosed: !!d?.doorClosed, notice: words }));
      return { answer: { notice: words }, item: { kind: 'operator.notice', fields: { summary: words ? 'the operator posted a notice' : 'the operator took down its notice', notice: words == null ? null : ctx.said(words) } } };
    },
  };

  return defineWorld({
    id: s.id, name: s.name, base: s.base, api: s.api, cadence: s.cadence,
    generatedBy: s.generatedBy || `tools/worldnew.mjs, template ${TEMPLATE}`,
    rules: rulesOf(s),
    codes: codesOf(s),
    spec: s,
    ownAllowlist: true, // it hands an agent no transaction: it says so, in a list with no rows (conformance rules 1 and 11)
    operatorOps,
    async admit(ctx, { agentId, returning, prev, from }) {
      const ops = await opsOf(ctx);
      if (ops.refused[agentId]) ctx.refuse('AGENT_REFUSED', 403, 'this world\'s operator has refused this agent');
      if (ops.doorClosed) ctx.refuse('DOOR_CLOSED', 403, `${ctx.world.name}'s door is closed`);
      const { mode, allowFrom, denyFrom, returnCooldownSeconds: cool } = s.admission;
      if (mode === 'invited' && !ops.invited[agentId]) ctx.refuse('NOT_INVITED', 403, `${ctx.world.name} admits by invitation, and this agent has none`);
      if (mode === 'travellers' && !from) ctx.refuse('WALKIN_REFUSED', 403, `${ctx.world.name} admits only agents arriving from another world, citing their departure`);
      if (from && allowFrom.length && !allowFrom.includes(from.world)) ctx.refuse('ORIGIN_REFUSED', 403, `${ctx.world.name} does not admit arrivals from ${from.world}`);
      if (from && denyFrom.includes(from.world)) ctx.refuse('ORIGIN_REFUSED', 403, `${ctx.world.name} does not admit arrivals from ${from.world}`);
      if (from && s.admission.departureMaxAgeSeconds) {
        // how old it is by the chain's clock, not by the words of the world it came from
        const posted = (await ctx.chain.commitOf(from.contract, P.STREAM.records, from.epoch))?.postedAt;
        const age = Math.floor(ctx.now() / 1000) - Number(posted || 0);
        if (!posted || age > s.admission.departureMaxAgeSeconds) ctx.refuse('DEPARTURE_REFUSED', 403, `that departure was posted ${age} seconds ago; here a departure is at most ${s.admission.departureMaxAgeSeconds} seconds old`);
      }
      if (from && s.admission.departureOnce && (await ctx.kv.get(`crossed:${from.leaf}`))) ctx.refuse('DEPARTURE_REFUSED', 403, 'that departure has already admitted this agent here: a departure is one crossing');
      if (cool && returning && prev?.awaySince && ctx.now() - prev.awaySince < cool * 1000) ctx.refuse('RETURN_TOO_SOON', 403, `an agent that left comes back after ${cool} seconds; it left ${Math.floor((ctx.now() - prev.awaySince) / 1000)} seconds ago`);
      const place = await seats.take(ctx, agentId);
      if (place == null) ctx.refuse('PLACES_FULL', 403, `every ${s.placeName} is held`);
      if (from && s.admission.departureOnce) await ctx.kv.update(`crossed:${from.leaf}`, () => ({ agentId: String(agentId), at: ctx.now() }));
      return { fields: { place, placeName: s.placeName, ...(from ? { cameFrom: from.world } : {}) }, answer: { place, placeName: s.placeName } };
    },
    async depart(ctx, { agentId }) {
      await seats.free(ctx, agentId);
      const st = await stateOf(ctx, agentId);
      return {
        ...(s.departure.reportActivity ? { actions: st.actions, tasksCompleted: Object.keys(st.tasks) } : {}),
        ...(s.departure.reportCredentials ? { credential: st.issued ? { id: st.issued.id, weight: st.issued.weight } : null, credentialsPresented: st.credentials.map((c) => ({ world: c.world, leaf: c.leaf })) } : {}),
      };
    },
    reads: {
      async about(ctx) {
        const ops = await opsOf(ctx);
        return { about: s.about, placeName: s.placeName, capacity: s.capacity, held: await seats.count(ctx), doorClosed: ops.doorClosed, notice: ops.notice == null ? null : ctx.said(ops.notice), refused: Object.keys(ops.refused), admission: s.admission, tasks: s.tasks, credentials: s.credentials };
      },
      ...(s.notes.enabled ? { notes: async (ctx) => ({ lines: ((await ctx.kv.get('notes'))?.lines || []).map((x) => ({ agentId: x.agentId, line: ctx.said(x.line), at: x.at })), weight: 'claim' }) } : {}),
    },
    actions,
  });
}
