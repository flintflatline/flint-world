// THE "JOBS" WORLD TEMPLATE (js/worlds/kit.js; tools/worldnew.mjs scaffolds a world from it). A world that hires agents
// from other worlds for work it can check itself, and pays through WorldJobs/WorldSettlement on chain (contracts/worldjobs).
//
// THE WORK: an AUDIT of another world's record. A job names a target (a world of this protocol, an agentId, an item kind:
// "the departure of agent 7 from San Verano"); the agent finds the item in that world's own record feed and submits it as
// that world serves it for citing: { world, contract, stream: 1, epoch, leaf, proof, itemText }. This world checks all of
// it itself, trusting neither the agent nor the audited world: the contract is the one it knows for that world, the item
// text hashes to the leaf, the leaf verifies against the root that world posted ON CHAIN, and the item is the target's.
// Only then does it seal `job.completed` (a fact: the evidence is the signed request and the proof); that leaf, once
// posted, is what the world's operator cites to WorldJobs.complete, which checks it against this world's own commits.
//
// config (worlds/<id>/world.json): { id, name, base, api, berths, jobs: [{ id, title, task: 'audit', target: { world,
// agentId, kind }, pay, payToken, chainJobId? }] , rules? }. Jobs may also be posted while running (postJob, below).
import { defineWorld, places } from '../kit.js';
import * as P from '../protocol.js';

export const TEMPLATE = 'jobs';
const AUDIT_KINDS = ['departed', 'arrived', 'returned', 'job.completed'];

// a job's spec, as hashed for WorldJobs.offer(specHash): what the agent is shown and what the chain commits to
// `hours` is how long the work keeps an agent away, as the world states it: what a resident weighs against its wage
export const jobSpec = (worldId, j) => ({ world: worldId, id: String(j.id), title: String(j.title), task: 'audit', target: { world: String(j.target.world), agentId: String(j.target.agentId), kind: String(j.target.kind) }, pay: String(j.pay ?? '0'), payToken: j.payToken ? String(j.payToken) : null, hours: Number(j.hours ?? 24) });
export const specHashOf = (spec) => P.answerHash(spec);

export function jobsWorld(config) {
  const berths = places('berths', Number(config.berths ?? 8));
  const jobKey = (jobId) => `job:${jobId}`;
  const listJobs = async (ctx) => ((await ctx.kv.get('jobs'))?.ids || []);
  const getJob = async (ctx, jobId) => ctx.kv.get(jobKey(jobId));

  async function putJob(ctx, j) {
    const spec = jobSpec(ctx.world.id, j);
    if (!AUDIT_KINDS.includes(spec.target.kind)) ctx.refuse('JOB_REFUSED', 422, `a job audits one of ${AUDIT_KINDS.join(', ')}`);
    if (!P.agentIdOk(spec.target.agentId)) ctx.refuse('JOB_REFUSED', 422, 'target.agentId is an agentId');
    const doc = { spec, specHash: specHashOf(spec), chainJobId: j.chainJobId != null ? String(j.chainJobId) : null, status: 'open', takenBy: null, completedBy: null };
    await ctx.kv.update(jobKey(spec.id), (cur) => (cur ? undefined : doc));
    await ctx.kv.update('jobs', (cur) => { const ids = cur?.ids || []; return ids.includes(spec.id) ? undefined : { ids: [...ids, spec.id] }; });
    return doc;
  }

  const def = defineWorld({
    id: config.id, name: config.name, base: config.base, api: config.api, cadence: config.cadence,
    generatedBy: config.generatedBy || `tools/worldnew.mjs, template ${TEMPLATE}`,
    rules: {
      berths: `one berth per agent present, ${Number(config.berths ?? 8)} berths; leaving frees it`,
      jobs: 'jobs are audits of another world\'s record; each is offered on WorldJobs with the hash of its spec, and paid through WorldSettlement only once WorldJobs releases it',
      take: 'an agent present takes an open job once it has accepted it on WorldJobs (when the job is on chain); one agent per job',
      audit: 'the result is the target item as its world serves it for citing { world, contract, stream: 1, epoch, leaf, proof, itemText }; this world checks the contract is the one it knows for that world, the text hashes to the leaf, the leaf verifies on chain, and the item is the target\'s; then it seals job.completed',
      ...(config.operatorDoor ? { operator: 'the owner of this world\'s contracts posts its jobs; each posting is signed by that owner and sealed in stream 1' } : {}),
      ...(config.rules || {}),
    },
    // the owner posts jobs from anywhere, signed, instead of from the host's own process (api/_worlds.js operator); a world chooses it in its config
    ...(config.operatorDoor ? { operatorOps: { postJob: async (ctx, j) => {
      const doc = await putJob(ctx, j);
      return { answer: { job: doc.spec, specHash: doc.specHash, chainJobId: doc.chainJobId }, item: { kind: 'operator.job.posted', fields: { summary: `the operator posted job ${doc.spec.id}`, jobId: doc.spec.id, specHash: doc.specHash, chainJobId: doc.chainJobId } } };
    } } } : {}),
    codes: { BERTHS_FULL: 'berths', JOB_REFUSED: 'jobs', NO_SUCH_JOB: 'jobs', JOB_TAKEN: 'take', NOT_ACCEPTED_ON_CHAIN: 'take', NOT_YOURS: 'audit', AUDIT_FAILED: 'audit' },
    async admit(ctx, { agentId }) {
      const berth = await berths.take(ctx, agentId);
      if (berth == null) ctx.refuse('BERTHS_FULL', 403, 'every berth is held');
      return { fields: { berth }, answer: { berth } };
    },
    async depart(ctx, { agentId }) {
      await berths.free(ctx, agentId);
      const done = [];
      for (const id of await listJobs(ctx)) { const j = await getJob(ctx, id); if (j?.completedBy === agentId) done.push(id); }
      return { jobsCompleted: done.length, jobs: done };
    },
    reads: {
      // the open jobs, with each spec's hash as WorldJobs holds it
      async jobs(ctx) {
        const out = [];
        for (const id of await listJobs(ctx)) { const j = await getJob(ctx, id); if (j) out.push({ ...j.spec, specHash: j.specHash, chainJobId: j.chainJobId, status: j.status, takenBy: j.takenBy }); }
        return { jobs: out, berthsHeld: await berths.count(ctx) };
      },
    },
    actions: {
      // take an open job; when the job is on chain, only the agent WorldJobs recorded as accepting it
      take: {
        presence: 'here',
        async run(ctx, { m }) {
          const j = await getJob(ctx, String(m.jobId));
          if (!j) ctx.refuse('NO_SUCH_JOB', 404, `no job ${String(m.jobId).slice(0, 20)} here`);
          if (j.status !== 'open') ctx.refuse('JOB_TAKEN', 409, `job ${j.spec.id} is ${j.status}`);
          if (j.chainJobId) {
            const onChain = ctx.jobsOnChain ? await ctx.jobsOnChain(j.chainJobId) : null;
            if (!onChain || String(onChain.agentId) !== String(m.agentId) || onChain.status !== 'ACCEPTED' || onChain.specHash !== j.specHash) ctx.refuse('NOT_ACCEPTED_ON_CHAIN', 409, `job ${j.spec.id} is not accepted on WorldJobs by agent ${m.agentId} (chain job ${j.chainJobId})`);
          }
          await ctx.kv.update(jobKey(j.spec.id), (cur) => (cur.status === 'open' ? { ...cur, status: 'taken', takenBy: String(m.agentId) } : undefined));
          const now = await getJob(ctx, j.spec.id);
          if (now.takenBy !== String(m.agentId)) ctx.refuse('JOB_TAKEN', 409, `job ${j.spec.id} was taken by another agent`);
          return { answer: { job: j.spec, specHash: j.specHash, chainJobId: j.chainJobId }, items: [{ kind: 'job.taken', fields: { summary: `took job ${j.spec.id} (${j.spec.title})`, jobId: j.spec.id, specHash: j.specHash, chainJobId: j.chainJobId } }], reason: `took job ${j.spec.id}` };
        },
      },
      // do the audit: the result is checked here against the audited world's commits on chain, then sealed
      audit: {
        presence: 'here',
        async run(ctx, { m }) {
          const j = await getJob(ctx, String(m.jobId));
          if (!j) ctx.refuse('NO_SUCH_JOB', 404, `no job ${String(m.jobId).slice(0, 20)} here`);
          if (j.takenBy !== String(m.agentId) || j.status !== 'taken') ctx.refuse('NOT_YOURS', 409, `job ${j.spec.id} is not taken by agent ${m.agentId}`);
          const r = m.result || {};
          const t = j.spec.target;
          const fail = (why) => ctx.refuse('AUDIT_FAILED', 422, why);
          if (r.world !== t.world) fail(`the result is from ${String(r.world).slice(0, 24)}, the target is in ${t.world}`);
          const known = ctx.known[t.world];
          if (!known || String(known).toLowerCase() !== String(r.contract || '').toLowerCase()) fail(`${t.world}'s contract is not the one cited`);
          if (Number(r.stream) !== P.STREAM.records) fail('the item is in stream 1');
          let item; try { item = JSON.parse(String(r.itemText || '')); } catch { fail('itemText is not JSON'); }
          if (P.recordLeaf(item) !== r.leaf) fail('the item does not hash to the cited leaf');
          if (item.world !== t.world || String(item.agentId) !== t.agentId || item.kind !== t.kind || Number(item.epoch) !== Number(r.epoch)) fail(`the item is not ${t.kind} of agent ${t.agentId} in ${t.world}`);
          let onChain = false;
          try { onChain = await ctx.chain.verify(known, P.STREAM.records, BigInt(r.epoch), r.leaf, r.proof || []); } catch (e) { fail(`the chain could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 80)})`); }
          if (!onChain) fail(`the leaf does not verify against ${t.world}'s posted root for epoch ${r.epoch}`);
          await ctx.kv.update(jobKey(j.spec.id), (cur) => ({ ...cur, status: 'completed', completedBy: String(m.agentId) }));
          const resultHash = P.answerHash({ world: r.world, contract: known, epoch: Number(r.epoch), leaf: r.leaf });
          return {
            answer: { job: j.spec, resultHash, receipt: 'the completion is sealed in this world\'s stream 1; once posted, its leaf and proof are what WorldJobs.complete checks' },
            items: [{ kind: 'job.completed', fields: { summary: `audited ${t.kind} of agent ${t.agentId} in ${names(ctx, t.world)}: it verifies on chain`, jobId: j.spec.id, specHash: j.specHash, chainJobId: j.chainJobId, task: 'audit', target: t, audited: { world: r.world, contract: known, epoch: Number(r.epoch), leaf: r.leaf }, resultHash } }],
            reason: `audit of ${t.world}/${t.agentId}/${t.kind} verified on chain`,
          };
        },
      },
    },
  });
  // the operator's own door: post a job (not an agent's action; the host calls it with the world's context)
  return Object.freeze({ ...def, postJob: (ctx, j) => putJob(ctx, j), seedJobs: config.jobs || [] });
}
const names = (ctx, worldId) => ctx.names?.[worldId] || worldId;
