// CITIES AS A PROTOCOL, v0 (docs/worlds-protocol.md, docs/worlds-v0.md) — THE PURE HALF. One definition of every
// leaf, typed message, hash and label, shared by the worlds' server (api/_worlds.js), the generic plug-in
// (js/worlds/plugin.js), the round-trip tool and the browser page. No store, no clock of its own, no network, no key.
//
// THE LEAVES (the city's tree, js/verify/tree.js: keccak256(keccak256(abi.encode(...))), sorted pairs):
//   stream 1  records    (uint256 epoch, uint256 agentId, string kind, bytes32 keccak(canonical item))        §1.3
//   stream 2  decisions  (uint256 epoch, uint256 agentId, string op, string kind, bytes32 keccak(reason),
//                         bytes32 keccak(canonical signed request))                                           §1.5
//   stream 16 manifest   (uint256 epoch, bytes32 manifestHash, address signer)  ONE STREET's pin (v0 deviation)
import { keccak256, toBytes, encodeAbiParameters, getAddress, recoverTypedDataAddress } from 'viem';
import { canonical } from '../verify/streams.js';
import { buildHashTree, proofAt, rootFrom } from '../verify/tree.js';

export { canonical };
export const PROTOCOL = 1;
export const CHAIN_ID = 4663;
export const CADENCE = 30; // seconds per epoch, every v0 stream (the doc allows up to a day; the v0 demo wants a round trip in minutes)
export const STREAM = Object.freeze({ records: 1, decisions: 2, manifest: 16 });
export const STREAM_NAMES = Object.freeze({ 1: 'records', 2: 'decisions', 16: 'manifest' });
export const ROLE_NAME = 'RESPONSE_SIGNER';
export const ROLE = keccak256(toBytes(ROLE_NAME));
// the ERC-8004 identity registry on 4663 (docs/harmonic-dd.md §4): UUPS-upgradeable by a third party, so a verifier
// records the implementation it read against
export const ERC8004 = Object.freeze({ chainId: 4663, address: '0x8004A169FB4a3325136EB29fA0ceB6D2e539a432', implementation: '0x7274e874ca62410a93bd8bf61c69d8045e399c02', implementationSlot: '0x' + (BigInt(keccak256(toBytes('eip1967.proxy.implementation'))) - 1n).toString(16).padStart(64, '0') }); // EIP-1967's slot, derived
// WHERE A WORLD READS PAPERS, BY CHAIN (docs/worlds-keyplan.md, docs/worlds-testnet.md). The ERC-8004 registry is on both
// Robinhood chains, each at its own address, on the same implementation (read 2026-10-30: 0x7274…9c02, one code hash).
// Each chain reads ITS OWN registry and nothing overrides mainnet's: a stand-in offered for 4663 is refused, and so is
// either real registry offered for the other's chain. A test chain may instead be given a STAND-IN
// (contracts/worldlocal), which is labelled as one wherever it shows; anvil (31337) has no registry and must be given one.
// Any other chain is refused: a world runs on mainnet or on a named test chain.
export const TEST_CHAINS = Object.freeze({ 46630: 'Robinhood Chain testnet', 31337: 'anvil (local)' });
export const RPC_FOR = Object.freeze({ 4663: 'https://rpc.mainnet.chain.robinhood.com', 46630: 'https://rpc.testnet.chain.robinhood.com' });
export const ERC8004_BY_CHAIN = Object.freeze({ 4663: ERC8004.address, 46630: '0x8004A818BFB912233c491871b3d84c89A494BD9e' });
export function identityRegistry(chainId = CHAIN_ID, standIn = null) {
  const id = Number(chainId);
  const real = ERC8004_BY_CHAIN[id] ? getAddress(ERC8004_BY_CHAIN[id]) : null;
  const realOf = (label) => Object.freeze({ chainId: id, address: real, implementation: ERC8004.implementation, implementationSlot: ERC8004.implementationSlot, standIn: false, label });
  const given = standIn ? getAddress(standIn) : null;
  if (given && Object.entries(ERC8004_BY_CHAIN).some(([c, a]) => Number(c) !== id && getAddress(a) === given)) throw new Error(`${given} is chain ${Object.entries(ERC8004_BY_CHAIN).find(([, a]) => getAddress(a) === given)[0]}'s ERC-8004 registry, not chain ${id}'s: refused`);
  if (id === CHAIN_ID) {
    if (given && given !== real) throw new Error(`chain ${CHAIN_ID} reads papers only from the ERC-8004 registry ${real}; the stand-in ${standIn} is refused`);
    return realOf('the ERC-8004 identity registry');
  }
  if (!TEST_CHAINS[id]) throw new Error(`chain ${id} is neither mainnet (${CHAIN_ID}) nor a test chain (${Object.keys(TEST_CHAINS).join(', ')}): no papers can be read there`);
  if (real && (!given || given === real)) return realOf(`the ERC-8004 identity registry on ${TEST_CHAINS[id]} (${id}): real papers, on a test chain`);
  if (!given) throw new Error(`${TEST_CHAINS[id]} (${id}) has no ERC-8004 registry: give its stand-in's address`);
  return Object.freeze({ chainId: id, address: given, implementation: null, implementationSlot: ERC8004.implementationSlot, standIn: true, label: `STAND-IN identity registry on ${TEST_CHAINS[id]} (${id}): not the ERC-8004 registry; papers read from it prove nothing outside this test chain` });
}
// THE LISTING FEE ON MAINNET (§4.1): 100,000 $GRIFT burnt from the lister's own wallet, its transaction named in the listing.
// WorldIndex stores the hash and reads nothing; discovery checks the receipt (js/worlds/discovery.js burnFacts)
export const LISTING_BURN = Object.freeze({ chainId: CHAIN_ID, token: '0x9f4BA41F91a59A34e17eE8C9EB3A51363B11aBD5', to: '0x000000000000000000000000000000000000dEaD', whole: 100_000, amount: 100_000n * 10n ** 18n });
export const MAX_SKEW_MS = 5 * 60e3; // a join or request signed more than five minutes from the server's clock is refused

// THE FEES A MANIFEST DECLARES (§4.1, §4.2; decisions 4 and 5, 2026-10-29): the burn floors, 70% of x402 intake and 10% of
// shop intake, and no index share until a third-party world lists. burnBps + indexBps ≤ 10000 per rail; the world keeps
// the rest. A world may burn more than its floor and never less.
export const FEE_FLOORS = Object.freeze({ x402: 7000, shops: 1000 });
export const FEE_DEFAULTS = Object.freeze({ x402: Object.freeze({ burnBps: FEE_FLOORS.x402, indexBps: 0 }), shops: Object.freeze({ burnBps: FEE_FLOORS.shops, indexBps: 0 }) });
export function feesProblem(fees) {
  if (!fees || typeof fees !== 'object') return 'fees is { x402: { burnBps, indexBps }, shops: { burnBps, indexBps } }';
  for (const rail of ['x402', 'shops']) {
    const f = fees[rail];
    if (!f || !Number.isInteger(f.burnBps) || !Number.isInteger(f.indexBps) || f.indexBps < 0) return `fees.${rail} is { burnBps, indexBps }, whole basis points`;
    if (f.burnBps < FEE_FLOORS[rail]) return `fees.${rail}.burnBps ${f.burnBps} is under the floor ${FEE_FLOORS[rail]}`;
    if (f.burnBps + f.indexBps > 10000) return `fees.${rail} burns and shares more than the whole intake (${f.burnBps + f.indexBps} bps)`;
  }
  return null;
}

const sha = (text) => keccak256(toBytes(String(text ?? '')));
const leafOf = (types, values) => keccak256(keccak256(encodeAbiParameters(types, values)));
export const epochOf = (ms, cadence = CADENCE) => Math.floor(Number(ms) / 1000 / cadence);
export const epochEndsAt = (epoch, cadence = CADENCE) => (Number(epoch) + 1) * cadence * 1000;
export const agentIdOk = (v) => typeof v === 'string' && /^(0|[1-9][0-9]{0,76})$/.test(v);

// ---- the leaves ------------------------------------------------------------------------------------------------------
export const RECORD_TYPES = [{ type: 'uint256', name: 'epoch' }, { type: 'uint256', name: 'agentId' }, { type: 'string', name: 'kind' }, { type: 'bytes32', name: 'itemHash' }];
export const DECISION_TYPES = [{ type: 'uint256', name: 'epoch' }, { type: 'uint256', name: 'agentId' }, { type: 'string', name: 'op' }, { type: 'string', name: 'kind' }, { type: 'bytes32', name: 'reasonHash' }, { type: 'bytes32', name: 'requestHash' }];
export const MANIFEST_TYPES = [{ type: 'uint256', name: 'epoch' }, { type: 'bytes32', name: 'manifestHash' }, { type: 'address', name: 'signer' }];

// a record item's canonical text: the item with `verify` removed, keys sorted, no spaces (§1.3)
export const itemCanonical = (item) => { const { verify, ...rest } = item || {}; void verify; return canonical(rest); };
export const recordLeaf = (item) => leafOf(RECORD_TYPES, [BigInt(item.epoch), BigInt(item.agentId), String(item.kind), sha(itemCanonical(item))]);
export const requestHash = (req) => sha(canonical(req));
export const decisionLeaf = (d) => leafOf(DECISION_TYPES, [BigInt(d.epoch), BigInt(d.agentId), String(d.op), String(d.kind), sha(d.reason), d.requestHash]);
export const manifestLeaf = (p) => leafOf(MANIFEST_TYPES, [BigInt(p.epoch), p.manifestHash, getAddress(p.signer)]);
export const leafFor = (stream, entry) => (Number(stream) === STREAM.records ? recordLeaf(entry) : Number(stream) === STREAM.decisions ? decisionLeaf(entry) : manifestLeaf(entry));

// ---- the tree: an epoch's leaves, its root, a proof, a fold ------------------------------------------------------------
export function treeOf(leaves) {
  const t = buildHashTree(leaves);
  const sorted = t.layers[0].map((h) => h.toLowerCase());
  return { root: t.root, count: leaves.length, proof: (leaf) => { const pos = sorted.indexOf(String(leaf).toLowerCase()); if (pos < 0) throw new Error('that leaf is not in this tree'); return proofAt(t.layers, pos); } };
}
export const foldProof = (leaf, proof) => rootFrom(leaf, proof);

// ---- the manifest -----------------------------------------------------------------------------------------------------
export const manifestHash = (m) => sha(canonical(m));

// ---- the signed answer: EIP-712 ResponseAttestation(bytes32 responseHash, uint256 issuedAt), as x402's (docs/x402.md),
// in the world's own domain, verifyingContract its KeyRegistry --------------------------------------------------------
export const RESPONSE_TYPES = { ResponseAttestation: [{ name: 'responseHash', type: 'bytes32' }, { name: 'issuedAt', type: 'uint256' }] };
// v0 DEMO: no KeyRegistry; the domain's verifyingContract is the world's own CityCommitsV2. THE DOMAINS NAME THE WORLD'S
// CHAIN (4663 unless the world runs on a test chain), so nothing signed on a test chain verifies for mainnet
const chainOf = (world) => Number(world?.chainId ?? CHAIN_ID);
export const responseDomain = (world) => ({ name: `${world.name} response`, version: '1', chainId: chainOf(world), verifyingContract: getAddress(world.commits) });
export const answerHash = (answer) => sha(canonical(answer));
export const responseTypedData = (world, responseHash, issuedAt) => ({ domain: responseDomain(world), types: RESPONSE_TYPES, primaryType: 'ResponseAttestation', message: { responseHash, issuedAt: BigInt(issuedAt) } });
// THE HEARTBEAT'S SIGNED BODY (api/_worlds.js ensureAlive): the world says it was up and had nothing else in that epoch
export const aliveBody = (world, stream, epoch) => ({ op: 'alive', world: world.id, stream: Number(stream), epoch: Number(epoch) });
export async function recoverAnswerSigner(world, answer, att) {
  if (!att || answerHash(answer) !== att.hash) return null;
  try { return await recoverTypedDataAddress({ ...responseTypedData(world, att.hash, att.issuedAt), signature: att.signature }); } catch { return null; }
}

// ---- the agent's signed requests --------------------------------------------------------------------------------------
// JOIN, exactly §2.1: { uint256 agentId, string world, string name, bytes32 challenge, uint256 ts }. In v0 the challenge
// is the agent's own 32 random bytes, used once (the world keeps every one it took).
export const JOIN_TYPES = { Join: [{ name: 'agentId', type: 'uint256' }, { name: 'world', type: 'string' }, { name: 'name', type: 'string' }, { name: 'challenge', type: 'bytes32' }, { name: 'ts', type: 'uint256' }] };
// THE DOMAIN NAMES THE WORLD'S CONTRACT (version 2): a signature made for one deployment of a world cannot be used on another, on any chain, whatever they share: id, name or
// keys. Version 1, with no contract, is what the worlds before this signed; a world never accepts it, and a reader sees it only in old records, and says so (js/worlds/verifier.js).
export const requestDomain = (world) => (world?.commits
  ? { name: world.name, version: '2', chainId: chainOf(world), verifyingContract: getAddress(world.commits) }
  : { name: world.name, version: '1', chainId: chainOf(world) });
export const joinTypedData = (world, j) => ({ domain: requestDomain(world), types: JOIN_TYPES, primaryType: 'Join', message: { agentId: BigInt(j.agentId), world: String(j.world), name: String(j.name), challenge: j.challenge, ts: BigInt(j.ts) } });
// PAPERSBIND (§2.1): an agent that joined without papers binds them later, signed by the registry's wallet for agentId
// AND by the resident's own city key (its seq, api/_worlds.js papersBind). resident is the city's id for it.
export const PAPERS_BIND_TYPES = { PapersBind: [{ name: 'agentId', type: 'uint256' }, { name: 'world', type: 'string' }, { name: 'resident', type: 'uint256' }, { name: 'challenge', type: 'bytes32' }, { name: 'ts', type: 'uint256' }] };
export const papersBindTypedData = (world, b) => ({ domain: requestDomain(world), types: PAPERS_BIND_TYPES, primaryType: 'PapersBind', message: { agentId: BigInt(b.agentId), world: String(b.world), resident: BigInt(b.resident), challenge: b.challenge, ts: BigInt(b.ts) } });
// EVERY OTHER OP: Request { string msg }, msg the JSON { v:1, op, world, agentId, ts, nonce, ...fields } signed as-is
export const REQUEST_TYPES = { Request: [{ name: 'msg', type: 'string' }] };
export const requestTypedData = (world, msg) => ({ domain: requestDomain(world), types: REQUEST_TYPES, primaryType: 'Request', message: { msg } });

// ---- labels: on everything shown --------------------------------------------------------------------------------------
// FACT: re-derivable by the reader without trusting the world (a signature of the agent's, a transaction, a proof against
// a root on chain). CLAIM: the world's say, shown as "reported by <world>" (§3.1).
export const WEIGHT_TEXT = Object.freeze({ fact: 'FACT', claim: 'CLAIM' });
export const weightLabel = (item, worldName) => (item.weight === 'fact' ? 'FACT · checkable without trusting the world' : `CLAIM · reported by ${worldName}`);

// v0 DEMO SIGNERS (docs/worlds-v0.md): both worlds sign with a throwaway key, labelled so. ONE STREET's is named in its
// manifest and the manifest's hash is posted in its stream 16 before it signs anything.
export const DEMO_LABEL = 'v0 demo key';
export function signerLabel({ pinned = null, registry = null } = {}) {
  // REGISTRY MODE: the key is whatever the world's KeyRegistry says is active for its role; the world signs nothing while
  // it is not (api/_worlds.js ready), so a label is only ever given to an answer from the active key
  if (registry) return { key: 'registry', text: `the active ${registry.role} on KeyRegistry ${registry.address}`, ok: true };
  if (pinned === false) return { key: 'unpinned', text: `${DEMO_LABEL} · manifest not pinned on chain yet: nothing it signs is to be relied on`, ok: false };
  return { key: 'demo', text: pinned ? `${DEMO_LABEL} · named in the manifest, whose hash is pinned in stream 16` : DEMO_LABEL, ok: true };
}
