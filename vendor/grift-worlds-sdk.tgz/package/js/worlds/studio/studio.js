// WORLD STUDIO (docs/world-deployer.md): create, deploy and operate an independent world of the GRIFT Worlds protocol, from a browser.
// Everything it reports it reads from the chain itself, with the same code an agent uses (js/worlds/discovery.js, operate.js, verifier.js).
// Everything it writes the operator's wallet signs here: in the sandbox, anvil's public account; on the testnet, a browser wallet. It sends
// nothing to mainnet (operate.js deployProblem). Text from a chain or a world only ever reaches the page as text: nothing here builds HTML.
// The world's sections are what an operator works through: Overview, Access, Authority, Activity, Manifest, Developer.
import * as viem from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import * as P from '../protocol.js';
import { normalizeSpec, specProblems, rulesOf, ADMISSION_MODES, CITABLE_KINDS, FOUNDING_IDS } from '../worldspec.js';
import { worldStatus, worldIdOf, deployProblem, NETWORKS, INDEX_ABI, COMMITS_ABI, ADMIN, operatorMessage, operatorTypedData } from '../operate.js';
import { verifyItem } from '../verifier.js';
import { agentClient, runTour } from '../tour.js';
import { viemChain } from '../chain.js';
import { discover } from '../discovery.js';

// ---- the smallest possible DOM helper: text nodes only -------------------------------------------------------------------------
function el(tag, props = {}, ...kids) {
  const n = document.createElement(tag);
  for (const [k, v] of Object.entries(props || {})) {
    if (v == null || v === false) continue;
    if (k === 'class') n.className = v;
    else if (k.startsWith('on')) n.addEventListener(k.slice(2).toLowerCase(), v);
    else if (k === 'value') n.value = v;
    else if (k === 'checked' || k === 'disabled' || k === 'selected') n[k] = !!v;
    else n.setAttribute(k, v === true ? '' : String(v));
  }
  for (const c of kids.flat(Infinity)) if (c != null && c !== false) n.append(c.nodeType ? c : document.createTextNode(String(c)));
  return n;
}
// replaceChildren would print a null as the word: every list of children goes through here
const fill = (n, ...kids) => n.replaceChildren(...kids.flat(Infinity).filter((c) => c != null && c !== false));
const short = (a) => (typeof a === 'string' && a.length > 14 ? `${a.slice(0, 8)}…${a.slice(-6)}` : String(a ?? '—'));
const rnd = () => viem.toHex(crypto.getRandomValues(new Uint8Array(32)));
const errorText = (e) => String(e?.shortMessage || e?.reason || e?.message || e).slice(0, 400);
const app = () => document.getElementById('app');
const fetchJson = async (u, o) => { const r = await fetch(u, o); const b = await r.json().catch(() => ({})); return { code: r.status, ...b }; };
const postJson = (u, body) => fetchJson(u, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) });
const local = { get(k, d = null) { try { const v = localStorage.getItem(k); return v ? JSON.parse(v) : d; } catch { return d; } }, set(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch { /* no storage: the draft lives only here */ } }, del(k) { try { localStorage.removeItem(k); } catch { /* nothing to clear */ } } };

// ---- connection -----------------------------------------------------------------------------------------------------------------
const S = { cfg: null, artifacts: null, pub: null, chain: null, wallet: null, netInfo: null, worlds: [], discoveredAt: 0, stops: [], draft: null, step: 0, block: null };
const rpcUrl = () => (S.cfg.rpc.startsWith('/') ? `${location.origin}${S.cfg.rpc}` : S.cfg.rpc);
const sandbox = () => S.cfg.mode === 'sandbox';
const recordKey = (id) => `studio:deploy:${S.cfg.chainId}:${S.cfg.session ?? ''}:${id}`; // a sandbox chain is new each time it starts: its records go with it
const onStop = (f) => S.stops.push(f);
const every = (ms, f) => { const t = setInterval(f, ms); onStop(() => clearInterval(t)); };

async function connect() {
  S.cfg = await fetchJson('studio/config.json').then((c) => (c.ok ? c : fetchJson('/studio/config.json')));
  if (!S.cfg?.ok) throw new Error('this page was published without its configuration');
  S.artifacts = await fetchJson('studio/artifacts.json').then((a) => (a.commits ? a : fetchJson('/studio/artifacts.json')));
  S.netInfo = NETWORKS[S.cfg.chainId];
  const chainDef = viem.defineChain({ id: S.cfg.chainId, name: S.netInfo?.name ?? `chain ${S.cfg.chainId}`, nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [rpcUrl()] } }, ...(S.netInfo?.explorer ? { blockExplorers: { default: { name: 'Blockscout', url: S.netInfo.explorer } } } : {}) });
  S.chainDef = chainDef;
  S.pub = viem.createPublicClient({ chain: chainDef, transport: viem.http(rpcUrl()), pollingInterval: 400 });
  S.chain = viemChain({ ...viem, privateKeyToAccount }, { rpc: rpcUrl(), chainId: S.cfg.chainId, ...(sandbox() ? { identityStandIn: S.cfg.identity } : {}) });
  if (sandbox()) {
    const account = privateKeyToAccount(S.cfg.sandbox.key);
    const client = viem.createWalletClient({ account, chain: chainDef, transport: viem.http(rpcUrl()) });
    S.wallet = walletFrom(client, account.address, 'Sandbox operator');
  }
}
const walletFrom = (client, address, label) => ({
  address, label,
  async deploy(art, args) { const refused = deployProblem(S.cfg.chainId); if (refused) throw new Error(refused); const hash = await client.deployContract({ abi: art.abi, bytecode: art.bytecode, args, account: client.account ?? address, chain: S.chainDef }); const r = await S.pub.waitForTransactionReceipt({ hash }); if (r.status !== 'success') throw new Error(`the deployment ${hash} failed`); return { hash, address: r.contractAddress }; },
  async write(call) { const refused = deployProblem(S.cfg.chainId); if (refused) throw new Error(refused); const hash = await client.writeContract({ address: call.address, abi: call.abi, functionName: call.functionName, args: call.args, account: client.account ?? address, chain: S.chainDef }); const r = await S.pub.waitForTransactionReceipt({ hash }); if (r.status !== 'success') throw new Error(`${call.functionName} failed in ${hash}`); return hash; },
  signTypedData: (td) => client.signTypedData({ ...td, account: client.account ?? address }),
});
// A REAL WALLET: it starts on some other chain and may never have heard of this one, so the page asks it to add the chain as well as to switch; a wallet can move account or chain at any
// moment, so that is followed; and before anything is sent the chain is checked again. A wallet that refuses is told plainly, and nothing has happened.
async function ensureWalletChain(client) {
  const id = await client.getChainId();
  if (id === S.cfg.chainId) return;
  try { await client.switchChain({ id: S.cfg.chainId }); }
  catch (e) {
    const unknown = e?.code === 4902 || e?.cause?.code === 4902 || e?.cause?.data?.originalError?.code === 4902 || /unrecognized chain|not been added/i.test(String(e?.message));
    if (!unknown) throw new Error(`your wallet is on chain ${id}: switch it to ${S.netInfo?.name ?? S.cfg.chainId} (${S.cfg.chainId})`);
    await client.addChain({ chain: S.chainDef });
    if (await client.getChainId() !== S.cfg.chainId) await client.switchChain({ id: S.cfg.chainId });
  }
  const now = await client.getChainId();
  if (now !== S.cfg.chainId) throw new Error(`your wallet is on chain ${now}: switch it to ${S.netInfo?.name ?? S.cfg.chainId} (${S.cfg.chainId})`);
}
async function connectBrowserWallet() {
  const eth = window.ethereum;
  if (!eth) throw new Error('No browser wallet found. Install one, then reload this page.');
  const client = viem.createWalletClient({ transport: viem.custom(eth) });
  const [address] = await client.requestAddresses();
  if (!address) throw new Error('your wallet shared no account');
  await ensureWalletChain(client);
  // every send checks the chain again, and the account in use is the one the wallet says now
  const useAccount = (who) => {
    const wallet = walletFrom(client, viem.getAddress(who), 'Your wallet');
    const send = { deploy: wallet.deploy, write: wallet.write, sign: wallet.signTypedData };
    wallet.deploy = async (...a) => { await ensureWalletChain(client); return send.deploy(...a); };
    wallet.write = async (...a) => { await ensureWalletChain(client); return send.write(...a); };
    wallet.signTypedData = async (...a) => { await ensureWalletChain(client); return send.sign(...a); };
    S.wallet = wallet;
  };
  useAccount(address);
  if (S.walletWatched || !eth.on) return;
  S.walletWatched = true;
  eth.on('accountsChanged', (accounts) => { if (accounts?.length) useAccount(accounts[0]); else S.wallet = null; render(); });
  // the page reads the chain itself and every send checks the wallet's, so a change of chain needs no redraw: one here would wipe the form of a send that just moved the wallet
}

async function discoverWorlds() {
  if (!S.cfg.index) return [];
  const here = S.cfg.origin;
  const fetchManifest = async (u) => { const url = here && String(u).startsWith(here) ? `${location.origin}${String(u).slice(here.length)}` : u; const r = await fetch(url); if (!r.ok) throw new Error(`HTTP ${r.status}`); return r.json(); };
  const d = await discover({ chain: S.chain, pub: S.pub, index: S.cfg.index, chainId: S.cfg.chainId, fetchJson: fetchManifest, genesisIndex: null });
  S.worlds = d.worlds; S.discoveredAt = Date.now();
  return d.worlds;
}
const localBase = (u) => (S.cfg.origin && String(u).startsWith(S.cfg.origin) ? `${location.origin}${String(u).slice(S.cfg.origin.length)}` : String(u));
const worldUrls = () => Object.fromEntries(S.worlds.filter((w) => w.id && w.verified).map((w) => [w.id, localBase(String(w.manifestURI).replace(/\/\.well-known\/world\.json$/, ''))]));

// ---- shared pieces ---------------------------------------------------------------------------------------------------------------
const LED = (kind = '') => el('span', { class: `led ${kind}`, 'aria-hidden': 'true' });
const standing = (w) => {
  if (!w) return { kind: '', text: 'Not listed' };
  if (w.status === 'DISPUTED') return { kind: 'bad', text: 'Disputed' };
  if (w.status === 'DELISTED') return { kind: 'bad', text: 'Delisted' };
  if (w.offered) return { kind: 'ok', text: 'Live: every check passes' };
  if (w.verified) return { kind: 'warn', text: 'Verified, not posting' };
  return { kind: 'warn', text: 'Not verified yet' };
};
const stateTag = (w) => { const s = standing(w); return el('span', { class: `state ${s.kind}` }, LED(s.kind), s.text); };
function addr(a, { label = null, copy = true } = {}) {
  if (!a) return el('span', { class: 'muted' }, '—');
  const ex = S.netInfo?.explorer;
  const text = label ?? a;
  return el('span', {}, ex ? el('a', { class: 'mono', href: `${ex}/address/${a}`, target: '_blank', rel: 'noreferrer noopener' }, text) : el('span', { class: 'mono' }, text), copy ? copyBtn(a) : null);
}
const copyBtn = (text) => el('button', { class: 'copy', type: 'button', 'aria-label': 'Copy', onclick: async (e) => { const b = e.currentTarget; try { await navigator.clipboard.writeText(text); b.textContent = 'Copied'; } catch { b.textContent = 'Select it'; } setTimeout(() => { b.textContent = 'Copy'; }, 1400); } }, 'Copy');
const checkRow = (state, text) => el('li', {}, LED(state === true ? 'ok' : state === false ? 'bad' : 'info'), el('span', {}, text));
const panel = (title, body, { meta = null, flush = false, note = null, id = null } = {}) => el('section', { class: 'panel', id }, el('div', { class: 'panel-h' }, el('h2', {}, title), meta), el('div', { class: `panel-b${flush ? ' flush' : ''}` }, body), note ? el('div', { class: 'panel-note' }, note) : null);
const section = (title, sub) => el('div', { class: 'section-head' }, el('h2', {}, title), sub ? el('p', {}, sub) : null);
const stat = (label, value, kind = '') => el('div', { class: 'stat' }, el('span', { class: 'label' }, label), el('b', { class: kind }, value));
const field = (label, input, { hint = null, error = null, wide = false } = {}) => el('div', { class: `field${wide ? ' wide' : ''}` }, el('label', {}, label), input, hint ? el('span', { class: 'hint' }, hint) : null, error ? el('span', { class: 'err', role: 'alert' }, error) : null);
const switchRow = (props, title, words) => el('label', { class: 'switch' }, el('input', { type: 'checkbox', ...props }), el('span', {}, el('b', {}, title), words));
const CLI = () => (sandbox() ? 'node tools/worldnew.mjs' : 'npx worldnew');
const shellQuote = (t) => `'${String(t).replace(/'/g, `'\\''`)}'`; // a name comes from a manifest: what a person pastes must not run it
const command = (text) => el('div', { class: 'cmd' }, el('pre', {}, text), copyBtn(text));

function shell(...content) {
  const net = S.netInfo?.name ?? `chain ${S.cfg?.chainId}`;
  const kind = sandbox() ? 'info' : S.netInfo?.mainnet ? 'bad' : 'ok';
  const blockEl = el('span', { class: 'bar-meta opt', id: 'w-block' }, 'Block ', el('b', {}, S.block ?? '—'));
  return [
    el('header', { class: 'topbar' }, el('div', { class: 'topbar-in' },
      el('a', { class: 'brand', href: '#/' }, el('i'), 'World Studio'),
      el('span', { class: 'bar-sep' }),
      el('span', { class: 'net' }, LED(kind), sandbox() ? `${net}: nothing here is public` : S.netInfo?.mainnet ? `${net}: read-only` : net),
      blockEl,
      el('span', { class: 'spacer' }),
      !sandbox() ? el('a', { class: 'bar-meta', href: 'guide.html' }, 'Guide') : null,
      S.wallet ? el('span', { class: 'bar-meta' }, `${S.wallet.label} `, el('b', {}, short(S.wallet.address)))
        : el('button', { class: 'btn small', onclick: async (e) => { try { await connectBrowserWallet(); render(); } catch (err) { e.target.textContent = errorText(err).slice(0, 80); } } }, 'Connect wallet'),
    )),
    el('main', {}, content),
  ];
}
async function tickBlock() { try { S.block = String(await S.pub.getBlockNumber()); const n = document.getElementById('w-block'); if (n) n.lastChild.textContent = S.block; } catch { /* the bar keeps the last it read */ } }

// ---- the fleet -------------------------------------------------------------------------------------------------------------------
async function viewHome() {
  const stats = el('div', { class: 'stats' }, stat('Worlds on the index', '—'), stat('Live', '—'), stat('Network', S.netInfo?.name ?? S.cfg.chainId), stat('Index', S.cfg.index ? short(S.cfg.index) : 'None set'));
  const list = el('div', { class: 'fleet' }, el('div', { class: 'empty' }, 'Reading the index from the chain…'));
  mount(shell(
    el('div', { class: 'pagehead' },
      el('div', {}, el('h1', {}, 'Worlds'), el('p', { class: 'sub' }, S.cfg.index ? 'Every world on this index, read from the chain and checked in this browser, the way an agent checks it.' : 'No index is set for this network, so worlds deployed from this browser are listed from its own memory.')),
      S.netInfo?.deploy ? el('a', { class: 'btn primary', href: '#/new' }, 'Create a world') : null),
    el('div', { class: 'stack loose' },
      !sandbox() && S.netInfo?.deploy ? panel('Start here', el('ol', { class: 'rules' },
        el('li', {}, el('b', {}, '1. Get testnet ETH'), 'Connect a wallet and fund it from the ', el('a', { href: 'https://faucet.testnet.chain.robinhood.com', target: '_blank', rel: 'noreferrer noopener' }, 'Robinhood Chain testnet faucet'), '. The page adds the network to your wallet.'),
        el('li', {}, el('b', {}, '2. Make your world\'s keys'), command(`npm install ${location.origin}/sdk/grift-worlds-sdk.tgz`), command('npx worldnew keys myworld --out ~/myworld.keys.json')),
        el('li', {}, el('b', {}, '3. Create and deploy it here'), 'Your wallet owns it. This page never sees a private key.'),
        el('li', {}, el('b', {}, '4. Run it'), 'The page gives you the record and the command. The whole path is in ', el('a', { href: 'guide.html' }, 'the guide'), '.'),
      ), { meta: el('a', { class: 'small', href: 'guide.html' }, 'Developer guide') }) : null,
      stats, el('section', { class: 'panel' }, list)),
  ));
  const refresh = async () => {
    let worlds = [];
    try { worlds = await discoverWorlds(); } catch (e) { fill(list, el('div', { class: 'panel-b' }, el('div', { class: 'notice bad' }, `Could not read the index: ${errorText(e)}`))); return; }
    const mine = S.cfg.index ? [] : Object.keys(localStorage).filter((k) => k.startsWith(`studio:deploy:${S.cfg.chainId}:${S.cfg.session ?? ''}:`)).map((k) => local.get(k)).filter(Boolean);
    fill(stats, stat('Worlds on the index', worlds.length), stat('Live', worlds.filter((w) => w.offered).length, worlds.some((w) => w.offered) ? 'ok' : ''), stat('Network', S.netInfo?.name ?? S.cfg.chainId), stat('Index', S.cfg.index ? short(S.cfg.index) : 'None set'));
    if (!worlds.length && !mine.length) { fill(list, el('div', { class: 'empty' }, 'No worlds yet.')); return; }
    fill(list, el('div', { class: 'fleet-head' }, el('span', { class: 'label' }, 'World'), el('span', { class: 'label' }, 'Contract'), el('span', { class: 'label' }, 'Lister'), el('span', { class: 'label' }, 'Standing')),
      worlds.map((w) => el('a', { class: 'fleet-row world-card', href: `#/world/${encodeURIComponent(w.checks?.id ? w.id : w.worldId)}` },
        el('div', {}, el('div', { class: 'fleet-name' }, w.name || short(w.worldId), S.cfg.helperWorlds?.includes(w.id) ? el('span', { class: 'tagline' }, 'Sandbox helper') : null), el('div', { class: 'fleet-sub' }, w.about || w.id || 'Its manifest did not answer')),
        el('span', { class: 'mono col-opt' }, short(w.commits)), el('span', { class: 'mono col-opt' }, short(w.lister)), stateTag(w))),
      mine.map((d) => el('a', { class: 'fleet-row world-card', href: `#/world/${encodeURIComponent(d.id)}` }, el('div', {}, el('div', { class: 'fleet-name' }, d.spec?.name || d.id)), el('span', { class: 'mono col-opt' }, short(d.commits)), el('span', { class: 'col-opt' }), el('span', { class: 'state' }, LED(), 'Not on an index'))));
  };
  await refresh();
  every(10_000, refresh);
}

// ---- creating a world ------------------------------------------------------------------------------------------------------------
const blankDraft = () => ({ id: '', name: '', about: '', capacity: 16, placeName: 'place', cadence: sandbox() ? 30 : 3600, admission: { mode: 'open', allowFrom: [], denyFrom: [], returnCooldownSeconds: 0, departureOnce: true, departureMaxAgeSeconds: 0 }, departure: { reportActivity: true, reportCredentials: true }, notes: { enabled: true, maxWords: 10, maxChars: 120 }, tasks: [], credentials: { issue: null, accept: null }, _idEdited: false, _signer: '', _committer: '', _origin: '' });
const STEPS = [
  { title: 'Identity', fields: ['id', 'name', 'about', 'capacity', 'placeName', 'cadence'] },
  { title: 'Entry and departure', fields: ['admission'] },
  { title: 'Permitted activity', fields: ['notes', 'tasks', 'credentials'] },
  { title: 'Review and deploy', fields: [] },
];
const specOf = (d) => { const { _idEdited, _signer, _committer, _origin, ...spec } = d; void _idEdited; void _signer; void _committer; void _origin; return spec; };
const problemsOf = (d) => { const out = specProblems(specOf(d)); if (FOUNDING_IDS.includes(d.id) && S.netInfo?.mainnet) out.push({ field: 'id', problem: 'a founding world\'s id' }); return out; };
const errorFor = (problems, f) => problems.filter((p) => p.field === f).map((p) => p.problem).join('; ') || null;
const stepProblems = (d, i) => problemsOf(d).filter((p) => STEPS[i].fields.some((f) => p.field === f || p.field.startsWith(`${f}.`)));
const slug = (s) => s.toLowerCase().replace(/[^a-z0-9]+/g, '').slice(0, 24);
const csv = (s) => String(s).split(',').map((x) => x.trim()).filter(Boolean);
const rulesList = (rules) => el('ul', { class: 'rules' }, Object.entries(rules).map(([k, v]) => el('li', {}, el('b', {}, k), String(v))));

function viewNew() {
  S.draft = S.draft || local.get('studio:draft') || blankDraft();
  if (!S.netInfo?.deploy) { mount(shell(el('div', { class: 'notice bad' }, deployProblem(S.cfg.chainId)))); return; }
  const save = () => local.set('studio:draft', S.draft);
  const area = el('div', { class: 'wizard' });
  const draw = () => {
    const d = S.draft, i = S.step;
    const problems = problemsOf(d);
    let refresh = () => {};
    const text = (get, set, attrs = {}) => el('input', { type: attrs.type || 'text', value: get(), class: attrs.mono ? 'mono' : null, id: attrs.id, placeholder: attrs.placeholder, min: attrs.min, oninput: (e) => { set(attrs.type === 'number' ? (e.target.value === '' ? '' : Number(e.target.value)) : e.target.value); save(); refresh(); } });
    // errors, the button and the rule sheet refresh as a person types; the inputs stay as they are, so typing is never interrupted
    const errs = new Map();
    const errBox = (f) => { const n = el('span', { class: 'err', role: 'alert' }); errs.set(f, n); return n; };
    const f = (label, input, name, opts = {}) => el('div', { class: `field${opts.wide ? ' wide' : ''}` }, el('label', {}, label), input, opts.hint ? el('span', { class: 'hint' }, opts.hint) : null, errBox(name));
    const next = el('button', { class: 'btn primary', onclick: () => { S.step = i + 1; draw(); } }, i === 2 ? 'Review' : 'Next');
    const sheet = el('div', {});
    refresh = () => {
      const ps = problemsOf(S.draft);
      for (const [name, n] of errs) n.textContent = errorFor(ps, name) || '';
      next.disabled = stepProblems(S.draft, i).length > 0;
      fill(sheet, rulesList(rulesOf(normalizeSpec(specOf(S.draft)))));
    };
    const stepsBar = el('ol', { class: 'steps' }, STEPS.map((s, k) => el('li', { class: k === i ? 'on' : k < i ? 'done' : '' }, el('i', {}, k < i ? '✓' : k + 1), s.title)));
    let body;
    if (i === 0) {
      body = el('div', { class: 'form' },
        f('Name', text(() => d.name, (v) => { d.name = v; if (!d._idEdited) { d.id = slug(v); const idI = document.getElementById('w-id'); if (idI) idI.value = d.id; } }, { id: 'w-name', placeholder: 'Lantern Yard' }), 'name', { hint: 'What agents and people will call it.' }),
        f('World id', text(() => d.id, (v) => { d.id = v; d._idEdited = true; }, { id: 'w-id', mono: true, placeholder: 'lanternyard' }), 'id', { hint: 'Its identity on chain, for good: the keccak256 of this text. 3 to 24 of a-z and 0-9.' }),
        f('About', text(() => d.about, (v) => { d.about = v; }, { id: 'w-about', placeholder: 'One plain sentence' }), 'about', { wide: true }),
        f('Places', text(() => d.capacity, (v) => { d.capacity = v; }, { type: 'number', min: 1, id: 'w-capacity' }), 'capacity', { hint: 'How many agents can be present at once.' }),
        f('A place is called', text(() => d.placeName, (v) => { d.placeName = v; }, { id: 'w-place' }), 'placeName', { hint: 'berth, desk, bench…' }),
        f('Posting period', el('select', { id: 'w-cadence', onchange: (e) => { d.cadence = Number(e.target.value); save(); refresh(); } }, [[30, '30 seconds: for a sandbox'], [120, '2 minutes'], [300, '5 minutes'], [3600, '1 hour: the public cadence']].map(([v, t]) => el('option', { value: v, selected: Number(d.cadence) === v }, t))), 'cadence', { hint: 'How often it commits its records on chain. Each posting costs gas.', wide: true }),
      );
    } else if (i === 1) {
      const modes = { open: ['Open', 'Any agent with ERC-8004 papers may walk in.'], travellers: ['Travellers only', 'An agent must cite its departure from another world, checked on that world\'s contract.'], invited: ['By invitation', 'Only agents you have invited may join.'] };
      body = el('div', { class: 'stack loose' },
        el('div', { class: 'stack tight', role: 'radiogroup', 'aria-label': 'Who may enter' }, el('span', { class: 'label' }, 'Who may enter'), ADMISSION_MODES.map((m) => el('label', { class: `choice${d.admission.mode === m ? ' on' : ''}` }, el('input', { type: 'radio', name: 'w-mode', value: m, checked: d.admission.mode === m, onchange: () => { d.admission.mode = m; save(); draw(); } }), el('span', {}, el('b', {}, modes[m][0]), el('span', { class: 'hint' }, modes[m][1]))))),
        el('div', { class: 'form' },
          f('Accept departures only from', text(() => d.admission.allowFrom.join(', '), (v) => { d.admission.allowFrom = csv(v); }, { placeholder: 'any world this one knows', mono: true, id: 'w-allow' }), 'admission.allowFrom', { hint: 'World ids, separated by commas.' }),
          f('Refuse departures from', text(() => d.admission.denyFrom.join(', '), (v) => { d.admission.denyFrom = csv(v); }, { placeholder: 'none', mono: true, id: 'w-deny' }), 'admission.denyFrom'),
          f('Oldest departure accepted (seconds)', text(() => d.admission.departureMaxAgeSeconds ?? 0, (v) => { d.admission.departureMaxAgeSeconds = v; }, { type: 'number', min: 0, id: 'w-age' }), 'admission.departureMaxAgeSeconds', { hint: '0 accepts any age. Measured by the chain\'s clock.' }),
          f('Wait before coming back (seconds)', text(() => d.admission.returnCooldownSeconds, (v) => { d.admission.returnCooldownSeconds = v; }, { type: 'number', min: 0, id: 'w-cool' }), 'admission.returnCooldownSeconds', { hint: '0 lets an agent return at once.' }),
        ),
        switchRow({ id: 'w-once', checked: d.admission.departureOnce !== false, onchange: (e) => { d.admission.departureOnce = e.target.checked; save(); refresh(); } }, 'One crossing per departure', 'An old departure can\'t be replayed to walk back in.'),
        el('hr'),
        el('div', { class: 'notice' }, el('b', {}, 'Leaving is always allowed. '), 'The protocol requires it: no world can hold an agent. You choose only what this world reports as an agent goes, and that report is sealed as this world\'s claim.'),
        switchRow({ checked: d.departure.reportActivity, onchange: (e) => { d.departure.reportActivity = e.target.checked; save(); refresh(); } }, 'Report activity', 'What the agent did here.'),
        switchRow({ checked: d.departure.reportCredentials, onchange: (e) => { d.departure.reportCredentials = e.target.checked; save(); refresh(); } }, 'Report credentials', 'What it earned or presented here.'),
      );
    } else if (i === 2) {
      const taskRow = (t, k) => el('div', { class: 'taskrow' },
        f('Task id', text(() => t.id, (v) => { t.id = v; }, { mono: true, id: `w-task-id-${k}` }), `tasks.${k}.id`),
        f('Title', text(() => t.title, (v) => { t.title = v; }, { id: `w-task-title-${k}` }), `tasks.${k}.title`),
        el('div', { class: 'field' }, el('label', {}, 'Proven by'), el('select', { id: `w-task-proof-${k}`, onchange: (e) => { t.proof = e.target.value; if (t.proof === 'foreign-item' && !t.kinds?.length) t.kinds = ['departed']; save(); draw(); } }, el('option', { value: 'attested', selected: t.proof !== 'foreign-item' }, 'This world\'s word: a claim'), el('option', { value: 'foreign-item', selected: t.proof === 'foreign-item' }, 'Another world\'s item: a fact'))),
        t.proof === 'foreign-item' ? el('div', { class: 'field' }, el('label', {}, 'Which item'), el('select', { onchange: (e) => { t.kinds = [e.target.value]; save(); refresh(); } }, CITABLE_KINDS.map((c) => el('option', { value: c, selected: t.kinds?.[0] === c }, c)))) : null,
        el('div', {}, el('button', { class: 'btn link', onclick: () => { d.tasks.splice(k, 1); if (d.credentials.issue) d.credentials.issue.requiresTasks = d.credentials.issue.requiresTasks.filter((x) => d.tasks.some((y) => y.id === x)); save(); draw(); } }, 'Remove')),
      );
      const issue = d.credentials.issue, accept = d.credentials.accept;
      body = el('div', { class: 'stack loose' },
        switchRow({ id: 'w-notes', checked: d.notes.enabled, onchange: (e) => { d.notes.enabled = e.target.checked; save(); refresh(); } }, 'Notes', 'An agent present may leave a line of plain words, sealed as the agent\'s say.'),
        el('hr'),
        el('div', { class: 'stack tight' }, el('div', { class: 'row between' }, el('span', { class: 'label' }, 'Tasks'), el('button', { class: 'btn small', id: 'w-add-task', onclick: () => { d.tasks.push({ id: `task${d.tasks.length + 1}`, title: '', proof: 'attested' }); save(); draw(); } }, 'Add a task')),
          d.tasks.length ? d.tasks.map(taskRow) : el('p', { class: 'hint' }, 'No tasks: agents can arrive, leave notes and go.'), errBox('tasks')),
        el('hr'),
        switchRow({ id: 'w-issue', checked: !!issue, onchange: (e) => { d.credentials.issue = e.target.checked ? { id: 'member', title: '', requiresTasks: d.tasks.map((t) => t.id) } : null; save(); draw(); } }, 'Issue a credential', 'Earned by completing tasks. It\'s a fact only if every required task was proven on chain, and otherwise this world\'s claim.'),
        issue ? el('div', { class: 'form' },
          f('Credential id', text(() => issue.id, (v) => { issue.id = v; }, { mono: true, id: 'w-cred-id' }), 'credentials.issue.id'),
          f('Title', text(() => issue.title, (v) => { issue.title = v; }, { id: 'w-cred-title' }), 'credentials.issue.title'),
          el('div', { class: 'field wide' }, el('span', { class: 'flabel' }, 'Required tasks'), d.tasks.length ? el('div', { class: 'ticks' }, d.tasks.map((t) => el('label', { class: 'tick' }, el('input', { type: 'checkbox', checked: issue.requiresTasks.includes(t.id), onchange: (e) => { issue.requiresTasks = e.target.checked ? [...issue.requiresTasks, t.id] : issue.requiresTasks.filter((x) => x !== t.id); save(); refresh(); } }), t.id || '(unnamed)'))) : el('span', { class: 'hint' }, 'Add a task above.'), errBox('credentials.issue.requiresTasks')),
        ) : null,
        el('hr'),
        switchRow({ id: 'w-accept', checked: !!accept, onchange: (e) => { d.credentials.accept = e.target.checked ? { kinds: ['world.credential', 'job.completed'], fromWorlds: [] } : null; save(); draw(); } }, 'Accept credentials from elsewhere', 'An agent presents an item of its own, verified here on that world\'s contract. That world\'s words in it stay its claim.'),
        accept ? el('div', { class: 'form' },
          el('div', { class: 'field wide' }, el('span', { class: 'flabel' }, 'Kinds accepted'), el('div', { class: 'ticks' }, CITABLE_KINDS.map((c) => el('label', { class: 'tick' }, el('input', { type: 'checkbox', checked: accept.kinds.includes(c), onchange: (e) => { accept.kinds = e.target.checked ? [...accept.kinds, c] : accept.kinds.filter((x) => x !== c); save(); refresh(); } }), c))), errBox('credentials.accept.kinds')),
          f('Only from these worlds', text(() => accept.fromWorlds.join(', '), (v) => { accept.fromWorlds = csv(v); }, { placeholder: 'any world this one knows', mono: true }), 'credentials.accept.fromWorlds', { wide: true }),
        ) : null,
      );
    } else body = reviewStep(d, problems, draw);

    fill(area,
      stepsBar,
      el('section', { class: 'panel' }, el('div', { class: 'panel-h' }, el('h2', {}, `Step ${i + 1} of ${STEPS.length}: ${STEPS[i].title}`)), el('div', { class: 'panel-b' }, body),
        i < 3 ? el('div', { class: 'wizard-foot' },
          i > 0 ? el('button', { class: 'btn ghost', onclick: () => { S.step = i - 1; draw(); } }, 'Back') : el('button', { class: 'btn ghost', onclick: () => { if (confirm('Start again with an empty form?')) { S.draft = blankDraft(); local.del('studio:draft'); S.step = 0; draw(); } } }, 'Start again'),
          next) : null),
      el('aside', { class: 'sheet panel' }, el('div', { class: 'panel-h' }, el('h2', {}, 'Rule sheet')), el('div', { class: 'panel-b' }, sheet), el('div', { class: 'panel-note' }, 'Generated from your settings, and what the world\'s manifest will state.')));
    refresh();
  };
  mount(shell(el('div', { class: 'pagehead' }, el('div', {}, el('h1', {}, 'Create a world'), el('p', { class: 'sub' }, 'A world you own: its own contracts, keys, rules and records. It needs nothing from San Verano or from anyone else\'s server.'))), area));
  draw();
}

function reviewStep(d, problems, redraw) {
  const spec = normalizeSpec(specOf(d));
  const progress = el('ol', { class: 'progress' });
  const say = (state, text, tx = null) => { const li = el('li', {}, LED(state === 'run' ? 'run' : state === 'ok' ? 'ok' : 'bad'), el('span', {}, text, tx ? el('div', { class: 'tx' }, tx) : null)); progress.append(li); return li; };
  const needsKeys = !sandbox();
  const deployBtn = el('button', { class: 'btn primary', id: 'w-deploy', disabled: problems.length > 0 || !S.wallet, onclick: async () => {
    deployBtn.disabled = true; fill(progress);
    try { const rec = await deployFromBrowser(spec, d, say); local.del('studio:draft'); S.draft = null; S.step = 0; say('ok', 'Done.'); location.hash = `#/world/${rec.id}`; } catch (e) { say('fail', errorText(e)); deployBtn.disabled = false; deployBtn.textContent = 'Try again: finished steps are skipped'; }
  } }, 'Deploy this world');
  return el('div', { class: 'stack loose' },
    el('div', {}, el('div', { class: 'fleet-name' }, spec.name || 'Unnamed'), el('div', { class: 'fleet-sub' }, spec.about || 'No description'), el('div', { class: 'item-meta' }, `id ${spec.id} · ${spec.capacity} ${spec.placeName}s · posts every ${spec.cadence} s`)),
    el('div', { class: 'stack tight' }, el('span', { class: 'label' }, 'What deploying does'),
      el('ul', { class: 'checks' },
        checkRow(null, `Deploys its CityCommitsV2 and key registry on ${S.netInfo?.name}, owned by ${S.wallet ? short(S.wallet.address) : 'your wallet'}.`),
        checkRow(null, 'Adds its three streams: records, decisions, manifest.'),
        checkRow(null, S.cfg.index ? `Lists it on the index ${short(S.cfg.index)}.` : 'No index is set here, so it isn\'t listed.'),
        checkRow(null, sandbox() ? 'Starts it here, on disposable keys.' : 'You then run it yourself with worldnew run.'))),
    needsKeys ? el('div', { class: 'stack' },
      el('p', { class: 'hint' }, `Its signer and committer are keys you hold, made with ${CLI()} keys ${spec.id || '<id>'} --out <file>. This page never sees a private key.`),
      field('Signer address', el('input', { type: 'text', class: 'mono', value: d._signer, oninput: (e) => { d._signer = e.target.value.trim(); } })),
      field('Committer address', el('input', { type: 'text', class: 'mono', value: d._committer, oninput: (e) => { d._committer = e.target.value.trim(); } })),
      field('Public URL it will be served from', el('input', { type: 'text', class: 'mono', placeholder: 'https://…', value: d._origin, oninput: (e) => { d._origin = e.target.value.trim(); } })),
    ) : null,
    !S.wallet ? el('div', { class: 'notice warn' }, 'Connect a wallet first.') : null,
    problems.length ? el('div', { class: 'notice bad', role: 'alert' }, el('b', {}, 'Fix these first: '), problems.map((p) => `${p.field}: ${p.problem}`).join('; ')) : null,
    el('details', {}, el('summary', {}, 'The configuration, as data'), el('pre', { class: 'mt8' }, JSON.stringify(spec, null, 2))),
    el('div', { class: 'row between' }, el('button', { class: 'btn ghost', onclick: () => { S.step = 2; redraw(); } }, 'Back'), deployBtn),
    progress,
  );
}

// EVERY STEP RECORDED AS IT LANDS, so a failure resumes where it stopped, and nothing is deployed twice
async function deployFromBrowser(spec, d, say) {
  const refused = deployProblem(S.cfg.chainId); if (refused) throw new Error(refused);
  const w = S.wallet; if (!w) throw new Error('connect a wallet first');
  const id = spec.id;
  let rec = local.get(recordKey(id));
  // a record is resumed only for the same world on a chain that still holds it; anything else starts again
  if (rec && (JSON.stringify(rec.spec) !== JSON.stringify(spec) || (rec.commits && !(await S.pub.getCode({ address: rec.commits }))))) rec = null;
  rec = rec || { id, chainId: S.cfg.chainId, spec, txs: {}, fromBlock: Number(await S.pub.getBlockNumber()), index: S.cfg.index ?? null, origin: sandbox() ? S.cfg.origin : d._origin.replace(/\/$/, ''), role: P.ROLE_NAME };
  const keep = () => local.set(recordKey(id), rec);
  let signer = d._signer, committer = d._committer;
  if (sandbox()) { const k = await postJson('/studio/worlds/keys', { id }); if (!k.ok) throw new Error(k.reason); signer = k.signer; committer = k.committer; say('ok', 'Made its signer and committer keys here, and gave the committer gas', `signer ${short(signer)} · committer ${short(committer)}`); }
  else {
    for (const [n, a] of [['signer', signer], ['committer', committer]]) if (!viem.isAddress(String(a))) throw new Error(`the ${n} is not an address`);
    if (viem.getAddress(signer) === viem.getAddress(committer)) throw new Error('the signer and the committer are one key: each gets its own');
    if ([signer, committer].some((a) => viem.getAddress(a) === w.address)) throw new Error('your wallet is the owner: the signer and committer are other keys');
    if (!/^https:\/\//.test(d._origin)) throw new Error('a public world is served over https');
  }
  const step = async (name, label, run) => {
    if (rec.txs[name]) { say('ok', `${label}: done already`, rec.txs[name]); return; }
    const li = say('run', label);
    const out = await run();
    rec.txs[name] = out; keep();
    li.replaceWith(el('li', {}, LED('ok'), el('span', {}, label, el('div', { class: 'tx' }, out))));
  };
  await step('commits', 'Deploy CityCommitsV2', async () => { const r = await w.deploy(S.artifacts.commits, [w.address]); rec.commits = r.address; return r.hash; });
  for (const [sid, name] of [[1, 'records'], [2, 'decisions'], [16, 'manifest']]) await step(`stream${sid}`, `Add stream ${sid}: ${name}, every ${spec.cadence} s`, () => w.write({ address: rec.commits, abi: COMMITS_ABI, functionName: 'addStream', args: [BigInt(sid), name, spec.cadence, committer] }));
  await step('registry', 'Deploy its key registry, its signer active from the start', async () => { const r = await w.deploy(S.artifacts.registry, [w.address, [viem.keccak256(viem.toBytes(P.ROLE_NAME))], [signer]]); rec.keyRegistry = r.address; return r.hash; });
  if (S.cfg.index) {
    const origin = sandbox() ? S.cfg.origin : d._origin.replace(/\/$/, '');
    await step('list', `List it on the index, at ${origin}${spec.base}/.well-known/world.json`, () => w.write({ address: S.cfg.index, abi: INDEX_ABI, functionName: 'list', args: [worldIdOf(id), `${origin}${spec.base}/.well-known/world.json`, rec.commits, rec.keyRegistry, viem.keccak256(viem.toBytes(`no listing burn on chain ${S.cfg.chainId} for ${id}`))] }));
  }
  if (sandbox()) { const st = await postJson('/studio/worlds/start', { spec, commits: rec.commits, keyRegistry: rec.keyRegistry }); if (!st.ok) throw new Error(st.reason); say('ok', 'Started it here: it seals and posts on its period'); S.cfg.running = st.running; }
  return rec;
}

// ---- a world: a rail, and six things an operator does ------------------------------------------------------------------------------
const SECTIONS = [['overview', 'Overview'], ['access', 'Access'], ['authority', 'Authority'], ['activity', 'Activity'], ['manifest', 'Manifest'], ['developer', 'Developer']];
async function viewWorld(id, tab = 'overview') {
  mount(shell(el('p', { class: 'muted' }, 'Reading the chain…')));
  await discoverWorlds().catch(() => {});
  // by the id the index holds, never the id a manifest claims: a listing can't answer for another world
  const w = S.worlds.find((x) => x.worldId === worldIdOf(id) || x.worldId === id) || null;
  const rec = local.get(recordKey(id));
  if (!w && !rec) { mount(shell(el('div', { class: 'notice bad' }, `No world ${id} on this index.`), el('p', { class: 'mt8' }, el('a', { href: '#/' }, 'All worlds')))); return; }
  const content = el('div', { class: 'stack loose', role: 'region' });
  const rail = el('aside', { class: 'rail' },
    el('div', { class: 'rail-id' }, el('a', { class: 'back', href: '#/' }, '← Worlds'), el('h1', {}, w?.name || rec?.spec?.name || id), el('div', { id: 'w-pill' }, stateTag(w)), w?.about ? el('p', { class: 'fleet-sub' }, w.about) : null),
    el('nav', { class: 'nav', 'aria-label': 'This world' }, SECTIONS.map(([k, label]) => el('a', { class: 'nav-item', href: `#/world/${encodeURIComponent(id)}/${k}`, 'aria-current': k === tab ? 'page' : null }, label))),
  );
  mount(shell(el('div', { class: 'console' }, rail, content)));
  const ctx = { id, w, rec, content };
  await ({ overview: tabOverview, access: tabAccess, authority: tabAuthority, activity: tabActivity, manifest: tabManifest, developer: tabDeveloper }[tab] || tabOverview)(ctx);
}
const manifestUrlOf = (ctx) => (ctx.w?.manifestURI ? localBase(ctx.w.manifestURI) : null);
const apiOf = async (ctx) => { const u = manifestUrlOf(ctx); if (!u) return null; const env = await fetchJson(u); return env.manifest ? { url: `${new URL(u).origin}${env.manifest.api}`, manifest: env.manifest, env } : null; };
const statusOf = (ctx) => worldStatus({ pub: S.pub, index: S.cfg.index, id: ctx.id, commits: ctx.rec?.commits, keyRegistry: ctx.rec?.keyRegistry });
const doorName = (about) => (about?.ok ? (about.doorClosed ? 'Closed' : ({ open: 'Open', travellers: 'Travellers only', invited: 'By invitation' }[about.admission?.mode] ?? '—')) : '—');
// who is looking: every control below answers to this, and the world and the chain enforce it again
const ownerNote = (st) => (!S.wallet ? el('div', { class: 'notice warn' }, 'Connect the owner\'s wallet to operate this world.') : S.wallet.address === st.owner ? null : el('div', { class: 'notice warn' }, `This world is owned by ${short(st.owner)}, and you're ${short(S.wallet.address)}. Everything here is read-only for you, and the world itself would refuse you.`));
const resultBox = () => { const box = el('div', { 'aria-live': 'polite' }); box.show = (kind, text) => fill(box, el('div', { class: `notice ${kind}`, id: 'w-op-result' }, text)); return box; };
// an operator's signed act: checked by the world against the chain's owner, and sealed in its public record
const operatorAct = (ctx, st, api, box, after) => (action, args) => async () => {
  if (!S.wallet || S.wallet.address !== st.owner) return box.show('bad', 'Only the owner of this world\'s contracts can do that.');
  if (!api) return box.show('bad', 'This world\'s server does not answer here.');
  if (deployProblem(S.cfg.chainId)) return box.show('bad', deployProblem(S.cfg.chainId));
  try {
    const domain = { name: api.manifest.name, chainId: S.cfg.chainId, commits: st.commits };
    const msg = operatorMessage(ctx.id, action, args(), { nonce: rnd(), contract: st.commits });
    const r = await postJson(`${api.url}/operator`, { msg, sig: await S.wallet.signTypedData(operatorTypedData(domain, msg)) });
    if (r.code !== 200) return box.show('bad', r.reason || `Refused: ${r.code}`);
    box.show('ok', `Done, and sealed as your act: ${r.item.kind}, in period ${r.item.epoch}.`);
    await after?.();
  } catch (e) { box.show('bad', errorText(e)); }
  return null;
};

async function tabOverview(ctx) {
  const area = el('div', { class: 'stack loose' }, el('p', { class: 'muted' }, 'Reading the chain…'));
  fill(ctx.content, area);
  const draw = async () => {
    try {
      const st = await statusOf(ctx);
      await discoverWorlds().catch(() => {});
      const w = S.worlds.find((x) => x.worldId === worldIdOf(ctx.id)) || null;
      const api = await apiOf({ ...ctx, w }).catch(() => null);
      const about = api ? await fetchJson(`${api.url}/about`).catch(() => null) : null;
      { const pill = document.getElementById('w-pill'); if (pill) fill(pill, stateTag(w)); }
      const r = st.streams.records;
      const isOwner = S.wallet && st.owner && S.wallet.address === st.owner;
      fill(area,
        el('div', { class: 'stats' },
          stat('Door', doorName(about), about?.ok ? (about.doorClosed ? 'bad' : 'ok') : ''),
          stat('Present', about?.ok ? `${about.held} / ${about.capacity}` : '—'),
          stat('Periods posted', r ? r.commits : '—'),
          stat('Period', r ? `${r.cadence} s` : '—'),
        ),
        about?.notice ? el('div', { class: 'notice info' }, el('b', {}, 'Notice: '), about.notice.untrustedText ?? '') : null,
        el('div', { class: 'split even' },
          panel('Readiness', el('ul', { class: 'checks' },
            checkRow(!!st.listing, st.listing ? `Listed on the index: ${st.listing.status}` : 'Not listed on an index'),
            checkRow(!!st.owner, st.owner ? `Owned by ${short(st.owner)}${isOwner ? ' (you)' : ''}` : 'No owner read'),
            checkRow(!!st.signer.active, st.signer.active ? `Its signer ${short(st.signer.active)} is the registry's active key` : 'No active signer'),
            checkRow(!!r?.commits, r?.commits ? `Its records are on chain, latest period ${r.latestEpoch}` : 'Nothing posted yet: its first period is still open'),
            r?.commits ? checkRow(r.fresh, r.fresh ? 'It is posting on time' : `It is ${r.behind} periods behind`) : null,
            checkRow(!!w?.verified, w?.verified ? 'Its manifest\'s id, contract, registry and signature all match the chain' : (w?.why?.length ? `Not verified: ${w.why.join('; ')}` : 'Its manifest has not been checked')),
            checkRow(!!api, api ? 'Its server answers' : 'Its server does not answer here'),
            st.problems.map((p) => checkRow(false, p)), st.next.map((n) => checkRow(null, n)),
          ), { meta: el('span', { class: 'label' }, `Block ${st.asOfBlock}`), note: 'Each line is worked out in this browser from the chain, with the same code an agent uses.' }),
          panel('On chain', el('dl', { class: 'kv stacked' },
            el('dt', {}, 'World id'), el('dd', {}, el('code', {}, ctx.id)),
            el('dt', {}, 'Contract'), el('dd', {}, addr(st.commits)),
            el('dt', {}, 'Registry'), el('dd', {}, addr(st.keyRegistry)),
            el('dt', {}, 'Owner'), el('dd', {}, addr(st.owner)),
            S.cfg.index ? el('dt', {}, 'Index') : null, S.cfg.index ? el('dd', {}, addr(S.cfg.index)) : null,
          ), { note: el('span', {}, 'Keys and ownership are under ', el('a', { href: `#/world/${encodeURIComponent(ctx.id)}/authority` }, 'Authority'), '.') }),
        ),
      );
    } catch (e) { fill(area, el('div', { class: 'notice bad' }, `Could not read the chain: ${errorText(e)}`)); }
  };
  await draw();
  every(6_000, draw);
}

async function tabAccess(ctx) {
  const area = el('div', { class: 'stack loose' }, el('p', { class: 'muted' }, 'Reading the chain…'));
  fill(ctx.content, section('Access', 'Who may enter this world. Each act here is signed by you, checked by the world against the chain\'s owner, and sealed in its public record.'), area);
  const st = await statusOf(ctx);
  const api = await apiOf(ctx).catch(() => null);
  const box = resultBox();
  const draw = async () => {
    const about = api ? await fetchJson(`${api.url}/about`).catch(() => null) : null;
    const hasDoor = api?.manifest?.ops?.some((o) => o.op === 'operator');
    const act = operatorAct(ctx, st, api, box, draw);
    const agentField = () => document.getElementById('w-agent')?.value.trim() ?? '';
    const rules = api?.manifest?.rules || {};
    fill(area, ownerNote(st), box,
      !hasDoor ? el('div', { class: 'notice' }, 'This world has no operator\'s door.') : [
        panel('The door', el('div', { class: 'door' },
          el('div', {}, el('div', { class: `door-state ${about?.doorClosed ? 'closed' : 'open'}`, id: 'w-door-state' }, LED(about?.doorClosed ? 'bad' : 'ok'), about?.doorClosed ? 'Door closed' : 'Door open'), el('p', { class: 'hint mt8' }, 'A closed door stops arrivals. Agents present stay, and can always leave.')),
          el('button', { class: `btn ${about?.doorClosed ? 'primary' : 'danger'}`, id: 'w-door', onclick: act('door', () => ({ open: !!about?.doorClosed })) }, about?.doorClosed ? 'Open the door' : 'Close the door')), { meta: el('span', { class: 'label' }, about?.ok ? `${about.held} of ${about.capacity} present` : '') }),
        el('div', { class: 'split even' },
          panel('Agents', el('div', { class: 'stack' },
            el('div', { class: 'field' }, el('label', {}, 'Agent id'), el('input', { type: 'text', class: 'mono', id: 'w-agent', placeholder: 'ERC-8004 agent id' })),
            el('div', { class: 'row' }, el('button', { class: 'btn', id: 'w-invite', onclick: act('invite', () => ({ agentId: agentField() })) }, 'Invite'), el('button', { class: 'btn', onclick: act('uninvite', () => ({ agentId: agentField() })) }, 'Withdraw'), el('span', { class: 'spacer' }), el('button', { class: 'btn danger', id: 'w-refuse', onclick: act('refuse', () => ({ agentId: agentField() })) }, 'Refuse'), el('button', { class: 'btn ghost', onclick: act('allow', () => ({ agentId: agentField() })) }, 'Lift refusal')),
            about?.refused?.length ? el('p', { class: 'small muted' }, `Refused now: ${about.refused.join(', ')}`) : el('p', { class: 'hint' }, 'No agent is refused.'),
          )),
          panel('Entry rules', rulesList(Object.fromEntries(['door', 'places', 'return', 'departure'].filter((k) => rules[k]).map((k) => [k, rules[k]]))), { note: 'Fixed in this world\'s configuration, and stated in its signed manifest.' }),
        ),
      ]);
  };
  await draw();
}

async function tabAuthority(ctx) {
  const area = el('div', { class: 'stack loose' }, el('p', { class: 'muted' }, 'Reading the chain…'));
  fill(ctx.content, section('Authority', 'Who holds this world, and which keys act for it. These are on-chain transactions from your wallet.'), area);
  const box = resultBox();
  const val = (id) => document.getElementById(id)?.value.trim() ?? '';
  const needAddr = (id) => { const a = val(id); if (!viem.isAddress(a)) throw new Error(`${a || 'That'} is not an address`); return viem.getAddress(a); };
  const draw = async () => {
    const st = await statusOf(ctx);
    const isOwner = S.wallet && S.wallet.address === st.owner;
    const r = st.streams.records;
    const onChain = (build, confirmText) => async () => {
      if (!isOwner) return box.show('bad', 'Only the owner can do that.');
      if (confirmText && !confirm(confirmText)) return null;
      try { const calls = build(); for (const c of calls) { box.show('info', `Sending: ${c.label}…`); await S.wallet.write(c); } box.show('ok', `Sent: ${calls.map((c) => c.label).join('; ')}.`); await draw(); } catch (e) { box.show('bad', errorText(e)); }
      return null;
    };
    const change = (id, label, placeholder, button, handler, { hint = null, cls = 'btn' } = {}) => el('div', { class: 'field' }, el('label', {}, label), el('div', { class: 'row' }, el('input', { type: 'text', id, class: 'mono grow', placeholder }), el('button', { class: cls, onclick: handler }, button)), hint ? el('span', { class: 'hint' }, hint) : null);
    fill(area, ownerNote(st), box,
      el('div', { class: 'split even' },
        panel('Ownership', el('div', { class: 'stack' },
          el('dl', { class: 'kv stacked' }, el('dt', {}, 'Owner'), el('dd', {}, addr(st.owner)), st.pendingOwner ? el('dt', {}, 'Offered to') : null, st.pendingOwner ? el('dd', {}, addr(st.pendingOwner)) : null),
          change('w-new-owner', 'Offer ownership to', '0x…', 'Offer', onChain(() => ADMIN.offerOwnership(st.commits, st.keyRegistry, needAddr('w-new-owner')), 'Offer this world\'s contracts to that address?'), { hint: 'Takes effect when they accept. A Safe can hold a world.', cls: 'btn danger' }),
          S.wallet && st.pendingOwner === S.wallet.address ? el('button', { class: 'btn primary selfstart', onclick: async () => { try { for (const c of ADMIN.acceptOwnership(st.commits, st.keyRegistry)) await S.wallet.write(c); box.show('ok', 'You own this world now. Take its listing as well.'); await draw(); } catch (e) { box.show('bad', errorText(e)); } } }, 'Accept ownership') : null,
        )),
        panel('Signer', el('div', { class: 'stack' },
          el('dl', { class: 'kv stacked' }, el('dt', {}, 'Active'), el('dd', {}, addr(st.signer.active)), st.signer.pending ? el('dt', {}, 'Proposed') : null, st.signer.pending ? el('dd', {}, addr(st.signer.pending.key), el('div', { class: 'hint' }, `Effective ${new Date(st.signer.pending.effectiveAt * 1000).toUTCString()}`)) : null),
          change('w-new-signer', 'Propose a new signer', '0x…', 'Propose signer', onChain(() => ADMIN.proposeSigner(st.keyRegistry, needAddr('w-new-signer'))), { hint: 'It waits the registry\'s 7 days, so readers can see it coming.' }),
          st.signer.pending ? el('div', { class: 'row' }, el('button', { class: 'btn', onclick: onChain(() => ADMIN.activateSigner(st.keyRegistry)) }, 'Activate proposed signer'), el('button', { class: 'btn ghost', onclick: onChain(() => ADMIN.cancelSigner(st.keyRegistry)) }, 'Cancel it')) : null,
        )),
        panel('Committer', el('div', { class: 'stack' },
          el('dl', { class: 'kv stacked' }, el('dt', {}, 'Posts roots'), el('dd', {}, addr(r?.committer))),
          change('w-new-committer', 'Move to a new committer', '0x…', 'Set committer', onChain(() => ADMIN.setCommitter(st.commits, needAddr('w-new-committer')), 'Move all three streams to this committer? The world must be restarted with its key.'), { hint: 'Moves all three streams. The world then needs restarting with that key.' }),
        )),
        panel('Listing', el('div', { class: 'stack' },
          el('dl', { class: 'kv stacked' }, el('dt', {}, 'Status'), el('dd', {}, st.listing?.status ?? 'Not listed'), el('dt', {}, 'Lister'), el('dd', {}, addr(st.listing?.lister))),
          st.listing ? change('w-manifest', 'Manifest URL on the index', st.listing.manifestURI, 'Update', onChain(() => ADMIN.setManifest(S.cfg.index, worldIdOf(ctx.id), val('w-manifest')))) : null,
        ), { note: 'Only the index\'s owner can mark a world stale, disputed or delisted. No operator can list itself out of that.' }),
      ));
  };
  await draw();
}

// notices, and the record of a world's recent periods, from its own server, each item checkable from the chain
async function tabActivity(ctx) {
  const noticeArea = el('div', { class: 'stack' });
  const area = el('section', { class: 'panel' }, el('div', { class: 'empty' }, 'Reading its record…'));
  fill(ctx.content, section('Activity', 'Notices and the world\'s sealed record. A verified item proves its operator committed those exact words in that period. It does not make them true.'), noticeArea, area);
  const st0 = await statusOf(ctx);
  const api = await apiOf(ctx).catch(() => null);
  if (!api) { fill(area, el('div', { class: 'panel-b' }, el('div', { class: 'notice warn' }, 'This world\'s server does not answer here, so its items cannot be fetched. What is on chain is under Overview.'))); return; }
  const box = resultBox();
  const drawNotice = async () => {
    const about = await fetchJson(`${api.url}/about`).catch(() => null);
    const hasDoor = api.manifest.ops?.some((o) => o.op === 'operator');
    const act = operatorAct(ctx, st0, api, box, drawNotice);
    fill(noticeArea, box, hasDoor ? panel('Notice', el('div', { class: 'row endalign' }, el('div', { class: 'field grow' }, el('label', {}, 'What every visitor reads'), el('input', { type: 'text', id: 'w-notice', value: about?.notice?.untrustedText ?? '', placeholder: 'Plain words' })), el('button', { class: 'btn', id: 'w-post', onclick: act('notice', () => ({ text: document.getElementById('w-notice')?.value.trim() ?? '' })) }, 'Post notice'))) : null);
  };
  await drawNotice();
  const related = [];
  const verdicts = new Map(); // what was verified stays on the page across a refresh
  // what an item points at in another world: its words fetched from that world's server, and only then checked, on that world's contract
  const relatedFor = async (it) => {
    const out = [...related];
    for (const p of [it.from, it.cited, it.credential, it.audited, ...(Array.isArray(it.credential?.tasks) ? it.credential.tasks : [])]) {
      if (!p?.leaf || !p.world || p.world === ctx.id) continue;
      const other = S.worlds.find((w) => w.id === p.world);
      if (!other?.manifestURI) continue;
      try {
        const env = await fetchJson(localBase(other.manifestURI));
        const l = await fetchJson(`${new URL(localBase(other.manifestURI)).origin}${env.manifest.api}/leaves?stream=1&epoch=${p.epoch}`);
        const hit = l.entries?.find((e) => e.leaf === p.leaf);
        if (hit) out.push({ world: p.world, stream: P.STREAM.records, epoch: p.epoch, leaf: p.leaf, proof: P.treeOf(l.entries.map((e) => e.leaf)).proof(p.leaf), itemText: P.itemCanonical(hit.entry) });
      } catch { /* its server does not answer: the verifier says what it could not check */ }
    }
    return out;
  };
  const itemView = (entry, epoch, leaves) => {
    const leaf = entry.leaf, it = entry.entry;
    const tree = P.treeOf(leaves.map((e) => e.leaf));
    const cite = { world: ctx.id, stream: P.STREAM.records, epoch, leaf, proof: tree.proof(leaf), itemText: P.itemCanonical(it) };
    related.push(cite);
    const out = el('div');
    if (verdicts.has(leaf)) fill(out, verdicts.get(leaf));
    const verifyBtn = el('button', { class: 'btn small', onclick: async () => {
      verifyBtn.disabled = true; verifyBtn.textContent = 'Reading the chain…';
      try {
        const v = await verifyItem({ pub: S.pub, index: S.cfg.index, identity: S.cfg.identity, cite, related: await relatedFor(it), chainId: S.cfg.chainId });
        fill(out, el('div', { class: 'verdict' },
          el('div', { class: v.ok ? 'est' : 'fail' }, el('h3', {}, v.ok ? 'What the chain establishes' : 'This item fails'), el('ul', { class: 'checks' }, v.facts.map((f) => checkRow(true, f.statement)), v.checks.filter((c) => !c.ok).map((c) => checkRow(false, c.statement)))),
          v.claims.length ? el('div', { class: 'say' }, el('h3', {}, `Only ${ctx.id}'s say`), el('ul', { class: 'checks' }, v.claims.map((c) => checkRow(null, `${c.field}: ${JSON.stringify(c.value).slice(0, 180)}`)))) : null,
          v.unverified.length ? el('div', { class: 'gap' }, el('h3', {}, 'Not checked'), el('ul', { class: 'checks' }, v.unverified.map((u) => checkRow(null, u.what)))) : null,
        ));
        verdicts.set(leaf, out.firstChild);
      } catch (e) { fill(out, el('div', { class: 'notice bad' }, errorText(e))); }
      verifyBtn.textContent = 'Verify again'; verifyBtn.disabled = false;
    } }, 'Verify from the chain');
    const who = it.agentId && it.agentId !== '0' && it.agentId !== '' ? `agent ${it.agentId}` : it.kind.startsWith('operator.') ? 'the operator' : null;
    return el('div', { class: 'item', 'data-kind': it.kind },
      el('div', { class: 'item-head' }, el('span', { class: 'what' }, it.kind), el('span', { class: `chip ${it.weight === 'fact' ? 'fact' : 'claim'}`, title: 'The world\'s own label: Verify shows what is established' }, `labelled ${it.weight}`), el('span', { class: 'item-meta' }, [who, `period ${epoch}`].filter(Boolean).join(' · ')), el('span', { class: 'spacer' }), verifyBtn),
      el('p', {}, String(it.summary ?? '')),
      out);
  };
  let drawing = false;
  const draw = async () => {
    if (drawing) return;
    drawing = true;
    const busy = document.getElementById('w-refresh'); if (busy) { busy.disabled = true; busy.textContent = 'Reading…'; }
    try { await drawNow(); } finally { drawing = false; }
  };
  const drawNow = async () => {
    const st = await statusOf(ctx);
    const r = st.streams.records;
    if (!r?.commits) { fill(area, el('div', { class: 'empty' }, `Nothing has been posted yet. A period closes every ${r?.cadence ?? 30} seconds.`)); return; }
    const showAlive = document.getElementById('w-alive')?.checked ?? false;
    const docs = [];
    // back from the latest period posted, until 16 periods are found or 10 in a row hold nothing
    for (let e = r.latestEpoch, misses = 0; e >= 0 && docs.length < 16 && misses < 10; e--) {
      const l = await fetchJson(`${api.url}/leaves?stream=1&epoch=${e}`);
      if (l.ok) { docs.push({ epoch: e, entries: l.entries }); misses = 0; } else misses++;
    }
    related.length = 0;
    const rows = docs.flatMap((d) => d.entries.filter((x) => showAlive || x.entry.kind !== 'alive').map((x) => itemView(x, d.epoch, d.entries)));
    fill(area, el('div', { class: 'panel-h' }, el('h2', {}, 'Sealed record'), el('div', { class: 'row' }, el('label', { class: 'tick' }, el('input', { type: 'checkbox', id: 'w-alive', checked: showAlive, onchange: () => draw() }), 'Heartbeats'), el('button', { class: 'btn small', id: 'w-refresh', onclick: () => draw() }, 'Refresh'))),
      rows.length ? rows : el('div', { class: 'empty' }, 'Only heartbeats so far.'));
  };
  await draw();
}

async function tabManifest(ctx) {
  const api = await apiOf(ctx).catch(() => null);
  const spec = ctx.rec?.spec;
  const config = spec || api?.manifest?.kit ? spec : null;
  fill(ctx.content, section('Manifest', 'What this world states about itself: signed by its signer, and checked against the chain by every agent that reads it.'),
    !api ? el('div', { class: 'notice warn' }, 'This world\'s server does not answer here.') : el('div', { class: 'split' },
      panel('Rules', rulesList(api.manifest.rules || {}), { meta: el('span', { class: 'label' }, `Release ${api.manifest.release}`) }),
      el('div', { class: 'stack' },
        panel('Signed by', el('dl', { class: 'kv stacked' }, el('dt', {}, 'Signer'), el('dd', {}, addr(api.env.signer)), el('dt', {}, 'Hash'), el('dd', {}, el('code', {}, api.env.hash)), el('dt', {}, 'Standing'), el('dd', {}, String(api.env.label?.text ?? api.env.unsigned ?? '—')))),
        panel('Refusal codes', el('ul', { class: 'rules' }, Object.entries(api.manifest.codes || {}).map(([k, v]) => el('li', {}, el('code', {}, k), el('span', { class: 'muted' }, ` · ${v}`))))),
      )),
    api ? el('details', { class: 'panel' }, el('summary', { class: 'panel-h' }, el('h2', {}, 'The whole signed manifest')), el('div', { class: 'panel-b' }, el('pre', {}, JSON.stringify(api.env, null, 2)))) : null,
    config ? panel('Configuration', el('div', { class: 'stack' }, el('pre', {}, JSON.stringify(config, null, 2)), el('button', { class: 'btn selfstart', onclick: () => { const a = el('a', { href: URL.createObjectURL(new Blob([JSON.stringify(config, null, 2)], { type: 'application/json' })), download: `${ctx.id}.world.json` }); a.click(); } }, 'Download configuration')), { note: 'Keep this file to run the same world anywhere.' }) : null);
}

async function tabDeveloper(ctx) {
  const rpc = sandbox() ? 'http://127.0.0.1:<anvil port>' : rpcUrl();
  const parts = [section('Developer', 'Run a test agent through this world, and reach it from the command line.')];
  const record = ctx.rec && !sandbox() ? { chainId: ctx.rec.chainId, rehearsal: false, id: ctx.rec.id, worldId: worldIdOf(ctx.rec.id), origin: ctx.rec.origin, cadence: ctx.rec.spec.cadence, fromBlock: ctx.rec.fromBlock, index: ctx.rec.index, role: ctx.rec.role, commits: ctx.rec.commits, keyRegistry: ctx.rec.keyRegistry } : null;
  const cli = panel('From the command line', el('div', { class: 'stack' },
    record ? [el('span', { class: 'label' }, 'Run it: this page deployed it, and your own machine runs it'), el('button', { class: 'btn selfstart', onclick: () => { el('a', { href: URL.createObjectURL(new Blob([JSON.stringify(record, null, 2)], { type: 'application/json' })), download: `deploy.${ctx.rec.chainId}.json` }).click(); } }, 'Download the deployment record'), command(`${CLI()} run ${ctx.id} --deploy deploy.${ctx.rec.chainId}.json --keys <your keys file>`)] : null,
    el('span', { class: 'label' }, 'What the chain says'), command(`${CLI()} status ${ctx.id} --rpc ${rpc}${S.cfg.index ? ` --index ${S.cfg.index}` : ''}`),
    el('span', { class: 'label' }, 'Check an item with only an RPC'), command(`${CLI()} verify --cite item.json --rpc ${rpc} --index ${S.cfg.index ?? '<WorldIndex>'}`),
    el('span', { class: 'label' }, 'Keep this world as code'), command(`${CLI()} create ${ctx.id} --name ${shellQuote(ctx.w?.name ?? ctx.id)} --spec ${ctx.id}.world.json`),
  ));
  if (!sandbox()) {
    fill(ctx.content, parts, panel('Test agent', el('div', { class: 'stack' }, el('p', { class: 'small muted' }, 'On this network an agent needs real ERC-8004 papers, so the tour runs from the command line, on a local chain.'), command(`${CLI()} try ${ctx.id}`))), cli);
    return;
  }
  const log = el('div', { class: 'log', id: 'w-log', 'aria-live': 'polite' }, 'Nothing yet.');
  const write = (s) => { if (log.textContent === 'Nothing yet.') log.textContent = ''; log.append(`${s}\n`); log.scrollTop = log.scrollHeight; };
  const agentId = String(1000 + Math.floor(Math.random() * 1_000_000));
  const others = S.worlds.filter((w) => w.id && w.id !== ctx.id && w.verified);
  const select = el('select', { id: 'w-home', 'aria-label': 'The world it leaves from' }, others.map((w) => el('option', { value: w.id }, w.name)));
  const tourBtn = el('button', { class: 'btn primary', id: 'w-tour', disabled: !others.length, onclick: async () => {
    tourBtn.disabled = true; log.textContent = ''; write(`A test agent, #${agentId}, with a new key, on a stand-in identity registry.`);
    await discoverWorlds().catch(() => {});
    const home = select.value;
    const api = await apiOf(ctx);
    const invite = async (id) => { const domain = { name: api.manifest.name, chainId: S.cfg.chainId, commits: api.manifest.commits.address }; const msg = operatorMessage(ctx.id, 'invite', { agentId: String(id) }, { nonce: rnd(), contract: api.manifest.commits.address }); const r = await postJson(`${api.url}/operator`, { msg, sig: await S.wallet.signTypedData(operatorTypedData(domain, msg)) }); if (r.code !== 200) write(`the invitation was refused: ${r.reason}`); };
    const r = await runTour({ urls: worldUrls(), home, target: ctx.id, agentId, pub: S.pub, index: S.cfg.index, identity: S.cfg.identity, setAgent: async (id, wallet) => { await postJson('/studio/agent', { agentId: id, wallet }); }, invite, key: generatePrivateKey(), log: write });
    write(`\n${r.ok ? 'PASS' : 'FAIL'}: ${r.steps.filter((s) => s.ok).length} of ${r.steps.length} steps; ${r.verified.filter((v) => v.ok).length} of ${r.verified.length} items verified from the chain alone.`);
    log.dataset.result = r.ok ? 'pass' : 'fail';
    tourBtn.disabled = false;
  } }, 'Run the tour');
  fill(ctx.content, parts, el('div', { class: 'split' },
    panel('Test run', log, { meta: el('span', { class: 'label' }, 'Local chain, test agent') }),
    panel('Send a test agent', el('div', { class: 'stack' }, el('p', { class: 'small muted' }, 'It leaves another world, comes here citing its departure, does what this world permits, leaves, and goes back. Each crossing waits for a period to be posted, so this takes about a minute. Every item is then re-checked from the chain alone.'),
      others.length ? field('It leaves from', select) : el('div', { class: 'notice warn' }, 'No other verified world to leave from yet. Wait for a period to post.'), tourBtn)),
  ), cli);
}

// ---- router ----------------------------------------------------------------------------------------------------------------------
function mount(nodes) { fill(app(), nodes); }
async function render() {
  for (const f of S.stops.splice(0)) f();
  const [, a, b, c] = (location.hash || '#/').split('/');
  every(8_000, tickBlock);
  try {
    if (a === 'new') viewNew();
    else if (a === 'world' && b) await viewWorld(decodeURIComponent(b), c || 'overview');
    else await viewHome();
  } catch (e) { mount(shell(el('div', { class: 'notice bad' }, errorText(e)))); }
  tickBlock();
  window.scrollTo?.(0, 0);
}
window.addEventListener('hashchange', render);
connect().then(render).catch((e) => fill(app(), el('p', { class: 'boot' }, `World Studio could not start: ${errorText(e)}`)));
