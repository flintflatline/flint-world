// THE GENESIS POLICY (docs/worlds-genesis.md): GRIFT's four founding worlds list free, once, on one WorldIndex, and everyone else pays.
// The text below is the policy. Its exact bytes are published at /genesis-policy.json and in docs/worlds/genesis-policy.json, the index
// holds their keccak256 as genesisPolicy(), and contracts/worldsdeploy/script/DeployIndex.s.sol holds the same hash: change a character
// and it is another policy, which that script refuses. No key and no network here, so a page can use it as the tools do.
import * as viem from 'viem';

export const GENESIS_TEXT = JSON.stringify({
  policy: 'GRIFT Worlds genesis listing policy',
  version: 1,
  date: '2026-10-30',
  chainId: 4663,
  worlds: ['sanverano', 'onestreet', 'portlumen', 'guildhouse'],
  operator: 'GRIFT',
  statement: 'GRIFT lists its four founding worlds on its WorldIndex on Robinhood Chain without burning the listing fee. GRIFT operates all four, and they paid nothing to be listed.',
  rules: [
    'It applies on one WorldIndex only: the address GRIFT publishes. That index names the keccak256 of this text as genesisPolicy(), and the four worldIds and one lister for each in its constructor. Nothing can add to them or change them afterwards.',
    'Each founding world\'s first listing names genesisMarker(worldId) as its feeBurnTx: keccak256(abi.encode(genesisPolicy, worldId, index, chainId)). It is not a transaction, and it says that no fee was burnt. Only that world\'s named lister may make that listing.',
    'It is good once. A founding world that is delisted and relisted pays the listing fee like any other.',
    'Every other world, on this index or on any other, pays the standard listing fee in full, by a real burn. Another index naming a genesis policy of its own exempts nobody.',
  ],
});
const policy = JSON.parse(GENESIS_TEXT);

export const GENESIS = Object.freeze({
  chainId: policy.chainId,
  worlds: Object.freeze(policy.worlds),
  text: GENESIS_TEXT,
  hash: viem.keccak256(viem.toBytes(GENESIS_TEXT)),
  // THE ONE INDEX IT APPLIES TO, pinned once `deploy` named it (2026-10-30), before the first listing. The launch tool refuses to list or
  // publish until it matches. No other index exempts anyone
  index: '0xc3BcC3b0a38fe6500880dC2C36BB7C88C5555487',
});
export const genesisWorldIds = () => GENESIS.worlds.map((w) => viem.keccak256(viem.toBytes(w)));
// what WorldIndex.genesisMarker answers, worked out here: keccak256(abi.encode(policy, worldId, index, chainId))
export const genesisMarkerOf = ({ worldId, index, chainId = GENESIS.chainId, policy: hash = GENESIS.hash }) => viem.keccak256(viem.encodeAbiParameters([{ type: 'bytes32' }, { type: 'bytes32' }, { type: 'address' }, { type: 'uint256' }], [hash, worldId, viem.getAddress(index), BigInt(chainId)]));
