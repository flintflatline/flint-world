// ONE WORLD ON THE TESTNET, FROM THE SDK ALONE (docs/worlds-sdk-guide.md; npx worldnew deploy --network testnet). The same steps as the guarded Foundry script (contracts/worldsdeploy
// DeployWorld.s.sol) and the same refusals, for a developer who has this package and not this repository: its operator owns both contracts, its signer and committer are other keys, and
// its first signer is active from the deployment, with every later one waiting the registry's 7 days. Mainnet is refused (operate.js deployProblem).
import * as viem from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import * as P from './protocol.js';
import { artifact, clientsFor } from './deployer.js';
import { COMMITS_ABI } from './chain.js';
import { INDEX_ABI, deployProblem, worldIdOf } from './operate.js';

const addr = (k) => privateKeyToAccount(k).address;
export async function deployWorldPublic({ rpc, chainId, id, keys, cadence, origin = null, base = null, index = null, burn = null, log = () => {} }) {
  const refused = deployProblem(chainId); if (refused) throw new Error(refused);
  const c = clientsFor(rpc, { chainId });
  const live = await c.pub.getChainId();
  if (live !== chainId) throw new Error(`that RPC is chain ${live}, not ${chainId}`);
  const operator = addr(keys.operator), signer = addr(keys.signer), committer = addr(keys.committer);
  if (signer === committer) throw new Error('the signer and the committer are one key: each gets its own');
  if (signer === operator || committer === operator) throw new Error('the operator is a world key: the owner of the contracts neither signs answers nor posts roots');
  const fromBlock = Number(await c.pub.getBlockNumber());
  const cc = artifact('worldlocal', 'CityCommitsV2.sol', 'CityCommitsV2'), kr = artifact('worldkeys', 'WorldKeyRegistry.sol', 'WorldKeyRegistry');
  const commits = await c.deploy(keys.operator, cc, [operator], `${id}: deploy CityCommitsV2`);
  log(`  CityCommitsV2 ${commits}`);
  for (const [s, n] of [[P.STREAM.records, 'records'], [P.STREAM.decisions, 'decisions'], [P.STREAM.manifest, 'manifest']]) await c.write(keys.operator, commits, COMMITS_ABI, 'addStream', [BigInt(s), n, cadence, committer], `${id}: addStream ${s} ${n}`);
  const keyRegistry = await c.deploy(keys.operator, kr, [operator, [viem.keccak256(viem.toBytes(P.ROLE_NAME))], [signer]], `${id}: deploy its key registry`);
  log(`  key registry ${keyRegistry}`);
  let listing = null;
  if (index) {
    const uri = `${String(origin).replace(/\/$/, '')}${base}/.well-known/world.json`;
    const fee = burn || viem.keccak256(viem.toBytes(`no listing burn on chain ${chainId} for ${id}`));
    const tx = await c.write(keys.operator, index, INDEX_ABI, 'list', [worldIdOf(id), uri, commits, keyRegistry, fee], `${id}: WorldIndex.list`);
    listing = { tx, uri, feeBurnTx: fee };
    log(`  listed at ${uri}`);
  }
  return { chainId, id, worldId: worldIdOf(id), origin, cadence, fromBlock, index, role: P.ROLE_NAME, commits, keyRegistry, operator, signer, committer, listing, txs: c.txs };
}
