// AN AGENT THAT TRAVELS (docs/worlds-sdk.md, "the journey"). The same code for every agent: no world, job or address in
// it. It learns where it may go from discovery (WorldIndex on chain, each world's manifest and contract checked), what
// work there is from each offered world's own `jobs` read joined to WorldJobs and WorldSettlement on chain, and how to
// sign from each world's manifest (its name and chain make the EIP-712 domain). Its decision is its decider's
// (js/worlds/decide.js: the city's model, or the labelled deterministic test policy); its every step is logged.
import { privateKeyToAccount } from 'viem/accounts';
import { randomBytes } from 'node:crypto';
import * as viem from 'viem';
import * as P from './protocol.js';
import { jobSpec, specHashOf } from './templates/jobs.js';
import { deterministicDecide, modelDecide, isUnpaid } from './decide.js';

const rnd = () => '0x' + randomBytes(32).toString('hex');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

export function worldAgent({ name, agentId, key, home = 'sanverano', discover, market = null, decider = 'deterministic', run = null, residentFacts = async () => ({}), log = () => {}, trace = null, patienceMs = 120_000 }) {
  const acct = privateKeyToAccount(key);
  let seen = null;
  const note = (step) => { const s = { at: new Date().toISOString(), agent: name, agentId: String(agentId), ...step }; trace?.push(s); log(`  [${name}] ${step.what}${step.world ? ` @ ${step.world}` : ''}${step.result ? `: ${step.result}` : ''}`); return s; };
  const get = async (url) => { const r = await fetch(url); return { code: r.status, ...(await r.json()) }; };
  const post = async (url, body) => { const r = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return { code: r.status, ...(await r.json()) }; };
  const domainOf = (w) => ({ name: w.name, chainId: Number(seen.chainId), commits: w.commits });
  const worldOf = (id) => { const w = seen?.worlds.find((x) => x.id === id); if (!w) throw new Error(`${id} is not a world discovery returned`); return w; };

  const self = {
    name, agentId: String(agentId), address: acct.address, key,
    // where it may go: discovery, never a list
    async discover() {
      const d = await discover();
      if (seen && d.asOf.block < seen.asOf.block) throw new Error(`discovery answered from block ${d.asOf.block}, older than the ${seen.asOf.block} already trusted`);
      seen = d;
      note({ what: 'discovered worlds through WorldIndex', result: d.worlds.map((w) => `${w.id} ${w.status}${w.offered ? ' offered' : ` not offered (${w.why[0] || ''})`}`).join('; '), block: d.asOf.block });
      return d;
    },
    // what work there is: each offered world that serves a `jobs` read, joined to the chain
    async jobs() {
      const out = [];
      const onChain = market ? await market.offers() : [];
      for (const w of seen.worlds.filter((x) => x.offered && x.id !== home && (x.ops || []).includes('jobs'))) {
        let list; try { list = await get(`${w.api}/jobs`); } catch { continue; }
        for (const j of list.jobs || []) {
          const c = onChain.find((x) => x.jobId === String(j.chainJobId));
          const spec = jobSpec(w.id, { id: j.id, title: j.title, target: j.target, pay: j.pay, payToken: j.payToken, hours: j.hours });
          out.push({ world: w.id, worldName: w.name, id: j.id, title: j.title, task: j.task, target: j.target, pay: j.pay, payToken: j.payToken, hours: j.hours, chainJobId: j.chainJobId, specHash: j.specHash,
            specHashOk: !!c && specHashOf(spec) === c.specHash && c.worldId === viem.keccak256(viem.toBytes(w.id)), onChain: c ? { status: c.status, acceptBy: c.acceptBy, doneBy: c.doneBy, pay: c.pay } : null, funded: c?.escrow?.state === 'HELD' && c.escrow.amount === c.pay, worldStatus: j.status });
        out[out.length - 1].unpaid = isUnpaid(out[out.length - 1]);
        }
      }
      note({ what: 'read the jobs offered', result: out.map((j) => `${j.world}/${j.id} ${j.unpaid ? 'pays nothing (a record only)' : `pays ${viem.formatEther(BigInt(j.pay))} WTEST`}, chain job ${j.chainJobId} ${j.onChain?.status || 'not on chain'}${j.funded ? ', funded' : ''}`).join('; ') || 'none' });
      return out;
    },
    // decide on each, by its decider; returns the verdicts and the best job it would take
    async weigh(offers) {
      const facts = await residentFacts();
      const nowSec = market ? await market.chainNow() : Math.floor(Date.now() / 1000);
      const verdicts = [];
      for (const o of offers) {
        const offer = { ...o, pay: viem.formatEther(BigInt(o.pay)), hours: Number(o.hours ?? 24) };
        const world = worldOf(o.world);
        const args = { offer, world, resident: facts, nowSec, testToken: market?.d.token };
        const v = decider === 'model' ? await modelDecide({ ...args, run }) : deterministicDecide(args);
        verdicts.push({ job: `${o.world}/${o.id}`, chainJobId: o.chainJobId, ...v });
        note({ what: `weighed ${o.world}/${o.id}`, world: o.world, decider: v.kind, label: v.label, result: `${v.take ? 'TAKE' : 'decline'}: ${v.reason}`, reservation: v.reservation });
      }
      // the best pay; between equal pay (every job, where nothing pays) the least time away, then the first offered
      const offerOf = (v) => offers.find((o) => o.chainJobId === v.chainJobId);
      const take = verdicts.filter((v) => v.take).sort((x, y) => { const a = offerOf(x), b = offerOf(y), dp = BigInt(b.pay) - BigInt(a.pay); return dp > 0n ? 1 : dp < 0n ? -1 : Number(a.hours ?? 24) - Number(b.hours ?? 24) || Number(a.chainJobId) - Number(b.chainJobId); })[0] || null;
      return { verdicts, take: take ? offers.find((o) => o.chainJobId === take.chainJobId) : null };
    },
    async join(worldId, nameAs, from = null) {
      const w = worldOf(worldId);
      const j = { agentId: String(agentId), world: w.id, name: nameAs, challenge: rnd(), ts: Date.now() };
      const cite = from ? (({ served, ...c }) => (void served, c))(from) : null;
      const r = await post(`${w.api}/join`, { join: j, sig: await acct.signTypedData(P.joinTypedData(domainOf(w), j)), ...(cite ? { from: cite } : {}) });
      note({ what: from ? `joined, citing its departure from ${from.world}` : 'joined', world: w.id, result: `${r.code} ${r.presence || r.reason || ''}`, item: r.item || null, decision: r.decision || null, att: r.att ? { signer: r.att.signer, label: r.att.label } : null });
      return r;
    },
    async request(worldId, op, extra = {}) {
      const w = worldOf(worldId);
      const msg = JSON.stringify({ v: 1, op, world: w.id, agentId: String(agentId), ts: Date.now(), nonce: rnd(), ...extra });
      const r = await post(`${w.api}/${op}`, { msg, sig: await acct.signTypedData(P.requestTypedData(domainOf(w), msg)) });
      note({ what: op, world: w.id, result: `${r.code} ${r.code >= 400 ? r.reason : (r.presence || (r.items || []).map((i) => i.kind).join(', ') || 'ok')}`, items: r.items || (r.item ? [r.item] : []), decision: r.decision || null });
      return r;
    },
    leave: (worldId) => self.request(worldId, 'leave'),
    // a record item of anyone's, as its world serves it for citing (posted, with its proof), or null while it is not. The
    // cite is the protocol's { world, contract, stream, epoch, leaf, proof, itemText }; the item as served (with its verify
    // and label) rides beside it as `served`, never as `item`, which a world would hash in place of itemText
    async citable(worldId, whoAgentId, kind) {
      const w = worldOf(worldId);
      const rec = await get(`${w.api}/record?agentId=${whoAgentId}`);
      const it = (rec.items || []).filter((x) => x.kind === kind).pop();
      if (!it?.verify?.proof || !it.verify.posted || it.verify.posted.unpostable) return null;
      return { world: w.id, contract: it.verify.contract, stream: P.STREAM.records, epoch: it.verify.epoch, leaf: it.verify.leaf, proof: it.verify.proof, itemText: it.verify.canonical, served: it };
    },
    async waitCitable(worldId, whoAgentId, kind, ms = patienceMs) {
      const until = Date.now() + ms;
      for (;;) { const c = await self.citable(worldId, whoAgentId, kind); if (c) return c; if (Date.now() > until) throw new Error(`${kind} of ${whoAgentId} in ${worldId} was not posted in time`); await sleep(2500); }
    },
    // the job: accept on chain (its own wallet), take it in the world, do the audit
    async acceptOnChain(job) {
      const t = await market.accept(key, job.chainJobId, agentId);
      note({ what: `accepted chain job ${job.chainJobId} on WorldJobs`, world: job.world, tx: t.tx, block: t.block, gasUsed: t.gasUsed, result: t.events.map((e) => e.event).join(', ') });
      return t;
    },
    async audit(job) {
      const t = job.target;
      const cite = await self.citable(t.world, t.agentId, t.kind);
      if (!cite) throw new Error(`the target ${t.world}/${t.agentId}/${t.kind} is not posted yet`);
      note({ what: `fetched the audit target from ${t.world}'s own record feed`, world: t.world, result: `${t.kind} of agent ${t.agentId}, epoch ${cite.epoch}, leaf ${cite.leaf.slice(0, 18)}…` });
      const { served, ...result } = cite; void served;
      return self.request(job.world, 'audit', { jobId: job.id, result });
    },
    async release(job) {
      const t = await market.release(key, job.chainJobId);
      note({ what: `released chain job ${job.chainJobId}'s escrow`, tx: t.tx, block: t.block, gasUsed: t.gasUsed, result: t.events.map((e) => `${e.event}${e.args?.amount != null ? ` ${viem.formatEther(e.args.amount)} WTEST to ${e.args.payee || e.args.to}` : ''}`).join(', ') });
      return t;
    },
  };
  return self;
}
