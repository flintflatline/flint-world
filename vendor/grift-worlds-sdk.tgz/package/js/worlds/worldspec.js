// A WORLD AS DATA (docs/world-deployer.md). What a developer configures to get an independent world without writing a hook: its
// identity, its places, who it admits, what an agent may do there, what it credits and what a departure reports. The CLI
// (tools/worldnew.mjs), the frontend (js/worlds/studio) and the template (js/worlds/templates/policy.js) all read this one
// file, so what a form accepts is what the world runs. It imports nothing: it runs in a browser as it does on a server.
//
//   normalizeSpec(input)   the whole spec, every default filled in
//   specProblems(input)    [{ field, problem }]: empty when the spec is a world
//   rulesOf(spec)          the rules in words, as the manifest states them
//   codesOf(spec)          every refusal code the world's hooks use, and the rule it applies
//
// A DEPARTURE CANNOT BE REFUSED: leaving is the engine's (conformance rule 10), so a departure policy says only what the
// world reports about an agent as it goes, and how soon that agent may come back.
export const SPEC_VERSION = 1;
export const ADMISSION_MODES = Object.freeze(['open', 'travellers', 'invited']);
export const TASK_PROOFS = Object.freeze(['attested', 'foreign-item']);
// what a task or a credential may cite: items any world of this protocol seals about an agent
export const CITABLE_KINDS = Object.freeze(['arrived', 'returned', 'departed', 'job.completed', 'task.completed', 'world.credential', 'guild.credential']);
export const BUILT_IN_IDS = Object.freeze(['sanverano', 'onestreet']);
// the four founding worlds of the mainnet index: their ids are named on it, for good, each to one lister (docs/worlds-genesis.md)
export const FOUNDING_IDS = Object.freeze(['sanverano', 'onestreet', 'portlumen', 'guildhouse']);
const MAX = Object.freeze({ capacity: 10_000, cooldown: 30 * 86_400, tasks: 20, worlds: 50, cadenceMin: 30, cadenceMax: 86_400 });

const WORLD_ID = /^[a-z0-9]{3,24}$/;
const TASK_ID = /^[a-z][a-z0-9-]{1,30}$/;
const PLACE = /^[a-z][a-z -]{1,23}$/;
// words a manifest states and a page shows: plain words, no markup, no links
// eslint-disable-next-line no-control-regex
const plain = (s) => typeof s === 'string' && !/[<>{}\\\u0000-\u001f\u007f\u2028\u2029]|https?:/i.test(s);
// a task or credential id is a key in stored state: nothing an object already answers to
const RESERVED_KEYS = Object.freeze(['constructor', 'prototype', 'hasOwnProperty', 'toString', 'valueOf']);
const strings = (v) => (Array.isArray(v) ? v.map(String) : []);
const orNull = (v) => (v && typeof v === 'object' ? v : null);

export function normalizeSpec(input = {}) {
  const s = input && typeof input === 'object' ? input : {};
  const id = String(s.id ?? '');
  const admission = orNull(s.admission) || {};
  const departure = orNull(s.departure) || {};
  const notes = orNull(s.notes) || {};
  const creds = orNull(s.credentials) || {};
  const issue = orNull(creds.issue);
  const accept = orNull(creds.accept);
  return {
    specVersion: SPEC_VERSION,
    template: 'policy',
    id,
    name: String(s.name ?? ''),
    about: String(s.about ?? ''),
    base: s.base ?? `/${id}`,
    api: s.api ?? `/api/worlds/${id}`,
    cadence: s.cadence == null || s.cadence === '' ? 30 : Number(s.cadence),
    capacity: s.capacity == null || s.capacity === '' ? 16 : Number(s.capacity),
    placeName: String(s.placeName ?? 'place'),
    admission: {
      mode: String(admission.mode ?? 'open'),
      allowFrom: strings(admission.allowFrom),
      denyFrom: strings(admission.denyFrom),
      returnCooldownSeconds: admission.returnCooldownSeconds == null || admission.returnCooldownSeconds === '' ? 0 : Number(admission.returnCooldownSeconds),
      // A DEPARTURE IS ONE CROSSING: by default it admits an agent here once, so an old departure cannot be replayed to walk back in
      departureOnce: admission.departureOnce !== false,
      departureMaxAgeSeconds: admission.departureMaxAgeSeconds == null || admission.departureMaxAgeSeconds === '' ? 0 : Number(admission.departureMaxAgeSeconds),
    },
    departure: { reportActivity: departure.reportActivity !== false, reportCredentials: departure.reportCredentials !== false },
    notes: { enabled: notes.enabled !== false, maxWords: notes.maxWords == null ? 10 : Number(notes.maxWords), maxChars: notes.maxChars == null ? 120 : Number(notes.maxChars) },
    tasks: (Array.isArray(s.tasks) ? s.tasks : []).map((t) => ({
      id: String(t?.id ?? ''),
      title: String(t?.title ?? ''),
      proof: String(t?.proof ?? 'attested'),
      kinds: t?.proof === 'foreign-item' ? strings(t?.kinds).length ? strings(t.kinds) : ['departed'] : [],
      subject: t?.proof === 'foreign-item' ? String(t?.subject ?? 'self') : 'self',
      fromWorlds: t?.proof === 'foreign-item' ? strings(t?.fromWorlds) : [],
    })),
    credentials: {
      issue: issue ? { id: String(issue.id ?? ''), title: String(issue.title ?? ''), requiresTasks: strings(issue.requiresTasks) } : null,
      accept: accept ? { kinds: strings(accept.kinds), fromWorlds: strings(accept.fromWorlds) } : null,
    },
    ...(s.generatedBy ? { generatedBy: String(s.generatedBy) } : {}),
  };
}

export function specProblems(input) {
  const s = normalizeSpec(input);
  const out = [];
  const no = (field, problem) => out.push({ field, problem });
  const worldList = (field, ids) => {
    if (ids.length > MAX.worlds) no(field, `at most ${MAX.worlds} worlds`);
    for (const w of ids) if (!WORLD_ID.test(w)) no(field, `${w.slice(0, 30)} is not a world id`);
    if (new Set(ids).size !== ids.length) no(field, 'a world is named twice');
  };
  if (!WORLD_ID.test(s.id)) no('id', 'an id is 3 to 24 of a-z and 0-9');
  else if (BUILT_IN_IDS.includes(s.id)) no('id', `${s.id} is a built-in world`);
  if (s.name.length < 2 || s.name.length > 40) no('name', 'a name is 2 to 40 characters');
  else if (!plain(s.name)) no('name', 'a name is plain words: no markup, no links');
  if (s.about.length > 160) no('about', 'at most 160 characters');
  else if (!plain(s.about)) no('about', 'plain words: no markup, no links');
  if (typeof s.base !== 'string' || !/^(\/[a-z0-9-]+)*$/.test(s.base)) no('base', 'a path like /myworld');
  if (typeof s.api !== 'string' || !/^\/[a-z0-9/-]+$/.test(s.api)) no('api', 'a path like /api/worlds/myworld');
  if (!Number.isInteger(s.cadence) || s.cadence < MAX.cadenceMin || s.cadence > MAX.cadenceMax) no('cadence', `${MAX.cadenceMin} to ${MAX.cadenceMax} whole seconds per period`);
  if (!Number.isInteger(s.capacity) || s.capacity < 1 || s.capacity > MAX.capacity) no('capacity', `1 to ${MAX.capacity} places`);
  if (!PLACE.test(s.placeName)) no('placeName', '2 to 24 lowercase letters, like berth or reading desk');
  if (!ADMISSION_MODES.includes(s.admission.mode)) no('admission.mode', `one of ${ADMISSION_MODES.join(', ')}`);
  worldList('admission.allowFrom', s.admission.allowFrom);
  worldList('admission.denyFrom', s.admission.denyFrom);
  if (s.admission.allowFrom.some((w) => s.admission.denyFrom.includes(w))) no('admission.denyFrom', 'a world cannot be both allowed and refused');
  if (s.admission.allowFrom.includes(s.id)) no('admission.allowFrom', 'an agent cannot arrive from this world itself');
  const cool = s.admission.returnCooldownSeconds;
  if (!Number.isInteger(cool) || cool < 0 || cool > MAX.cooldown) no('admission.returnCooldownSeconds', `0 to ${MAX.cooldown} whole seconds`);
  const age = s.admission.departureMaxAgeSeconds;
  if (!Number.isInteger(age) || age < 0 || age > 365 * 86_400) no('admission.departureMaxAgeSeconds', `0 to ${365 * 86_400} whole seconds`);
  if (!Number.isInteger(s.notes.maxWords) || s.notes.maxWords < 1 || s.notes.maxWords > 50) no('notes.maxWords', '1 to 50 words');
  if (!Number.isInteger(s.notes.maxChars) || s.notes.maxChars < 10 || s.notes.maxChars > 280) no('notes.maxChars', '10 to 280 characters');
  if (s.tasks.length > MAX.tasks) no('tasks', `at most ${MAX.tasks} tasks`);
  const taskIds = s.tasks.map((t) => t.id);
  if (new Set(taskIds).size !== taskIds.length) no('tasks', 'two tasks share an id');
  s.tasks.forEach((t, i) => {
    const at = `tasks.${i}`;
    if (!TASK_ID.test(t.id) || RESERVED_KEYS.includes(t.id)) no(`${at}.id`, 'a task id is 2 to 31 of a-z, 0-9 and -, starting with a letter');
    if (t.title.length < 2 || t.title.length > 80) no(`${at}.title`, 'a title is 2 to 80 characters');
    else if (!plain(t.title)) no(`${at}.title`, 'plain words: no markup, no links');
    if (!TASK_PROOFS.includes(t.proof)) no(`${at}.proof`, `one of ${TASK_PROOFS.join(', ')}`);
    if (t.proof === 'foreign-item') {
      for (const k of t.kinds) if (!CITABLE_KINDS.includes(k)) no(`${at}.kinds`, `${k.slice(0, 30)} is not an item this protocol's worlds seal`);
      if (!['self', 'any'].includes(t.subject)) no(`${at}.subject`, 'self or any');
      worldList(`${at}.fromWorlds`, t.fromWorlds);
    }
  });
  const { issue, accept } = s.credentials;
  if (issue) {
    if (!TASK_ID.test(issue.id)) no('credentials.issue.id', 'a credential id is 2 to 31 of a-z, 0-9 and -, starting with a letter');
    if (issue.title.length < 2 || issue.title.length > 80) no('credentials.issue.title', 'a title is 2 to 80 characters');
    else if (!plain(issue.title)) no('credentials.issue.title', 'plain words: no markup, no links');
    if (!issue.requiresTasks.length) no('credentials.issue.requiresTasks', 'a credential is earned by at least one task');
    for (const t of issue.requiresTasks) if (!taskIds.includes(t)) no('credentials.issue.requiresTasks', `${t.slice(0, 30)} is not one of this world's tasks`);
  }
  if (accept) {
    if (!accept.kinds.length) no('credentials.accept.kinds', 'name at least one kind of item');
    for (const k of accept.kinds) if (!CITABLE_KINDS.includes(k)) no('credentials.accept.kinds', `${k.slice(0, 30)} is not an item this protocol's worlds seal`);
    worldList('credentials.accept.fromWorlds', accept.fromWorlds);
  }
  return out;
}

const list = (ids) => ids.join(', ');
export function rulesOf(input) {
  const s = normalizeSpec(input);
  const { mode, allowFrom, denyFrom, returnCooldownSeconds: cool, departureOnce, departureMaxAgeSeconds: maxAge } = s.admission;
  const door = mode === 'travellers' ? 'no walk-ins: an agent joins only citing its departure from another world of this protocol, checked on that world\'s contract'
    : mode === 'invited' ? 'by invitation: an agent joins only once this world\'s operator has invited its agentId'
      : 'open to any agent with papers';
  const origin = [allowFrom.length ? `a departure cited here is from one of: ${list(allowFrom)}` : '', denyFrom.length ? `a departure from these worlds is refused: ${list(denyFrom)}` : '', departureOnce ? 'each departure admits an agent here once' : '', maxAge ? `a departure cited here was posted within the last ${maxAge} seconds, by the chain's clock` : ''].filter(Boolean).join('; ');
  const { issue, accept } = s.credentials;
  return {
    door: origin ? `${door}; ${origin}` : door,
    places: `one ${s.placeName} per agent present, ${s.capacity} in all; leaving frees it`,
    operator: 'the owner of this world\'s contracts may close the door, refuse an agent and post a notice; each such act is signed by that owner and sealed in stream 1 as the operator\'s say',
    departure: `leaving is always allowed; the standing this world reports as an agent goes is this world's say${s.departure.reportActivity ? ', and counts what it did here' : ''}${s.departure.reportCredentials ? ', and names its credentials' : ''}`,
    ...(cool ? { return: `an agent that left comes back after at least ${cool} seconds` } : {}),
    ...(s.notes.enabled ? { notes: `an agent present may leave a note of plain words (at most ${s.notes.maxWords} words, ${s.notes.maxChars} characters); a note is the agent's say, sealed as a claim` } : {}),
    ...(s.tasks.length ? { tasks: `the tasks here: ${s.tasks.map((t) => `${t.id} (${t.proof === 'foreign-item' ? `proven by citing ${t.subject === 'any' ? 'an' : 'the agent\'s own'} ${t.kinds.join(' or ')} item from ${t.fromWorlds.length ? list(t.fromWorlds) : 'another world'}, checked on its contract: a fact where that item is one` : 'attested by this world: its claim'})`).join('; ')}` } : {}),
    ...(issue ? { credential: `${issue.id} is issued once to an agent that has completed ${list(issue.requiresTasks)}; it is a fact where every one of those tasks was proven on chain, and otherwise this world's claim` } : {}),
    ...(accept ? { accept: `an agent present may present ${accept.kinds.join(' or ')} items of its own from ${accept.fromWorlds.length ? list(accept.fromWorlds) : 'any other world this one knows'}, checked on that world's contract; each item counts once, ever` } : {}),
  };
}

export function codesOf(input) {
  const s = normalizeSpec(input);
  return {
    DOOR_CLOSED: 'door', AGENT_REFUSED: 'door', WALKIN_REFUSED: 'door', NOT_INVITED: 'door', ORIGIN_REFUSED: 'door', DEPARTURE_REFUSED: 'door',
    PLACES_FULL: 'places',
    ...(s.admission.returnCooldownSeconds ? { RETURN_TOO_SOON: 'return' } : {}),
    ...(s.notes.enabled ? { NOTE_REFUSED: 'notes' } : {}),
    ...(s.tasks.length ? { NO_SUCH_TASK: 'tasks', TASK_DONE: 'tasks', TASK_REFUSED: 'tasks' } : {}),
    ...(s.credentials.issue ? { NOT_EARNED: 'credential', ALREADY_ISSUED: 'credential' } : {}),
    ...(s.credentials.accept ? { CREDENTIAL_REFUSED: 'accept' } : {}),
    OPERATOR_REFUSED: 'operator',
  };
}

// the same plain-words check the template applies to what an agent or the operator writes
export function wordsProblem(line, { maxWords = 40, maxChars = 280 } = {}) {
  if (typeof line !== 'string' || !line.trim()) return 'it is words';
  if (line.length > maxChars) return `at most ${maxChars} characters`;
  if (line.trim().split(/\s+/).length > maxWords) return `at most ${maxWords} words`;
  if (!plain(line)) return 'plain words: no markup, no links';
  return null;
}
