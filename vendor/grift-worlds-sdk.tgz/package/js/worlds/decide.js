// SHOULD THIS RESIDENT TAKE THAT JOB? (docs/worlds-sdk.md, "the journey"). A resident of San Verano weighs a job another
// world offers, found through the index (js/worlds/discovery.js), against what it would give up. Two deciders, never
// confused with each other; every verdict says which one made it:
//
//   kind 'model'          the city's own model path (api/ai.js runAgentJSON, persona `worldjob`): the resident's planner
//                         reads the offer as data and answers { take, reason, minPay }. Runs only where the city's model
//                         runs (AI_ENABLED and a key); otherwise the verdict says it could not run, and nothing is taken.
//   kind 'deterministic'  a stated policy, for tests and for any run without a model: the same inputs, the same arithmetic,
//                         every time. It is labelled a test agent's policy everywhere it appears.
//
// THE CONSTRAINTS bind both: whatever the model says, a job is never taken when its world is not offered by discovery
// (verified, fresh, LISTED or STALE), when its escrow is not funded on WorldSettlement, when it pays in anything but the
// local test token, when it pays less than the resident's reservation wage for the time away, or when its deadline leaves
// no time for the trip. The model may decline what the constraints allow; it can never accept what they forbid.
//
// A JOB THAT PAYS NOTHING (a chain with no WorldSettlement, docs/worlds-mainnet.md: pay 0 on WorldJobs and no token in its spec)
// is work for the record alone. There is no escrow to check and no wage it could beat, so the rule is the time: it may keep an
// agent away at most maxUnpaidHours. A job that names any pay on a chain with no test token still fails the constraints above:
// no agent here ever takes work for a real token.
export const DECIDERS = ['model', 'deterministic'];
export const POLICY = Object.freeze({ dayHours: 24, minHoursToDeadline: 1, riskPremiumBps: 2000, staleWorldPremiumBps: 3000, minPay: 1, maxUnpaidHours: 24 });
export const isUnpaid = (offer) => !offer.payToken && Number(offer.pay) === 0 && String(offer.onChain?.pay ?? '0') === '0';

// the resident's reservation wage for a trip of `hours`: what it earns in the city in that time, plus a premium for the
// risk (more when the world is STALE). Earnings are its own recent average (cash per city day)
export function reservationWage({ dailyEarnings = 0, hours = 24, worldStatus = 'LISTED' } = {}) {
  const base = Math.max(0, Number(dailyEarnings)) * (Number(hours) / POLICY.dayHours);
  const premium = POLICY.riskPremiumBps + (worldStatus === 'STALE' ? POLICY.staleWorldPremiumBps : 0);
  return Math.max(POLICY.minPay, Math.ceil(base * (10_000 + premium) / 10_000));
}

// the hard constraints: a list of reasons the job may not be taken (empty: it may)
export function constraintsFor({ offer, world, resident, nowSec, testToken }) {
  const out = [];
  if (!world?.offered) out.push(`${world?.id || offer.world} is not offered by discovery (${(world?.why || []).join('; ') || 'not found'})`);
  if (offer.onChain?.status !== 'OPEN') out.push(`the job is ${offer.onChain?.status || 'not on chain'} on WorldJobs`);
  if (isUnpaid(offer)) {
    if (offer.specHashOk === false) out.push('the world\'s spec does not hash to what WorldJobs holds');
    const hoursLeft = (Number(offer.onChain?.acceptBy || 0) - nowSec) / 3600;
    if (hoursLeft < POLICY.minHoursToDeadline) out.push('it must be accepted within the hour');
    const away = Number(offer.hours ?? 24);
    if (away > POLICY.maxUnpaidHours) out.push(`it pays nothing and keeps the agent away ${away} hours, more than the ${POLICY.maxUnpaidHours} this policy gives work for the record alone`);
    return { reasons: out, reservation: 0, unpaid: true };
  }
  if (!offer.funded) out.push('its escrow is not funded on WorldSettlement');
  if (!testToken || String(offer.payToken || '').toLowerCase() !== String(testToken).toLowerCase()) out.push('it does not pay in the local test token');
  if (offer.specHashOk === false) out.push('the world\'s spec does not hash to what WorldJobs holds');
  const hoursLeft = (Number(offer.onChain?.acceptBy || 0) - nowSec) / 3600;
  if (hoursLeft < POLICY.minHoursToDeadline) out.push('it must be accepted within the hour');
  const need = reservationWage({ dailyEarnings: resident.dailyEarnings, hours: offer.hours || 24, worldStatus: world?.status });
  if (Number(offer.pay) < need) out.push(`it pays ${offer.pay}, under the reservation wage of ${need} for ${offer.hours || 24} hours away`);
  return { reasons: out, reservation: need };
}

export function deterministicDecide({ offer, world, resident, nowSec, testToken }) {
  const c = constraintsFor({ offer, world, resident, nowSec, testToken });
  const take = c.reasons.length === 0;
  return { kind: 'deterministic', label: 'deterministic test agent: a stated policy (js/worlds/decide.js), not a model', take, reason: take ? (c.unpaid ? `pays nothing and keeps it away ${offer.hours ?? 24} hours: work for the record alone; the world is offered and the job open` : `pays ${offer.pay}, over the reservation wage of ${c.reservation}; the world is offered and the escrow funded`) : c.reasons[0], reservation: c.reservation, constraints: c.reasons, ...(c.unpaid ? { unpaid: true } : {}) };
}

// the model's verdict, clamped by the constraints. `run` is api/ai.js runAgentJSON (passed in, so this file stays pure)
export async function modelDecide({ offer, world, resident, nowSec, testToken, run }) {
  const c = constraintsFor({ offer, world, resident, nowSec, testToken });
  const context = {
    resident: { name: resident.name, trade: resident.trade, dailyEarnings: resident.dailyEarnings, cash: resident.cash },
    offer: { world: world?.name || offer.world, title: offer.title, task: offer.task, pay: offer.pay, token: c.unpaid ? 'none: this job pays nothing, its reward is the sealed record' : 'local test token (no value)', hours: offer.hours || 24, acceptByIso: new Date(Number(offer.onChain?.acceptBy || 0) * 1000).toISOString() },
    world: { status: world?.status, fresh: !!world?.fresh, verified: !!world?.verified },
    reservationWage: c.reservation,
  };
  let r;
  try { r = await run('worldjob', context, { maxTokens: 300 }); } catch (e) { r = { ok: false, error: String(e?.message || e) }; }
  if (!r?.ok) return { kind: 'model', label: 'model-driven: the city\'s planner model (api/ai.js persona worldjob)', ran: false, take: false, reason: `the model did not run (${String(r?.error || 'no answer').slice(0, 80)}); nothing is taken`, reservation: c.reservation, constraints: c.reasons };
  const said = r.data || {};
  const wants = said.take === true;
  const take = wants && c.reasons.length === 0;
  return { kind: 'model', label: 'model-driven: the city\'s planner model (api/ai.js persona worldjob)', ran: true, take, reason: !wants ? String(said.reason || 'declined').slice(0, 200) : take ? String(said.reason || 'accepted').slice(0, 200) : `the model would take it, but ${c.reasons[0]}`, said: { take: said.take, reason: String(said.reason || '').slice(0, 200), minPay: said.minPay ?? null }, reservation: c.reservation, constraints: c.reasons, costMicros: r.costMicros ?? null };
}
