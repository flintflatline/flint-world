// A STORE THAT SURVIVES A RESTART, FOR A RUN ON A REAL CHAIN (docs/worlds-testnet.md). The worlds' sealed records and
// epochs live in their store, and on a real chain a run has phases days apart, so they must outlast the process: this is
// the in-memory store written to one JSON file (atomically, after every commit). It holds what the worlds serve publicly,
// never a key. ONE PROCESS AT A TIME: two writers would seal different epochs and post different roots, and a root is for ever,
// so a second process on the same file is refused (a lock file naming the holder; one left by a dead process is taken over).
import { readFileSync, writeFileSync, renameSync, existsSync, mkdirSync, openSync, closeSync, unlinkSync } from 'node:fs';
import { dirname } from 'node:path';
import { MemoryStore } from '../econ/store.js';

const alive = (pid) => { try { process.kill(pid, 0); return true; } catch (e) { return e.code === 'EPERM'; } };
function takeLock(path) {
  const lock = `${path}.lock`;
  mkdirSync(dirname(lock), { recursive: true });
  for (let i = 0; i < 3; i++) {
    try {
      const fd = openSync(lock, 'wx');
      writeFileSync(fd, String(process.pid));
      closeSync(fd);
      process.once('exit', () => { try { if (readFileSync(lock, 'utf8') === String(process.pid)) unlinkSync(lock); } catch { /* gone */ } });
      return;
    } catch (e) {
      if (e.code !== 'EEXIST') throw e;
      const holder = Number(readFileSync(lock, 'utf8'));
      if (holder === process.pid) return;
      if (holder && alive(holder)) throw new Error(`${path} is in use by process ${holder}: one process at a time writes a world's records`);
      try { unlinkSync(lock); } catch { /* another took it */ }
    }
  }
  throw new Error(`could not take the lock on ${path}`);
}

export class FileStore extends MemoryStore {
  constructor(path) {
    super();
    this.path = path; this.kind = 'file';
    takeLock(path);
    if (existsSync(path)) for (const [k, v] of Object.entries(JSON.parse(readFileSync(path, 'utf8')))) this.map.set(k, v);
  }
  async commit(reads = [], writes = [], opts = {}) {
    const out = await super.commit(reads, writes, opts);
    this.save();
    return out;
  }
  save() {
    mkdirSync(dirname(this.path), { recursive: true });
    const tmp = `${this.path}.tmp`;
    writeFileSync(tmp, JSON.stringify(Object.fromEntries(this.map)));
    renameSync(tmp, this.path);
  }
}
