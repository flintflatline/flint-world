// THE WORLDS' CHAIN, BEHIND ONE SMALL INTERFACE (docs/worlds-v0.md). Two implementations:
//   viemChain(viem, { rpc })   the real one: Robinhood Chain over its public RPC (or any RPC), viem passed in so the
//                              browser can hand it the copy it loads and the server the one it imports
//   memoryChain()              CityCommitsV2, KeyRegistry and the ERC-8004 registry's reads, in memory, with the same
//                              rules (append-only per stream, epochs strictly increasing, the far-future bound, the
//                              committer check, the 7-day genesis). For tests and the local frames ONLY: api/_worlds.js
//                              refuses it on a production deployment.
//
// the interface, every method async:
//   commitOf(contract, stream, epoch)         { root, count, postedAt }   (root 0x00…0 when nothing is posted)
//   verify(contract, stream, epoch, leaf, proof)  the contract's own verify()
//   streamOf(contract, stream)                { name, cadence, committer, latestEpoch, commitCount }
//   postBatch({ contract, key, entries })     entries [{ stream, epoch, root, count }] in one commitBatch → { tx, block }
//   activeKey(registry, role)                 address or null
//   pendingKey(registry, role)                { key, effectiveAt } (key null when none)
//   papers(agentId)                           { owner, wallet, implementation, blockTag, unsettled? } from the ERC-8004
//                                             registry as of the safe head; `unsettled` when they changed since it
//   committedTx(contract, stream, epoch)      the hash of the tx whose Committed event posted it, or null
//   identity                                  where papers are read: protocol.js identityRegistry(chainId, standIn), or
//                                             null when this chain has none configured (papers() then refuses)
//
// THE CHAIN IS CHECKED, NOT ASSUMED: before the first papers read or post, viemChain asks the RPC its chain id and
// refuses to go on if it is not the one configured, so a mainnet world pointed at a test RPC (or the reverse) reads and
// posts nothing.
import { identityRegistry } from './protocol.js';

export const ZERO32 = '0x' + '0'.repeat(64);
export const COMMITS_ABI = [
  { type: 'function', name: 'commitOf', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'epoch', type: 'uint256' }], outputs: [{ name: 'root', type: 'bytes32' }, { name: 'count', type: 'uint64' }, { name: 'postedAt', type: 'uint64' }] },
  { type: 'function', name: 'streamOf', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }], outputs: [{ name: 'name', type: 'string' }, { name: 'cadence', type: 'uint32' }, { name: 'committer', type: 'address' }, { name: 'latestEpoch', type: 'uint64' }, { name: 'commitCount', type: 'uint64' }] },
  { type: 'function', name: 'verify', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'epoch', type: 'uint256' }, { name: 'leaf', type: 'bytes32' }, { name: 'proof', type: 'bytes32[]' }], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'commitBatch', stateMutability: 'nonpayable', inputs: [{ name: 'streamIds_', type: 'uint256[]' }, { name: 'epochs', type: 'uint256[]' }, { name: 'roots', type: 'bytes32[]' }, { name: 'counts', type: 'uint64[]' }], outputs: [] },
  { type: 'function', name: 'addStream', stateMutability: 'nonpayable', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'name', type: 'string' }, { name: 'cadence', type: 'uint32' }, { name: 'committer', type: 'address' }], outputs: [] },
  { type: 'function', name: 'owner', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
  { type: 'event', name: 'Committed', inputs: [{ name: 'streamId', type: 'uint256', indexed: true }, { name: 'epoch', type: 'uint256', indexed: true }, { name: 'root', type: 'bytes32', indexed: false }, { name: 'count', type: 'uint256', indexed: false }, { name: 'committer', type: 'address', indexed: true }] },
];
export const REGISTRY_ABI = [
  { type: 'function', name: 'activeKey', stateMutability: 'view', inputs: [{ name: 'role', type: 'bytes32' }], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'pendingKey', stateMutability: 'view', inputs: [{ name: 'role', type: 'bytes32' }], outputs: [{ name: 'key', type: 'address' }, { name: 'effectiveAt', type: 'uint256' }] },
  { type: 'function', name: 'activateKey', stateMutability: 'nonpayable', inputs: [{ name: 'role', type: 'bytes32' }], outputs: [] },
  { type: 'function', name: 'owner', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
];
export const ERC8004_ABI = [
  { type: 'function', name: 'ownerOf', stateMutability: 'view', inputs: [{ type: 'uint256' }], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'getAgentWallet', stateMutability: 'view', inputs: [{ type: 'uint256' }], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'register', stateMutability: 'nonpayable', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'event', name: 'Registered', inputs: [{ name: 'agentId', type: 'uint256', indexed: true }, { name: 'agentURI', type: 'string', indexed: false }, { name: 'owner', type: 'address', indexed: true }] },
];
// EVERY WAY AN AGENT'S PAPERS CHANGE, AS THE REGISTRY LOGS IT (IdentityRegistryUpgradeable at 0x7274…9c02, Sourcify):
// a mint or a transfer is Transfer (agentId in topic 3); setAgentWallet, unsetAgentWallet, a register and the wallet
// cleared on a transfer are all MetadataSet(agentId, "agentWallet", …) (agentId in topic 1, keccak("agentWallet") in
// topic 2); a new implementation is the proxy's Upgraded. None of the three between two blocks means ownerOf and
// getAgentWallet answer the same at both.
export const PAPERS_TOPICS = Object.freeze({
  transfer: '0xddf252ad1be2c89b69c2b068fc378daa952ba7f163c4a11628f55a4df523b3ef',   // Transfer(address,address,uint256)
  metadataSet: '0x2c149ed548c6d2993cd73efe187df6eccabe4538091b33adbd25fafdb8a1468b', // MetadataSet(uint256,string,string,bytes)
  agentWalletKey: '0x2ac6109326e720d1435c0db66f7e35eda7839f52b6f1f5520a60788e132b4e39', // keccak("agentWallet"): the indexed key
  upgraded: '0xbc7cd75a20ee27fd9adebab32041f755214dbc6bffa90cc0225b39da2e5c2d3b',    // Upgraded(address)
});
const nz = (a) => (a && !/^0x0{40}$/i.test(a) ? a : null);
const STATE_GONE = /historical state|missing trie node|state .*not available|header not found/i;

// fees: optional async () => { maxFeePerGas, maxPriorityFeePerGas }, for a run that sizes its committers' gas (docs/worlds-testnet.md)
export function viemChain(viem, { rpc = 'https://rpc.mainnet.chain.robinhood.com', chainId = 4663, fromBlock = 0n, identityStandIn = null, fees = null } = {}) {
  let identity = null, identityError = null;
  try { identity = identityRegistry(chainId, identityStandIn); } catch (e) { identityError = e; }
  const registryOf = () => { if (!identity) throw identityError; return identity; };
  let chainOk = null;
  const checkChain = () => (chainOk ??= pub.getChainId().then((id) => { if (Number(id) !== Number(chainId)) throw new Error(`RPC_CHAIN_MISMATCH: ${rpc} answers chain ${id}; this world is configured for chain ${chainId}`); }).catch((e) => { chainOk = null; throw e; }));
  const chain = viem.defineChain({ id: chainId, name: `chain ${chainId}`, nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [rpc] } } });
  const pub = viem.createPublicClient({ chain, transport: viem.http(rpc, { timeout: 15_000, retryCount: 6, retryDelay: 1500 }) });
  const read = (address, abi, functionName, args = [], blockTag = 'latest') => pub.readContract({ address, abi, functionName, args, blockTag });
  return {
    kind: 'chain', chainId, pub, identity, identityError: identityError ? String(identityError.message) : null,
    async commitOf(contract, stream, epoch) { const [root, count, postedAt] = await read(contract, COMMITS_ABI, 'commitOf', [BigInt(stream), BigInt(epoch)]); return { root, count: Number(count), postedAt: Number(postedAt) }; },
    verify: (contract, stream, epoch, leaf, proof) => read(contract, COMMITS_ABI, 'verify', [BigInt(stream), BigInt(epoch), leaf, proof]),
    async streamOf(contract, stream) { const [name, cadence, committer, latestEpoch, commitCount] = await read(contract, COMMITS_ABI, 'streamOf', [BigInt(stream)]); return { name, cadence: Number(cadence), committer, latestEpoch: Number(latestEpoch), commitCount: Number(commitCount) }; },
    async postBatch({ contract, key, entries }) {
      await checkChain();
      const account = viem.privateKeyToAccount(key);
      const wallet = viem.createWalletClient({ account, chain, transport: viem.http(rpc, { timeout: 30_000, retryCount: 6, retryDelay: 1500 }) });
      const args = [entries.map((e) => BigInt(e.stream)), entries.map((e) => BigInt(e.epoch)), entries.map((e) => e.root), entries.map((e) => BigInt(e.count))];
      const { request } = await pub.simulateContract({ account, address: contract, abi: COMMITS_ABI, functionName: 'commitBatch', args });
      const tx = await wallet.writeContract({ ...request, ...(fees ? await fees() : {}) });
      const r = await pub.waitForTransactionReceipt({ hash: tx, timeout: 90_000 });
      if (r.status !== 'success') throw new Error(`commitBatch reverted in ${tx}`);
      return { tx, block: Number(r.blockNumber), gasUsed: Number(r.gasUsed) };
    },
    // an agent's signature: an EOA's by recovery, a smart wallet's by EIP-1271 (viem's verifyTypedData asks the wallet)
    // the on-chain owner of a world's contract: who may use its operator's door (a contract owner is checked by EIP-1271)
    ownerOf: (contract) => read(contract, [{ type: 'function', name: 'owner', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] }], 'owner'),
    verifyTyped: ({ address, typedData, signature }) => pub.verifyTypedData({ address, ...typedData, signature }).catch(() => false),
    activeKey: async (registry, role) => nz(await read(registry, REGISTRY_ABI, 'activeKey', [role])),
    async pendingKey(registry, role) { const [key, effectiveAt] = await read(registry, REGISTRY_ABI, 'pendingKey', [role]); return { key: nz(key), effectiveAt: Number(effectiveAt) }; },
    // THE PAPERS AT THE SAFE HEAD (§2.1: a join is permanent, so it must not rest on a block that can still reorg).
    // Read at the safe block when the RPC keeps its state. Robinhood Chain's public RPC does not (state at `safe`,
    // ~12 minutes back, and `finalized`, ~19, answers "historical state … is not available"), so otherwise the reads are
    // pinned to one recent block and the registry's logs between the safe block and it are read: no Transfer, no
    // agentWallet MetadataSet for this agentId and no Upgraded means the pinned read IS the safe head's. If there is one,
    // the answer is `unsettled` and the world refuses the join until that block is safe. Logs, unlike state, are kept.
    async papers(agentId) {
      const reg = registryOf();
      await checkChain();
      const id = BigInt(agentId);
      const safe = (await pub.getBlock({ blockTag: 'safe' })).number;
      const readAt = async (blockNumber) => {
        const call = (functionName) => pub.readContract({ address: reg.address, abi: ERC8004_ABI, functionName, args: [id], blockNumber });
        let owner = null, wallet = null;
        // only a revert means "no such agent"; an RPC that fails, or has no state there, is an error, never an empty answer
        try { owner = await call('ownerOf'); } catch (e) { if (/revert/i.test(String(e?.shortMessage || e?.message)) && !STATE_GONE.test(String(e?.details || e?.message)) && !/RPC Request failed/i.test(String(e?.shortMessage || e?.message))) return { owner: null, wallet: null, implementation: null }; throw e; }
        try { wallet = nz(await call('getAgentWallet')); } catch (e) { if (STATE_GONE.test(String(e?.details || e?.message))) throw e; wallet = null; }
        const slot = await pub.getStorageAt({ address: reg.address, slot: reg.implementationSlot, blockNumber });
        return { owner, wallet, implementation: slot && !/^0x0*$/.test(slot) ? viem.getAddress('0x' + slot.slice(-40)) : null, registry: { chainId: reg.chainId, address: reg.address, standIn: reg.standIn } };
      };
      try {
        return { ...(await readAt(safe)), blockTag: `safe #${safe}`, safeBlock: Number(safe) };
      } catch (e) { if (!STATE_GONE.test(String(e?.details || e?.message || e))) throw e; }
      const pinned = await pub.getBlockNumber();
      const p = await readAt(pinned);
      const T = PAPERS_TOPICS, idTopic = '0x' + id.toString(16).padStart(64, '0'), range = { fromBlock: '0x' + (safe + 1n).toString(16), toBlock: '0x' + pinned.toString(16) };
      const logs = (topics) => pub.request({ method: 'eth_getLogs', params: [{ address: reg.address, ...range, topics }] });
      const [wallets, transfers, upgrades] = await Promise.all([logs([T.metadataSet, idTopic, T.agentWalletKey]), logs([T.transfer, null, null, idTopic]), logs([T.upgraded])]);
      const moved = [...wallets.map((l) => ['wallet', l]), ...transfers.map((l) => ['transfer', l]), ...upgrades.map((l) => ['upgrade', l])]
        .map(([kind, l]) => ({ kind, block: Number(BigInt(l.blockNumber)), tx: l.transactionHash })).sort((a, b) => a.block - b.block);
      const out = { ...p, safeBlock: Number(safe), pinnedBlock: Number(pinned), blockTag: `safe #${safe}, by #${pinned} with no papers event between (the RPC keeps no state at the safe head)` };
      if (moved.length) return { ...out, blockTag: `#${pinned}, unsettled since #${moved[0].block}`, unsettled: { safe: Number(safe), last: moved[moved.length - 1].block, events: moved } };
      return out;
    },
    async committedTx(contract, stream, epoch) {
      const logs = await pub.getContractEvents({ address: contract, abi: COMMITS_ABI, eventName: 'Committed', args: { streamId: BigInt(stream), epoch: BigInt(epoch) }, fromBlock: BigInt(fromBlock) });
      return logs.length ? logs[0].transactionHash : null;
    },
  };
}

// ---- in memory: the same rules, no chain ---------------------------------------------------------------------------
export function memoryChain({ now = () => Date.now(), keyOf = null, chainId = 4663, identityStandIn = null } = {}) {
  const identity = identityRegistry(chainId, identityStandIn);
  const contracts = new Map(), registries = new Map(), agents = new Map();
  let txn = 0;
  const fakeTx = () => '0x' + (++txn).toString(16).padStart(64, 'f');
  const c = (addr) => { const k = String(addr).toLowerCase(); if (!contracts.has(k)) throw new Error(`no CityCommitsV2 at ${addr}`); return contracts.get(k); };
  const self = {
    kind: 'memory', chainId, identity, txs: [],
    deployCommits(addr, owner) { contracts.set(String(addr).toLowerCase(), { owner, streams: new Map(), commits: new Map() }); },
    addStream(addr, stream, name, cadence, committer) { c(addr).streams.set(Number(stream), { name, cadence, committer, latestEpoch: 0, commitCount: 0 }); },
    deployRegistry(addr, owner, roles = {}) { const r = { owner, active: new Map(), pending: new Map() }; for (const [role, key] of Object.entries(roles)) r.pending.set(role, { key, effectiveAt: Math.floor(now() / 1000) + 7 * 86400 }); registries.set(String(addr).toLowerCase(), r); },
    setActive(addr, role, key) { registries.get(String(addr).toLowerCase()).active.set(role, key); },
    registerAgent(agentId, owner, wallet = owner) { agents.set(String(agentId), { owner, wallet }); },
    // the registry moved this agent's papers after the safe head (a transfer, a new wallet): reads answer `unsettled`
    unsettle(agentId, on = true) { const a = agents.get(String(agentId)); if (a) a.unsettled = on ? { safe: 0, last: 1, events: [{ kind: 'wallet', block: 1, tx: null }] } : undefined; },
    async ownerOf(addr) { return c(addr).owner; },
    setOwner(addr, owner) { c(addr).owner = owner; },
    async commitOf(addr, stream, epoch) { const x = c(addr).commits.get(`${stream}:${epoch}`); return x ? { ...x } : { root: ZERO32, count: 0, postedAt: 0 }; },
    async verify(addr, stream, epoch, leaf, proof) {
      const x = c(addr).commits.get(`${stream}:${epoch}`); if (!x) return false;
      const { foldProof } = await import('./protocol.js');
      return foldProof(leaf, proof).toLowerCase() === x.root.toLowerCase();
    },
    async streamOf(addr, stream) { const s = c(addr).streams.get(Number(stream)); if (!s) throw new Error(`NoSuchStream(${stream})`); return { ...s }; },
    async postBatch({ contract, key, entries }) {
      const k = c(contract), from = keyOf ? keyOf(key) : key, t = Math.floor(now() / 1000);
      for (const e of entries) {
        const s = k.streams.get(Number(e.stream));
        if (!s) throw new Error(`NoSuchStream(${e.stream})`);
        if (String(s.committer).toLowerCase() !== String(from).toLowerCase()) throw new Error(`NotCommitter(${e.stream})`);
        if (s.commitCount && Number(e.epoch) <= s.latestEpoch) throw new Error(`EpochNotAfterLatest(${e.stream}, ${e.epoch}, ${s.latestEpoch})`);
        if (Number(e.epoch) > Math.floor(t / s.cadence) + 1) throw new Error(`EpochInFuture(${e.stream}, ${e.epoch})`);
        if (/^0x0{64}$/.test(e.root)) throw new Error('ZeroRoot'); if (!e.count) throw new Error('NoLeaves');
      }
      const tx = fakeTx();
      for (const e of entries) { const s = k.streams.get(Number(e.stream)); k.commits.set(`${e.stream}:${e.epoch}`, { root: e.root, count: Number(e.count), postedAt: t, tx }); s.latestEpoch = Number(e.epoch); s.commitCount++; }
      self.txs.push({ tx, contract, entries });
      return { tx, block: self.txs.length };
    },
    async activeKey(addr, role) { return registries.get(String(addr).toLowerCase())?.active.get(role) || null; },
    async pendingKey(addr, role) { const p = registries.get(String(addr).toLowerCase())?.pending.get(role); return p ? { ...p } : { key: null, effectiveAt: 0 }; },
    async papers(agentId) { const a = agents.get(String(agentId)); if (!a) return { owner: null, wallet: null, implementation: null }; const { unsettled, ...p } = a; return { ...p, implementation: identity.implementation, registry: { chainId, address: identity.address, standIn: identity.standIn }, blockTag: 'memory', ...(unsettled ? { unsettled } : {}) }; },
    async committedTx(addr, stream, epoch) { return c(addr).commits.get(`${stream}:${epoch}`)?.tx || null; },
  };
  return self;
}
