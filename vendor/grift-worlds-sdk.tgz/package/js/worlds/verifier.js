// THE INDEPENDENT VERIFIER (docs/world-deployer.md). Anyone holding an item another world sealed, and an RPC, can check it here: no
// world's server, no San Verano, no index service. It runs in a browser as it does on a server: its only reads are the chain's.
//
//   verifyItem({ pub, index, cite, related }) → { ok, world, kind, agentId, epoch, leaf, checks, facts, claims, unverified }
//     cite: { world, stream: 1, epoch, leaf, proof, itemText } as a world serves it; any contract it names is ignored, the index decides
//     related: more cites, for the leaves this item points at (a departure it arrived on, an item it was credited for)
//
// WHAT IT SEPARATES, because the difference is the point:
//   facts      what cryptography and the chain establish, each with its basis: this world's operator committed these exact words in
//              this period; this wallet signed this request; the other world's contract holds that leaf
//   claims     every other word in the item. A commitment proves the operator published it, not that it is true: `summary`, a standing,
//              an attested task and a clock time are that operator's say, and nothing here makes them more
//   unverified what the item points at and this reader was not handed the proof for, said so rather than counted
// `weight` is the world's own label and is reported as one. A 'fact' item that fails a check here is a failed check.
import * as viem from 'viem';
import * as P from './protocol.js';

export const INDEX_READ_ABI = viem.parseAbi([
  'function worldOf(bytes32 worldId) view returns ((address lister, uint8 status, uint32 listings, uint64 listedAt, address commits, uint64 statusAt, address keyRegistry, uint64 checkedAt, bytes32 feeBurnTx, bytes32 evidenceHash, string manifestURI))',
]);
const COMMITS_READ_ABI = viem.parseAbi([
  'function verify(uint256 streamId, uint256 epoch, bytes32 leaf, bytes32[] proof) view returns (bool)',
  'function commitOf(uint256 streamId, uint256 epoch) view returns (bytes32 root, uint32 count, uint64 postedAt)',
  'function owner() view returns (address)',
]);
const REGISTRY_READ_ABI = viem.parseAbi(['function ownerOf(uint256 agentId) view returns (address)', 'function getAgentWallet(uint256 agentId) view returns (address)']);
const STATUS = ['NONE', 'LISTED', 'STALE', 'DISPUTED', 'DELISTED'];
const worldIdOf = (id) => viem.keccak256(viem.toBytes(String(id)));
const same = (a, b) => { try { return viem.getAddress(a) === viem.getAddress(b); } catch { return false; } };
// the fields a world writes that are its own say, whatever weight it labels the item with
const SAID_BY_WORLD = ['summary', 'standing', 'at', 'id', 'place', 'placeName', 'name', 'title', 'taskId', 'proof', 'credential', 'cited', 'line', 'notice', 'reason', 'target', 'doorClosed', 'cameFrom', 'jobId', 'chainJobId', 'task', 'audited', 'resultHash', 'specHash'];

async function worldOnIndex(pub, index, world) {
  if (typeof world !== 'string' || !world) return { problem: 'the cite names no world' };
  let e;
  try { e = await pub.readContract({ address: index, abi: INDEX_READ_ABI, functionName: 'worldOf', args: [worldIdOf(world)] }); } catch (err) { return { problem: `the index could not be read (${String(err?.shortMessage || err?.message || err).slice(0, 100)})` }; }
  if (!e || /^0x0+$/.test(String(e.commits)) || Number(e.status) === 0) return { problem: `${world.slice(0, 40)} is not on this index` };
  return { commits: viem.getAddress(e.commits), keyRegistry: viem.getAddress(e.keyRegistry), lister: viem.getAddress(e.lister), status: STATUS[Number(e.status)] ?? String(e.status) };
}

// WHICH REQUEST EACH KIND OF ITEM IS SEALED FROM. Without this, any real signature an agent ever made could be set beside any words: a note's request behind a made-up departure
const REQUEST_OF_KIND = Object.freeze({ arrived: 'Join', returned: 'Join', 'papers.bound': 'PapersBind', departed: 'leave', 'note.written': 'note', 'task.completed': 'task', 'world.credential': 'claim', 'credential.accepted': 'present', 'guild.credential': 'present', 'guild.signed': 'sign', 'job.taken': 'take', 'job.completed': 'audit', 'review.written': 'review' });
const OPERATOR_KIND_OF = Object.freeze({ door: 'operator.door', refuse: 'operator.refused', allow: 'operator.allowed', invite: 'operator.invited', uninvite: 'operator.uninvited', notice: 'operator.notice', postJob: 'operator.job.posted' });

// the wallet that signed the request an item carries as its evidence, if it can be shown: an EOA by recovery, a contract by EIP-1271. What the signature is checked against is
// decided by the KIND of item, never by a field a world wrote: item.wallet for an agent's, evidence.signedBy only for an operator.* item signed as an operator's act.
// cadence: the stream's, from the chain, so the request is held to the period it is sealed in
async function requestSignature(pub, item, chainId, cadence, commits) {
  const req = item?.evidence?.request;
  if (!req) return null;
  const domain = req.domain, signature = req.signature;
  if (!domain || typeof signature !== 'string') return { ok: false, why: 'its request carries no domain or signature' };
  if (Number(domain.chainId) !== Number(chainId)) return { ok: false, why: `its request was signed for chain ${domain.chainId}, this is chain ${chainId}` };
  // A SIGNATURE BOUND TO ANOTHER CONTRACT IS NOT THIS WORLD'S, whatever its words say. One bound to none is a record from before the binding: it is reported, and not counted as bound
  const bound = domain.verifyingContract != null;
  if (bound && !same(domain.verifyingContract, commits)) return { ok: false, why: `its request was signed for the contract ${String(domain.verifyingContract).slice(0, 42)}, and this world's is ${commits}` };
  const operatorKind = String(item.kind).startsWith('operator.');
  const wanted = REQUEST_OF_KIND[item.kind] ?? null;
  let typedData, ts, op = req.kind, taskCheck = true;
  if (req.kind === 'Join' || req.kind === 'PapersBind') {
    const j = req.message || {};
    if (j.world !== item.world || String(j.agentId) !== String(item.agentId)) return { ok: false, why: `its ${req.kind} is not for this agent in this world` };
    try {
      typedData = req.kind === 'Join'
        ? { domain, types: P.JOIN_TYPES, primaryType: 'Join', message: { agentId: BigInt(j.agentId), world: String(j.world), name: String(j.name), challenge: j.challenge, ts: BigInt(j.ts) } }
        : { domain, types: P.PAPERS_BIND_TYPES, primaryType: 'PapersBind', message: { agentId: BigInt(j.agentId), world: String(j.world), resident: BigInt(j.resident), challenge: j.challenge, ts: BigInt(j.ts) } };
    } catch { return { ok: false, why: `its ${req.kind} cannot be read` }; }
    ts = j.ts;
  } else if (req.kind === 'Request') {
    let m; try { m = JSON.parse(req.msg); } catch { return { ok: false, why: 'its request is not JSON' }; }
    if (!m || typeof m !== 'object') return { ok: false, why: 'its request is not an object' };
    if (m.world !== item.world) return { ok: false, why: 'its request is for another world' };
    if (operatorKind !== (m.op === 'operator')) return { ok: false, why: operatorKind ? 'an operator\'s item must rest on an operator\'s request' : 'an operator\'s request cannot stand behind this item' };
    if (!operatorKind && String(m.agentId) !== String(item.agentId)) return { ok: false, why: 'its request is another agent\'s' };
    if (operatorKind && OPERATOR_KIND_OF[m.action] && OPERATOR_KIND_OF[m.action] !== item.kind) return { ok: false, why: `its request asks for ${String(m.action).slice(0, 30)}, not this act` };
    if (item.kind === 'task.completed' && String(m.taskId) !== String(item.taskId)) taskCheck = false;
    typedData = { domain, types: P.REQUEST_TYPES, primaryType: 'Request', message: { msg: req.msg } };
    ts = m.ts; op = m.op;
  } else return { ok: false, why: `an unknown request kind ${String(req.kind).slice(0, 20)}` };
  if (!operatorKind && wanted && op !== wanted) return { ok: false, why: `a ${String(item.kind).slice(0, 30)} item is sealed from a ${wanted} request, and this one is ${String(op).slice(0, 30)}` };
  if (!taskCheck) return { ok: false, why: 'its request is for another task' };
  // a request is signed within the world's clock window of the period it lands in: an old signature cannot be set beside new words
  if (cadence) {
    const start = Number(item.epoch) * cadence * 1000, end = (Number(item.epoch) + 2) * cadence * 1000;
    if (!Number.isFinite(Number(ts)) || Number(ts) < start - P.MAX_SKEW_MS || Number(ts) > end + P.MAX_SKEW_MS) return { ok: false, why: `its request was signed outside period ${item.epoch}` };
  }
  const expected = operatorKind ? item.evidence.signedBy : item.wallet;
  if (!expected) return { ok: false, why: 'the item names no wallet' };
  let valid = false;
  try { valid = await pub.verifyTypedData({ address: expected, ...typedData, signature }); } catch { valid = false; }
  return valid ? { ok: true, signer: viem.getAddress(expected), operator: operatorKind, known: operatorKind || !!wanted, op, bound } : { ok: false, why: `the signature is not by ${expected}` };
}

// the leaves an item points at in other worlds, and what each must be: a citation is checked for what it is said to be, not only that it exists
function pointersOf(item) {
  const out = [];
  if (item?.from?.leaf) out.push({ why: 'the departure it arrived on', world: item.from.world, contract: item.from.contract, epoch: item.from.epoch, leaf: item.from.leaf, kind: 'departed', agentId: item.agentId });
  if (item?.cited?.leaf) out.push({ why: 'the item it was credited for', world: item.cited.world, contract: item.cited.contract, epoch: item.cited.epoch, leaf: item.cited.leaf, kind: item.cited.kind ?? null });
  if (item?.credential?.leaf) out.push({ why: 'the credential presented', world: item.credential.world, contract: item.credential.contract, epoch: item.credential.epoch, leaf: item.credential.leaf, kind: item.credential.kind ?? null, agentId: item.agentId });
  // a credential rests on the items its tasks were proven by: a reader handed them checks each on its own world's contract
  for (const t of Array.isArray(item?.credential?.tasks) ? item.credential.tasks : []) if (t?.leaf && t.world) out.push({ why: `the proof of task ${String(t.id).slice(0, 30)}`, world: t.world, contract: t.contract, epoch: t.epoch, leaf: t.leaf });
  if (item?.audited?.leaf) out.push({ why: 'the item it audited', world: item.audited.world, contract: item.audited.contract, epoch: item.audited.epoch, leaf: item.audited.leaf, kind: item.target?.kind ?? null, agentId: item.target?.agentId ?? null });
  return out;
}
const COMMITS_STREAM_ABI = viem.parseAbi(['function streamOf(uint256 streamId) view returns (string name, uint32 cadence, address committer, uint256 latestEpoch, uint64 commitCount)']);

// identity: the ERC-8004 registry to read papers from, for a chain whose registry is not in the protocol's table (a local stand-in). Never taken from the item.
export async function verifyItem({ pub, index, cite, related = [], chainId = null, identity = null, depth = 2 }) {
  const checks = [], facts = [], claims = [], unverified = [];
  const check = (id, passed, statement, detail = null) => { checks.push({ id, ok: !!passed, statement, ...(detail ? { detail } : {}) }); return !!passed; };
  const r = cite && typeof cite === 'object' ? cite : {};
  const out = { ok: false, world: r.world ?? null, kind: null, agentId: null, epoch: r.epoch ?? null, leaf: r.leaf ?? null, weight: null, checks, facts, claims, unverified };
  chainId = chainId ?? await pub.getChainId();

  // WHICH CONTRACT: the index says, never the cite
  const onIndex = await worldOnIndex(pub, index, r.world);
  if (!check('index', !onIndex.problem, onIndex.problem || `${r.world} is on the index at ${index}, its contract ${onIndex.commits}, status ${onIndex.status}`)) return out;
  out.contract = onIndex.commits; out.lister = onIndex.lister; out.status = onIndex.status;
  if (r.contract != null && !same(r.contract, onIndex.commits)) check('contract', false, `the cite names ${r.contract}, the index names ${onIndex.commits}`);

  // THE WORDS: they hash to the leaf
  let item = null, leaf = null;
  try { item = JSON.parse(String(r.itemText ?? '')); leaf = P.recordLeaf(item); } catch { /* below */ }
  if (!check('text', leaf != null && leaf === r.leaf, leaf == null ? 'the cite\'s text is not an item' : leaf === r.leaf ? 'the item\'s text hashes to its leaf' : 'the item\'s text does not hash to the cited leaf')) return out;
  out.kind = item.kind; out.agentId = String(item.agentId); out.weight = item.weight ?? null;
  if (!check('world', item.world === r.world && Number(item.epoch) === Number(r.epoch), item.world === r.world && Number(item.epoch) === Number(r.epoch) ? 'the item says the same world and period as the cite' : 'the item says another world or period than the cite')) return out;

  // ON CHAIN: the leaf is under the root that world's committer posted
  let onChain = false, commit = null;
  try {
    onChain = await pub.readContract({ address: onIndex.commits, abi: COMMITS_READ_ABI, functionName: 'verify', args: [BigInt(P.STREAM.records), BigInt(r.epoch), r.leaf, Array.isArray(r.proof) ? r.proof : []] });
    const [root, count, postedAt] = await pub.readContract({ address: onIndex.commits, abi: COMMITS_READ_ABI, functionName: 'commitOf', args: [BigInt(P.STREAM.records), BigInt(r.epoch)] });
    commit = { root, count: Number(count), postedAt: Number(postedAt) };
  } catch (e) { check('chain', false, `the chain could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 100)})`); return out; }
  if (!check('chain', onChain, onChain ? `the leaf verifies against the root posted for period ${r.epoch} on ${onIndex.commits}` : `the leaf does not verify against that contract's root for period ${r.epoch}`)) return out;
  out.commit = commit;
  facts.push({ fact: 'committed', statement: `${r.world}'s operator committed exactly these words in period ${r.epoch}, posted at chain time ${commit.postedAt}`, basis: `CityCommitsV2.verify on ${onIndex.commits}` });

  // WHO SIGNED: the request the item carries as its evidence, if it carries one
  let cadence = null;
  try { cadence = Number((await pub.readContract({ address: onIndex.commits, abi: COMMITS_STREAM_ABI, functionName: 'streamOf', args: [BigInt(P.STREAM.records)] }))[1]); } catch { /* the window below is then not applied, and that is said */ unverified.push({ what: 'the stream\'s cadence could not be read, so the request\'s time was not held to its period' }); }
  const sig = await requestSignature(pub, item, chainId, cadence, onIndex.commits);
  if (sig) {
    if (check('signature', sig.ok, sig.ok ? `its request is signed by ${sig.signer}` : `its request's signature fails: ${sig.why}`)) {
      if (!sig.bound) unverified.push({ what: 'this signature names no contract (a record from before signatures were bound to one), so it could have been made for another deployment of this world' });
      if (sig.operator) {
        let owner = null; try { owner = viem.getAddress(await pub.readContract({ address: onIndex.commits, abi: COMMITS_READ_ABI, functionName: 'owner' })); } catch { /* unread */ }
        facts.push({ fact: 'operator-signed', statement: `${sig.signer} signed this act${owner && same(owner, sig.signer) ? ', and owns the world\'s contract now' : ''}`, basis: 'EIP-712 Request in the world\'s domain' });
        if (!owner || !same(owner, sig.signer)) unverified.push({ what: `whether ${sig.signer} owned the contract when it signed: ${owner ? `its owner now is ${owner}` : 'the owner could not be read'}` });
      } else {
        facts.push({ fact: 'agent-signed', statement: `the wallet ${sig.signer} signed the request behind this item, naming agent ${item.agentId}`, basis: `EIP-712 ${item.evidence.request.kind} in the world's domain` });
        if (!sig.known) unverified.push({ what: `which request a ${String(item.kind).slice(0, 30)} item should rest on: this is that world's own kind, so only that this wallet signed a ${String(sig.op).slice(0, 30)} request is established` });
        const papersAt = identity || P.ERC8004_BY_CHAIN?.[chainId];
        if (papersAt) {
          let now = null;
          try { const wallet = await pub.readContract({ address: papersAt, abi: REGISTRY_READ_ABI, functionName: 'getAgentWallet', args: [BigInt(item.agentId)] }); now = /^0x0+$/.test(wallet) ? await pub.readContract({ address: papersAt, abi: REGISTRY_READ_ABI, functionName: 'ownerOf', args: [BigInt(item.agentId)] }) : wallet; } catch { /* unread */ }
          if (now && same(now, sig.signer)) facts.push({ fact: 'papers', statement: `the identity registry ${papersAt} names that wallet for agent ${item.agentId} now`, basis: 'ERC-8004 getAgentWallet or ownerOf' });
          else if (now) unverified.push({ what: `the registry ${papersAt} names ${now} for agent ${item.agentId} now, not the signer; the world says the signer held the papers then` });
          else unverified.push({ what: `the identity registry ${papersAt} could not be read for agent ${item.agentId}` });
        } else unverified.push({ what: `no identity registry is known for chain ${chainId}, so whether that wallet holds agent ${item.agentId}'s papers was not checked` });
      }
    }
  } else if (item.kind !== 'alive') unverified.push({ what: 'this item carries no signed request: nothing shows an agent asked for it' });

  // WHAT IT POINTS AT, in other worlds: checked when this reader was handed the proof, and said so when not
  for (const p of pointersOf(item)) {
    const handed = (related || []).find((c) => c && c.leaf === p.leaf && c.world === p.world);
    if (!handed || depth <= 0) { unverified.push({ what: `${p.why}: leaf ${p.leaf} in ${p.world}, epoch ${p.epoch}; no proof was given to check it` }); continue; }
    const sub = await verifyItem({ pub, index, cite: handed, related, chainId, identity, depth: depth - 1 });
    const what = !sub.ok ? sub.checks.filter((c) => !c.ok).map((c) => c.statement).join('; ')
      : p.kind && sub.kind !== p.kind ? `it is a ${sub.kind} item, not ${p.kind}`
        : p.agentId != null && String(sub.agentId) !== String(p.agentId) ? `it is agent ${sub.agentId}'s, not ${p.agentId}'s`
          : Number(sub.epoch) !== Number(p.epoch) ? `it is from period ${sub.epoch}, not ${p.epoch}`
            : p.contract && !same(p.contract, sub.contract) ? `the item names ${p.contract}, the index names ${sub.contract}` : null;
    if (check('pointer', !what, what ? `${p.why} does not hold: ${what}` : `${p.why} verifies on ${p.world}'s contract`)) facts.push({ fact: 'cross-world', statement: `${p.why} is committed on ${p.world}'s own contract`, basis: `CityCommitsV2.verify on ${sub.contract}`, kind: sub.kind });
  }

  // EVERYTHING ELSE IN IT IS THE WORLD'S SAY
  for (const field of SAID_BY_WORLD) if (item[field] != null) claims.push({ field, by: r.world, value: item[field] });
  out.item = item;
  out.ok = checks.every((c) => c.ok);
  return out;
}

// a world's items as its record serves them, as cites: { world, stream, epoch, leaf, proof, itemText } from record()'s verify block
export function citeOf(world, recordItem) {
  const v = recordItem?.verify;
  if (!v?.proof || !v.posted || v.posted.unpostable) return null;
  return { world, stream: v.stream ?? P.STREAM.records, epoch: v.epoch, leaf: v.leaf, proof: v.proof, itemText: v.canonical };
}
