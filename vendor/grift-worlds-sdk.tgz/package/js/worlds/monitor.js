// THE MONITOR'S RULE FOR STALE (docs/worlds-protocol.md §3.3, conformance rule 9). Pure: what the chain and a world's served
// leaves say, in; a verdict, out. The index service that runs it on a schedule is not built (stage 2a); the conformance
// suite (tools/worldconform.mjs) runs it once.
//
// A required stream (1 records, 2 decisions) is FRESH when its latest posted epoch is within two cadences of now. An
// epoch with nothing else carries the world's signed `alive` entry (api/_worlds.js ensureAlive), so an idle world stays
// fresh; an alive entry counts only when its signature recovers to the world's signer and its body names that world,
// stream and epoch. A world is STALE when either stream is not fresh, or its latest epoch's leaves are not served, or an
// alive entry there does not check.
import * as P from './protocol.js';

export const MAX_BEHIND = 2; // cadences

export function freshness(stream, nowMs = Date.now()) {
  if (!stream || !stream.commitCount) return { fresh: false, behind: null, why: 'never posted' };
  const behind = Math.floor(nowMs / 1000 / stream.cadence) - Number(stream.latestEpoch);
  return { fresh: behind <= MAX_BEHIND, behind, why: behind <= MAX_BEHIND ? null : `${behind} cadences behind` };
}

// the entries an epoch's leaves endpoint served: { alive, real, bad[] }
export async function aliveCheck(entries, { world, stream, epoch, signer }) {
  const out = { alive: 0, real: 0, bad: [] };
  for (const e of entries || []) {
    const x = e.entry || e;
    const isAlive = x.kind === 'alive' && (x.op === undefined || x.op === 'alive');
    if (!isAlive) { out.real++; continue; }
    const body = x.alive || x.request?.alive, att = x.att || x.request?.att;
    const want = P.aliveBody(world, stream, epoch);
    if (!body || P.canonical(body) !== P.canonical(want)) { out.bad.push('the alive body does not name this world, stream and epoch'); continue; }
    const who = await P.recoverAnswerSigner(world, body, att);
    if (!who || who.toLowerCase() !== String(signer).toLowerCase()) { out.bad.push('the alive signature does not recover to the world\'s signer'); continue; }
    out.alive++;
  }
  return out;
}

// one stream's standing: freshness from streamOf, and the latest epoch's leaves checked
// `root`, when given, is the root posted on chain for the latest epoch: the served leaves must rebuild it, or a world that
// posts roots and serves anything at all would read FRESH (security review, finding 9)
export async function streamStanding({ stream, streamOf, leaves, world, signer, nowMs = Date.now(), root = null }) {
  const f = freshness(streamOf, nowMs);
  if (!f.fresh) return { stream, standing: 'STALE', ...f };
  if (!leaves) return { stream, standing: 'STALE', ...f, why: 'the latest epoch\'s leaves are not served' };
  if (root != null) {
    const rebuilt = leaves.length ? P.treeOf(leaves.map((x) => x.leaf)).root : null;
    const leafOk = leaves.every((x) => { try { return P.leafFor(stream, x.entry) === x.leaf; } catch { return false; } });
    if (!rebuilt || rebuilt.toLowerCase() !== String(root).toLowerCase() || !leafOk) return { stream, standing: 'STALE', ...f, why: 'the served leaves do not rebuild the root posted on chain for the latest epoch' };
  }
  const a = await aliveCheck(leaves, { world, stream, epoch: streamOf.latestEpoch, signer });
  if (a.bad.length) return { stream, standing: 'STALE', ...f, alive: a, why: a.bad.join('; ') };
  return { stream, standing: 'FRESH', ...f, alive: a, kept: a.real ? 'entries of its own' : 'a signed alive entry' };
}
