// DISCOVERY THROUGH THE INDEX (docs/worlds-protocol.md §2.4, §3.3; docs/worlds-sdk.md). Which worlds exist, and which
// may be trusted, is read from WorldIndex on chain and from each world's own manifest and contract, never from a list in
// code. For every worldId the index holds:
//   1. the index entry: lister, status (LISTED, STALE, DISPUTED, DELISTED), commits, keyRegistry, manifestURI
//   2. the manifest at manifestURI, and its checks:
//        id        keccak256(manifest.id) is the worldId           (a manifest cannot claim another world's entry)
//        chain     manifest.chain is this chain                      (a test chain's world is not a mainnet one)
//        commits   manifest.commits.address is the index's commits   (its records are the ones the index names)
//        registry  a keyRegistry named in the manifest is the index's. ON MAINNET THE MANIFEST MUST NAME IT, under a signing role:
//                  the index says which registry speaks for a world, and a manifest cannot leave it out to be believed on
//                  something a world's own committer can post (which would also walk past a revoke)
//        signed    the served hash is the manifest's, and its signature recovers to manifest.signer
//        recent    the signature was made within MAX_SKEW of now     (an old answer replayed is not a fresh one)
//        authority the signer is the registry's active RESPONSE_SIGNER, or, on a test chain only (pin mode, while a registry's 7
//                  days run), the manifest's hash and signer are the leaf posted in stream 16: the served leaves rebuild the
//                  root the world posted ON CHAIN
//        burn      on mainnet: the listing's burn is a real transaction in which the address that listed this world burnt
//                  the listing fee, read from the receipt (a fake or borrowed burn hash is never offered). The one exception is
//                  the genesis policy (docs/worlds-genesis.md): exactly the four founding worlds, on the one index it pins
//   3. freshness by the monitor's rule (js/worlds/monitor.js): streams 1 and 2 within two cadences, alive entries signed
// A world is OFFERED to agents only when it is LISTED or STALE on the index (never DISPUTED or DELISTED), every check
// passes, and its streams are FRESH. Everything else is reported with the reason, so the index's page can show it.
// The answer names the block it was read at; an agent refuses an answer older than the last block it trusted.
import * as viem from 'viem';
import * as P from './protocol.js';
import { streamStanding } from './monitor.js';
import { GENESIS, genesisWorldIds, genesisMarkerOf } from './genesis.js';

export const STATUS = ['NONE', 'LISTED', 'STALE', 'DISPUTED', 'DELISTED'];
export const OFFERABLE = ['LISTED', 'STALE'];
export const SIGNING_ROLES = [P.ROLE_NAME, 'X402_RESPONSE_SIGNER']; // the protocol's, and the one the live city maps it to (K1)
const INDEX_ABI = [
  { type: 'function', name: 'worldCount', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'worldIds', stateMutability: 'view', inputs: [{ type: 'uint256' }, { type: 'uint256' }], outputs: [{ type: 'bytes32[]' }] },
  { type: 'function', name: 'worldOf', stateMutability: 'view', inputs: [{ type: 'bytes32' }], outputs: [{ type: 'tuple', components: [
    { name: 'lister', type: 'address' }, { name: 'status', type: 'uint8' }, { name: 'listings', type: 'uint32' }, { name: 'listedAt', type: 'uint64' }, { name: 'commits', type: 'address' }, { name: 'statusAt', type: 'uint64' },
    { name: 'keyRegistry', type: 'address' }, { name: 'checkedAt', type: 'uint64' }, { name: 'feeBurnTx', type: 'bytes32' }, { name: 'evidenceHash', type: 'bytes32' }, { name: 'manifestURI', type: 'string' }] }] },
  { type: 'function', name: 'owner', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'listingOpen', stateMutability: 'view', inputs: [], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'listerAllowed', stateMutability: 'view', inputs: [{ type: 'address' }], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'codeAllowed', stateMutability: 'view', inputs: [{ type: 'bytes32' }], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'burnUsedBy', stateMutability: 'view', inputs: [{ type: 'bytes32' }, { type: 'address' }], outputs: [{ type: 'bytes32' }] },
  { type: 'function', name: 'genesisPolicy', stateMutability: 'view', inputs: [], outputs: [{ type: 'bytes32' }] },
  { type: 'function', name: 'genesisWorlds', stateMutability: 'view', inputs: [], outputs: [{ type: 'bytes32[]' }] },
  { type: 'function', name: 'genesisLister', stateMutability: 'view', inputs: [{ type: 'bytes32' }], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'genesisMarker', stateMutability: 'view', inputs: [{ type: 'bytes32' }], outputs: [{ type: 'bytes32' }] },
  { type: 'function', name: 'pendingRegistry', stateMutability: 'view', inputs: [{ type: 'bytes32' }], outputs: [{ name: 'keyRegistry', type: 'address' }, { name: 'effectiveAt', type: 'uint64' }] },
  { type: 'function', name: 'list', stateMutability: 'nonpayable', inputs: [{ type: 'bytes32' }, { type: 'string' }, { type: 'address' }, { type: 'address' }, { type: 'bytes32' }], outputs: [] },
  { type: 'function', name: 'setManifest', stateMutability: 'nonpayable', inputs: [{ type: 'bytes32' }, { type: 'string' }], outputs: [] },
  { type: 'function', name: 'setListerAllowed', stateMutability: 'nonpayable', inputs: [{ type: 'address' }, { type: 'bool' }], outputs: [] },
  { type: 'function', name: 'claimLister', stateMutability: 'nonpayable', inputs: [{ type: 'bytes32' }], outputs: [] },
];
export { INDEX_ABI };
const TRANSFER_TOPIC = viem.keccak256(viem.toBytes('Transfer(address,address,uint256)'));

// IS THIS LISTING'S BURN REAL? From the receipt and the index alone: the transaction succeeded, it holds a $GRIFT Transfer of at
// least the listing fee to the burn address, and the address that burnt is the one that listed THIS world with THIS burn
// (WorldIndex burnUsedBy), so a burn cannot be made up, borrowed from someone else's transaction or used for two worlds. A
// receipt never changes, so a good answer is kept.
const burnsSeen = new Map();
export async function burnFacts({ pub, index, worldId, tx }) {
  const B = P.LISTING_BURN, key = `${index}|${worldId}|${tx}`.toLowerCase();
  if (burnsSeen.has(key)) return burnsSeen.get(key);
  const no = (why) => ({ ok: false, tx, why });
  if (!pub) return no('no chain client to read the receipt');
  let rc;
  try { rc = await pub.getTransactionReceipt({ hash: tx }); } catch { return no(`${tx} is not a transaction on this chain`); }
  if (rc.status !== 'success') return no(`the burn transaction ${tx} failed`);
  const hit = rc.logs.find((l) => { try { return viem.getAddress(l.address) === viem.getAddress(B.token) && l.topics[0] === TRANSFER_TOPIC && l.topics.length === 3 && viem.getAddress(`0x${l.topics[2].slice(-40)}`) === viem.getAddress(B.to) && BigInt(l.data) >= B.amount; } catch { return false; } });
  if (!hit) return no(`${tx} holds no Transfer of at least ${B.whole} $GRIFT to ${B.to}`);
  const from = viem.getAddress(`0x${hit.topics[1].slice(-40)}`);
  const used = await pub.readContract({ address: index, abi: INDEX_ABI, functionName: 'burnUsedBy', args: [tx, from] });
  if (used !== worldId) return no(`the address that burnt (${from}) did not list this world with this burn`);
  const facts = { ok: true, tx, from, amount: BigInt(hit.data).toString(), block: Number(rc.blockNumber) };
  burnsSeen.set(key, facts);
  return facts;
}

// IS THIS A GENESIS LISTING? Every condition, or no exemption. The index is the one pinned, so another index naming the same policy and
// the same worlds exempts nobody; the world is one of the policy's four; this is its first listing; and the chain itself says the
// index holds this policy, names this world, and answers this marker. `genesisIndex` is the pinned address: GENESIS.index, which is
// null, and exempts nothing, until the launch pins it. Only a launch's own rehearsal names another, from its own record
export async function genesisFacts({ pub, index, worldId, entry, chainId, genesisIndex = GENESIS.index }) {
  const tx = entry.feeBurnTx;
  const no = (why) => ({ ok: false, tx, why });
  const eq = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
  if (Number(chainId) !== GENESIS.chainId) return no(`the genesis policy is for chain ${GENESIS.chainId}`);
  if (!genesisIndex || !eq(index, genesisIndex)) return no(`this index is not the one the genesis policy applies to, so this world pays the fee: ${tx} is no burn`);
  if (!genesisWorldIds().includes(worldId)) return no('this is not one of the genesis policy\'s four founding worlds, so it pays the fee');
  if (Number(entry.listings) !== 1) return no('the genesis exemption is for a first listing, and this is a relisting: it pays the fee');
  if (!pub) return no('no chain client to read the index');
  const read = (functionName, args = []) => pub.readContract({ address: index, abi: INDEX_ABI, functionName, args });
  const [policy, lister, marker] = await Promise.all([read('genesisPolicy'), read('genesisLister', [worldId]), read('genesisMarker', [worldId])]);
  if (!eq(policy, GENESIS.hash)) return no(`this index holds the policy ${policy}, not the published ${GENESIS.hash}`);
  if (/^0x0+$/.test(lister) || !eq(marker, tx)) return no('this index does not name this world and this marker in its genesis set');
  return { ok: true, genesis: true, tx, from: viem.getAddress(lister), amount: '0', policy };
}
// WHAT A WORLD PAID TO BE LISTED, ON MAINNET: a listing naming its own genesis marker answers to the policy, every other to its burn
export async function listingFee({ pub, index, worldId, entry, chainId, genesisIndex = GENESIS.index }) {
  let marker = null;
  try { marker = genesisMarkerOf({ worldId, index, chainId }); } catch { /* no index to work it out for: read as a burn */ }
  if (marker && String(entry.feeBurnTx).toLowerCase() === marker.toLowerCase()) return genesisFacts({ pub, index, worldId, entry, chainId, genesisIndex });
  return burnFacts({ pub, index, worldId, tx: entry.feeBurnTx });
}

// chain: js/worlds/chain.js (commitOf, streamOf, activeKey); pub: a viem public client (the index reads, the block)
// WHICH WORLDS' CITATIONS A WORLD ACCEPTS, kept from discovery: a world verified and in good standing is added, and one the index has marked disputed or delisted is dropped.
// A world that merely did not answer stays, because what it committed on chain still stands. trust: worlds its operator named itself, which the index does not overrule
export function learnKnown(known, worlds, { self = null, trust = {} } = {}) {
  const same = (a, b) => String(a).toLowerCase() === String(b).toLowerCase();
  for (const w of worlds) {
    if (!OFFERABLE.includes(w.status)) { for (const [id, a] of Object.entries(known)) if (!Object.hasOwn(trust, id) && same(a, w.commits)) delete known[id]; continue; }
    if (w.verified && w.id && w.id !== self && !Object.hasOwn(trust, w.id)) known[w.id] = viem.getAddress(w.commits);
  }
  return known;
}

export async function discover({ chain, pub, index, chainId, fetchJson = defaultFetch, nowMs = Date.now(), genesisIndex = GENESIS.index }) {
  const block = await pub.getBlock({ blockTag: 'latest' });
  const read = (functionName, args = []) => pub.readContract({ address: index, abi: INDEX_ABI, functionName, args, blockNumber: block.number });
  const n = Number(await read('worldCount'));
  const ids = n ? await read('worldIds', [0n, BigInt(n)]) : [];
  const worlds = [];
  // ONE WORLD'S ANSWER IS THAT WORLD'S PROBLEM: whatever a listing's server sends, the others are still read
  for (const worldId of ids) {
    const entry = await read('worldOf', [worldId]);
    try { worlds.push(await checkWorld({ chain, worldId, entry, chainId, fetchJson, nowMs, pub, index, genesisIndex })); }
    catch (e) { worlds.push({ worldId, status: STATUS[Number(entry.status)] || 'NONE', lister: entry.lister, commits: entry.commits, keyRegistry: entry.keyRegistry, manifestURI: entry.manifestURI, checks: { manifest: false }, verified: false, offered: false, why: [`manifest: ${String(e?.message || e).slice(0, 80)}`] }); }
  }
  return { index, chainId, asOf: { block: Number(block.number), blockHash: block.hash, at: nowMs }, worlds, offered: worlds.filter((w) => w.offered).map((w) => w.id) };
}

export async function checkWorld({ chain, worldId, entry, chainId, fetchJson = defaultFetch, nowMs = Date.now(), pub = null, index = null, genesisIndex = GENESIS.index }) {
  const status = STATUS[Number(entry.status)] || 'NONE';
  const out = { worldId, status, lister: entry.lister, commits: entry.commits, keyRegistry: entry.keyRegistry, manifestURI: entry.manifestURI, checks: {}, offered: false, why: [] };
  const no = (k, why) => { out.checks[k] = false; out.why.push(`${k}: ${why}`); };
  let env;
  try { env = await fetchJson(entry.manifestURI); } catch (e) { no('manifest', `could not be fetched (${String(e?.message || e).slice(0, 80)})`); return out; }
  const m = env?.manifest;
  if (!m) { no('manifest', 'no manifest in the answer'); return out; }
  out.id = m.id; out.name = m.name; out.about = typeof m.about === 'string' ? m.about : null; out.api = new URL(m.api, entry.manifestURI).href; out.release = m.release; out.manifestHash = env.hash; out.ops = (m.ops || []).map((o) => o.op);
  out.checks.manifest = true;
  if (viem.keccak256(viem.toBytes(String(m.id))) === worldId) out.checks.id = true; else no('id', `keccak256("${String(m.id).slice(0, 24)}") is not the listed worldId`);
  if (Number(m.chain) === Number(chainId)) out.checks.chain = true; else no('chain', `the manifest says chain ${m.chain}, the index is on ${chainId}`);
  if (String(m.commits?.address || '').toLowerCase() === String(entry.commits).toLowerCase()) out.checks.commits = true; else no('commits', 'the manifest\'s commits is not the index\'s');
  const onMainnet = Number(chainId) === P.CHAIN_ID;
  const namesIndexRegistry = !!m.keyRegistry && String(m.keyRegistry.address).toLowerCase() === String(entry.keyRegistry).toLowerCase();
  if (namesIndexRegistry || (!m.keyRegistry && !onMainnet)) out.checks.registry = true;
  else no('registry', m.keyRegistry ? 'the manifest names another KeyRegistry than the index' : 'on mainnet a manifest names the KeyRegistry the index does');
  if (Number(chainId) === P.LISTING_BURN.chainId) {
    out.burn = await listingFee({ pub, index, worldId, entry, chainId, genesisIndex }).catch((e) => ({ ok: false, why: `could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 80)})` }));
    if (out.burn.ok) out.checks.burn = true; else no('burn', out.burn.why);
  }
  // a new key registry named for this world, its week's notice running: shown, as the index's page would show it
  if (pub && index) { try { const [keyRegistry, effectiveAt] = await pub.readContract({ address: index, abi: INDEX_ABI, functionName: 'pendingRegistry', args: [worldId] }); if (Number(effectiveAt)) out.registryNotice = { keyRegistry, effectiveAt: Number(effectiveAt) }; } catch { /* an index without the notice */ } }
  const world = { id: m.id, name: m.name, commits: entry.commits, chainId: Number(chainId) };
  const signer = m.signer?.address;
  if (env.hash === P.manifestHash(m) && env.att && (await P.recoverAnswerSigner(world, { manifestHash: env.hash }, env.att))?.toLowerCase() === String(signer).toLowerCase()) out.checks.signed = true;
  else no('signed', env.att ? 'the served signature does not recover to the manifest\'s signer' : `unsigned (${env.unsigned || 'no att'})`);
  if (env.att && Math.abs(nowMs / 1000 - Number(env.att.issuedAt)) <= P.MAX_SKEW_MS / 1000) out.checks.recent = true; else no('recent', 'the manifest\'s signature is not from the last five minutes');
  out.checks.authority = false;
  try {
    if (m.keyRegistry?.address) {
      // a world cannot answer under whatever role suits it: a second role's key is one nobody was watching
      const roleName = m.keyRegistry.roles?.[P.ROLE_NAME] || P.ROLE_NAME;
      const role = viem.keccak256(viem.toBytes(roleName));
      const active = await chain.activeKey(viem.getAddress(m.keyRegistry.address), role);
      if (onMainnet && !SIGNING_ROLES.includes(roleName)) no('authority', `${String(roleName).slice(0, 40)} is not a role a world signs under`);
      else if (active && active.toLowerCase() === String(signer).toLowerCase()) { out.checks.authority = true; out.authority = 'registry'; } else no('authority', 'the signer is not the registry\'s active key');
    } else if (!onMainnet && env.pin?.epoch != null && env.pin.manifestHash === env.hash) {
      const lv = await fetchJson(`${out.api}/leaves?stream=${P.STREAM.manifest}&epoch=${env.pin.epoch}`);
      const on = await chain.commitOf(viem.getAddress(entry.commits), P.STREAM.manifest, env.pin.epoch);
      const entryFor = (lv.entries || []).find((x) => x.leaf === env.pin.leaf);
      const rebuilt = lv.entries?.length ? P.treeOf(lv.entries.map((x) => x.leaf)).root : null;
      if (entryFor && entryFor.entry.manifestHash === env.hash && String(entryFor.entry.signer).toLowerCase() === String(signer).toLowerCase() && P.leafFor(P.STREAM.manifest, entryFor.entry) === env.pin.leaf && rebuilt && on.root.toLowerCase() === rebuilt.toLowerCase()) { out.checks.authority = true; out.authority = 'pin'; }
      else no('authority', 'the stream-16 pin does not rebuild to the root on chain for this manifest and signer');
    } else no('authority', 'neither a KeyRegistry nor a posted pin backs the signer');
  } catch (e) { no('authority', `could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 80)})`); }
  // freshness, the monitor's rule
  out.freshness = {};
  let fresh = true;
  for (const [name, stream] of [['records', P.STREAM.records], ['decisions', P.STREAM.decisions]]) {
    try {
      const so = await chain.streamOf(viem.getAddress(entry.commits), stream);
      let leaves = null;
      let root = null;
      if (so.commitCount) { try { leaves = (await fetchJson(`${out.api}/leaves?stream=${stream}&epoch=${so.latestEpoch}`)).entries || null; } catch { leaves = null; } root = (await chain.commitOf(viem.getAddress(entry.commits), stream, so.latestEpoch)).root; }
      const st = await streamStanding({ stream, streamOf: so, leaves, world, signer, nowMs, root });
      out.freshness[name] = st.standing; if (st.standing !== 'FRESH') { fresh = false; out.why.push(`${name}: ${st.why || st.standing}`); }
    } catch (e) { out.freshness[name] = 'STALE'; fresh = false; out.why.push(`${name}: ${String(e?.message || e).slice(0, 60)}`); }
  }
  out.fresh = fresh;
  out.verified = Object.values(out.checks).every(Boolean);
  out.offered = out.verified && fresh && OFFERABLE.includes(status);
  if (!OFFERABLE.includes(status)) out.why.push(`status ${status}: not offered`);
  return out;
}

// a listed world that does not answer costs discovery ten seconds, not forever
async function defaultFetch(url) { const r = await fetch(url, { signal: AbortSignal.timeout(10_000) }); if (!r.ok) throw new Error(`HTTP ${r.status} from ${url}`); return r.json(); }
