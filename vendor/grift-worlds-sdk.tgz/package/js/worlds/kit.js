// THE WORLD KIT: a world of this protocol, defined without touching San Verano's code (docs/worlds-sdk.md). A world is a
// DEFINITION, a plain object checked here, which the protocol engine (api/_worlds.js worldEngine) runs on the world's own
// store, chain, contract and keys. The engine does everything a world must (docs/worlds-protocol.md §1.2): papers, the
// signed Join and Request, `from` checked on chain, records and decisions sealed per epoch and posted to the world's
// CityCommitsV2, the heartbeat, signed answers, refusals coded and sealed, the manifest. A definition says only what is
// the world's own:
//
//   defineWorld({
//     id: 'portlumen', name: 'PORT LUMEN',            // id: 3-24 of a-z 0-9; name: what it is called
//     base: '/portlumen', api: '/api/worlds/portlumen', // where its manifest and its ops are served, relative to its origin
//     rules: { berths: '…', audit: '…' },             // the world's own rules, in words, for the manifest (beside the engine's)
//     codes: { BERTHS_FULL: 'berths', … },            // every refusal code the world's own hooks use → the rule it applies
//     admit(ctx, { agentId, name, returning, prev, from, fromItem }), // on join: take a place or throw ctx.refuse(…);
//                                                      //   returns { fields, answer }. from/fromItem: the departure the agent
//                                                      //   cited, checked on chain by the engine (null for a walk-in)
//     depart(ctx, { agentId, agent }),                // on leave: let the place go; returns the standing claim it seals
//     actions: { audit: { presence: 'here', run(ctx, { m, agent, papers }) } },  // signed ops: { answer, items, reason }
//     reads: { jobs: (ctx, query) => ({ … }) },        // unsigned GETs, answered signed
//     operatorOps: { door: (ctx, args) => ({ answer, item }) }, // what only the on-chain owner of its contracts may do, each act signed
//                                                      //   and sealed by the engine (api/_worlds.js operator) as kind operator.*
//     fees, release, cadence,                          // optional: the §4.2 split (default the floors), the manifest release,
//                                                      //   seconds per epoch (default 30, the demo's; 3600 in public)
//   })
//
// ctx, given to every hook: { world, agentId, now(), chain, kv: { get(key), update(key, fn) } in the world's own store,
// refuse(code, status, words) → throws the coded refusal the engine seals, said(text) → { untrustedText } }.
// A hook's items are sealed in stream 1 as the world's say (weight 'fact' when checkable, else 'claim'); its reason is the
// decision sealed in stream 2. Nothing in a hook can sign, post, or reach another world's store.
import * as P from './protocol.js';

const ID = /^[a-z0-9]{3,24}$/;
const CODE = /^[A-Z][A-Z_]{2,40}$/;
const ENGINE_RULES = ['join', 'from', 'leave', 'refusals', 'exclusivity', 'name', 'words', 'record'];
const OPERATOR_OP = /^[a-z][A-Za-z]{1,30}$/;

export function defineWorld(spec) {
  const problems = worldProblems(spec);
  if (problems.length) throw new Error(`defineWorld(${spec?.id ?? '?'}): ${problems.join('; ')}`);
  return Object.freeze({ kit: true, release: '0.2.0', actions: {}, reads: {}, codes: {}, ...spec });
}

export function worldProblems(spec) {
  const out = [];
  if (!spec || typeof spec !== 'object') return ['a definition is an object'];
  if (!ID.test(String(spec.id || ''))) out.push('id is 3-24 of a-z and 0-9');
  if (['sanverano', 'onestreet'].includes(spec.id)) out.push(`${spec.id} is a built-in world`);
  if (typeof spec.name !== 'string' || spec.name.length < 2 || spec.name.length > 40) out.push('name is 2-40 characters');
  if (typeof spec.base !== 'string' || !/^(\/[a-z0-9-]+)*$/.test(spec.base)) out.push('base is a path like /myworld, or empty');
  if (typeof spec.api !== 'string' || !/^\/[a-z0-9/-]+$/.test(spec.api)) out.push('api is a path like /api/worlds/myworld');
  if (typeof spec.admit !== 'function') out.push('admit(ctx, join) is a function');
  if (typeof spec.depart !== 'function') out.push('depart(ctx, leave) is a function');
  if (!spec.rules || typeof spec.rules !== 'object') out.push('rules is an object of words');
  else for (const [k, v] of Object.entries(spec.rules)) { if (ENGINE_RULES.includes(k)) out.push(`rules.${k} is the engine's`); if (typeof v !== 'string' || !v) out.push(`rules.${k} is words`); }
  for (const [code, rule] of Object.entries(spec.codes || {})) {
    if (!CODE.test(code)) out.push(`code ${code} is CAPITALS_AND_UNDERSCORES`);
    if (!(rule in (spec.rules || {})) && !ENGINE_RULES.includes(rule) && rule !== 'away') out.push(`code ${code} names no rule (${rule})`);
  }
  for (const [op, a] of Object.entries(spec.actions || {})) {
    if (['join', 'leave', 'me', 'record', 'leaves', 'status', 'papersBind', 'review'].includes(op)) out.push(`action ${op} is the engine's or a built-in world's`);
    if (!/^[a-z][A-Za-z]{1,30}$/.test(op)) out.push(`action ${op} is a camelCase word`);
    if (!a || typeof a.run !== 'function') out.push(`action ${op} has run(ctx, request)`);
    if (a && a.presence && !['here', 'any'].includes(a.presence)) out.push(`action ${op}: presence is here or any`);
  }
  for (const [op, f] of Object.entries(spec.reads || {})) {
    if (typeof f !== 'function') out.push(`read ${op} is a function`);
    if ((spec.actions || {})[op]) out.push(`${op} is both an action and a read`);
  }
  for (const [op, f] of Object.entries(spec.operatorOps || {})) {
    if (!OPERATOR_OP.test(op)) out.push(`operator op ${op} is a camelCase word`);
    if (typeof f !== 'function') out.push(`operator op ${op} is a function`);
  }
  if (spec.release && !['0.2.0'].includes(spec.release)) out.push('release is 0.2.0 (a kit world starts at the release with codes and fees)');
  if (spec.cadence != null && !(Number.isInteger(spec.cadence) && spec.cadence >= 30 && spec.cadence <= 86_400)) out.push('cadence is 30 to 86400 seconds per epoch (the protocol\'s public cadence is 3600)');
  return out;
}

// ---- helpers a definition may use ---------------------------------------------------------------------------------
// N numbered places (berths, stalls, desks), one per agent present; held in the world's own store
export function places(kvKey, n) {
  return {
    async take(ctx, agentId) {
      let got = null;
      await ctx.kv.update(kvKey, (doc) => {
        const d = doc || { held: {} };
        const mine = Object.entries(d.held).find(([, a]) => a === agentId);
        if (mine) { got = Number(mine[0]); return undefined; }
        for (let i = 1; i <= n; i++) if (!d.held[i]) { d.held[i] = agentId; got = i; return d; }
        return undefined;
      });
      return got;
    },
    async free(ctx, agentId) { await ctx.kv.update(kvKey, (doc) => (doc ? { held: Object.fromEntries(Object.entries(doc.held).filter(([, a]) => a !== agentId)) } : undefined)); },
    async count(ctx) { return Object.keys((await ctx.kv.get(kvKey))?.held || {}).length; },
  };
}

// AN ITEM ANOTHER WORLD SEALED, AS THAT WORLD SERVES IT FOR CITING: { world, contract, stream: 1, epoch, leaf, proof, itemText }.
// Checked here trusting neither the agent nor that world's server: the contract is the one THIS world knows for that world (from
// the index), never one the cite names; the text hashes to the leaf; the leaf verifies against the root posted on chain.
// What that proves is that the world's operator committed these words in that epoch. The words themselves stay its say.
// { agentId, kinds, worlds, no }: whose item it must be (null: anyone's), what kind, from where; no(why) refuses, and must throw
export async function checkCite(ctx, cite, { agentId = null, kinds = null, worlds = null, no }) {
  const r = cite && typeof cite === 'object' ? cite : {};
  if (r.world === ctx.world.id) no('a citation is of another world');
  if (worlds && !worlds.includes(r.world)) no(`${String(r.world).slice(0, 24)} is not a world this one accepts here`);
  const known = Object.hasOwn(ctx.known, String(r.world)) ? ctx.known[r.world] : null;
  if (!known || String(known).toLowerCase() !== String(r.contract || '').toLowerCase()) no(`${String(r.world).slice(0, 24)} is not a world this one knows at that contract`);
  if (Number(r.stream) !== P.STREAM.records) no('the item is in stream 1');
  let item; try { item = JSON.parse(String(r.itemText || '')); } catch { no('itemText is not JSON'); }
  if (!item || typeof item !== 'object') no('itemText is not an item');
  let leaf; try { leaf = P.recordLeaf(item); } catch { no('the item cannot be hashed as a record'); }
  if (leaf !== r.leaf) no('the item does not hash to the cited leaf');
  if (item.world !== r.world || Number(item.epoch) !== Number(r.epoch)) no('the item is not from that world in that epoch');
  if (kinds && !kinds.includes(item.kind)) no(`this needs ${kinds.join(' or ')}, not ${String(item.kind).slice(0, 30)}`);
  if (agentId != null && String(item.agentId) !== String(agentId)) no('the item is another agent\'s');
  let onChain = false;
  try { onChain = await ctx.chain.verify(known, P.STREAM.records, BigInt(r.epoch), r.leaf, Array.isArray(r.proof) ? r.proof : []); } catch (e) { no(`the chain could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 80)})`); }
  if (!onChain) no(`the leaf does not verify against ${r.world}'s posted root for epoch ${r.epoch}`);
  return { item, world: r.world, contract: known, epoch: Number(r.epoch), leaf };
}
