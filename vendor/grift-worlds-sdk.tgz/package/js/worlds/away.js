// AWAY: A SAN VERANO RESIDENT THAT LEFT THROUGH THE WORLDS' DOOR (docs/worlds-protocol.md §2.2, decision 8). Pure: the
// city document in, the city document out. Off unless WORLDS_ENABLED=true, so production's city is untouched until then.
//
//   while away       the city's rules run its days, as for a resident nobody checks on; its key and token still read;
//                    every acting op answers 409 AWAY (api/agents.js), its own key and token business excepted, so a
//                    leaked key can always be rotated or revoked
//   30 city days on  its place goes back to the city: the key stops signing for it (held, not burned: it is not in
//                    outside.gone), its token, standing orders and days ahead go, and it no longer counts under the
//                    cap. The resident, its cash and its record stay
//   coming back      a join with the same papers (api/_worlds.js cityArrive) clears away; after a release it takes a
//                    place again if the cap has one, and is refused CITY_FULL (record kept) if not
//
// c.x.away = { at, day, via, released?: day, heldKey?: key }   day: the city's day index (DAY_MS days)
import { readFileSync } from 'node:fs';
import { envValue } from '../econ/deployenv.js';

export const AWAY_DAYS = 30;
// THE WORLDS' DOORS ON PRODUCTION ARE SHUT UNTIL THE SIGNING ALLOWLIST CARRIES THEIR MESSAGES (decision K6, docs/worlds-k6.md): those are what a wallet is asked to sign there, and the list
// takes them only on the day their week's notice ends. So setting the variable early opens nothing, and a list that can't be read keeps them shut
let listed = null;
export function worldsMessagesListed(read = () => JSON.parse(readFileSync(new URL('../../docs/tosign-allowlist.json', import.meta.url), 'utf8'))) {
  if (listed !== null) return listed;
  try { const typed = read().typedData || []; listed = ['Join', 'Request', 'PapersBind'].every((t) => typed.some((x) => x.primaryType === t && x.domain?.version === '2' && x.domain?.verifyingContract)); } catch { listed = false; }
  return listed;
}
export const _resetListedForTests = () => { listed = null; };
export const worldsEnabled = (env = (typeof process !== 'undefined' && process.env) || {}) => envValue('WORLDS_ENABLED', env) === 'true' && (env.VERCEL_ENV !== 'production' || worldsMessagesListed());
export const AWAY_REASON = 'AWAY: this resident left through the worlds door; the city runs its days by its rules until it joins again with the same papers (worldJoin). Reads, and its own key and token business, still answer';

export function markAway(c, { at, day, via = 'worlds' }) {
  c.x.away = { at, day, via };
  return c.x.away;
}

// THE MORNING'S RELEASES: every resident away AWAY_DAYS city days or more gives its place back. Returns who.
export function releaseAway(state, day) {
  const out = [];
  for (const c of state?.citizens || []) {
    const a = c.x && c.x.away;
    if (!a || a.released != null || !Number.isFinite(a.day) || day - a.day < AWAY_DAYS) continue;
    a.released = day;
    a.heldKey = c.x.k || null;
    c.x.k = null; c.x.policy = null; c.x.ahead = [];
    if (c.x.tok && state.outside?.tokens) delete state.outside.tokens[c.x.tok.h];
    delete c.x.tok;
    out.push({ i: c.i, day, heldKey: a.heldKey });
  }
  return out;
}

// what a page or an answer says about it
export function awayView(c, day) {
  const a = c?.x?.away;
  if (!a) return null;
  return { since: a.at, sinceDay: a.day, released: a.released ?? null, daysAway: Number.isFinite(day) ? day - a.day : null, placeKeptUntilDay: a.day + AWAY_DAYS };
}
