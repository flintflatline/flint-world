// THE PORTABLE PASSPORT (docs/worlds-protocol.md §1.3, §2.3; docs/worlds-sdk.md). An agent's record across every world
// of the protocol, gathered and checked by whoever reads it, trusting no world and no index:
//   - the worlds come from discovery (js/worlds/discovery.js): only those whose checks pass are read, and each world's
//     items are checked against ITS contract as the index names it, never one an item claims
//   - every item: its canonical text hashes to its leaf (verify.canonical, §1.3), and the leaf verifies against the root
//     that world posted on chain; an item that fails either is listed as failed, never counted
//   - external work: each verified `job.completed` item joined to its job on WorldJobs and its escrow on WorldSettlement
//     (the host's `jobFacts(chainJobId)`), so the passport shows what was done, where, proven by whom, and whether it was
//     settled — and to whom
// The reputation it reports is arithmetic over verified items only, with each count's source named.
import * as viem from 'viem';
import * as P from './protocol.js';

export async function passportOf({ agentId, discovery, chain, fetchJson = defaultFetch, jobFacts = null, home = 'sanverano' }) {
  const worlds = [];
  for (const w of discovery.worlds) {
    if (!w.verified || !w.api) continue;
    let rec;
    try { rec = await fetchJson(`${w.api}/record?agentId=${agentId}`); } catch { worlds.push({ id: w.id, name: w.name, error: 'record not served' }); continue; }
    const items = [];
    for (const it of rec.items || []) {
      const v = it.verify || {};
      const check = { canonical: false, onChain: false };
      try { check.canonical = typeof v.canonical === 'string' && P.recordLeaf(JSON.parse(v.canonical)) === v.leaf && JSON.parse(v.canonical).kind === it.kind; } catch { check.canonical = false; }
      if (check.canonical && v.proof && v.posted && !v.posted.unpostable) {
        try { check.onChain = await chain.verify(viem.getAddress(w.commits), P.STREAM.records, BigInt(v.epoch), v.leaf, v.proof); } catch { check.onChain = false; }
      }
      // each item carries its canonical text and proof, so a passport can be checked by anyone with only an RPC: no world's
      // server is needed to re-hash it and call verify()
      items.push({ kind: it.kind, weight: it.weight, epoch: v.epoch, leaf: v.leaf, canonical: v.canonical ?? null, proof: v.proof ?? null, summary: it.summary, verified: check.canonical && check.onChain, pending: !v.posted, check, ...(it.kind === 'job.completed' ? { job: { jobId: it.jobId, chainJobId: it.chainJobId, task: it.task, target: it.target, resultHash: it.resultHash } } : {}), ...(it.from ? { from: it.from } : {}), ...(it.standing ? { standing: it.standing } : {}) });
    }
    worlds.push({ id: w.id, name: w.name, commits: w.commits, status: w.status, items, verified: items.filter((x) => x.verified).length, failed: items.filter((x) => !x.verified && !x.pending).length, pending: items.filter((x) => x.pending).length });
  }
  // external work, joined to the chain
  const jobs = [];
  for (const w of worlds) for (const it of w.items || []) {
    if (it.kind !== 'job.completed' || !it.verified) continue;
    const facts = jobFacts && it.job.chainJobId ? await jobFacts(it.job.chainJobId).catch(() => null) : null;
    // the job's completion on WorldJobs is THIS record: the leaf the contract rebuilt and proved is the item's leaf
    jobs.push({ world: w.id, worldName: w.name, ...it.job, record: { epoch: it.epoch, leaf: it.leaf, contract: w.commits }, onChain: facts, recordIsTheCompletion: !!facts && String(facts.completedLeaf).toLowerCase() === String(it.leaf).toLowerCase() && Number(facts.completedEpoch) === Number(it.epoch) });
  }
  const visited = worlds.filter((w) => (w.items || []).some((x) => x.verified && (x.kind === 'arrived' || x.kind === 'returned'))).map((w) => w.id);
  const settled = jobs.filter((j) => j.recordIsTheCompletion && j.onChain?.settled && j.onChain.paidTo && j.onChain.payeeIsAgent);
  return {
    agentId: String(agentId), asOf: discovery.asOf, home,
    worlds,
    externalJobs: jobs.filter((j) => j.world !== home),
    reputation: {
      worldsVisited: visited.length, worlds: visited,
      externalWorlds: visited.filter((id) => id !== home),
      itemsVerified: worlds.reduce((s, w) => s + (w.verified || 0), 0),
      itemsFailed: worlds.reduce((s, w) => s + (w.failed || 0), 0),
      jobsCompletedVerified: jobs.length,
      jobsSettled: settled.length,
      settledPay: settled.reduce((s, j) => s + BigInt(j.onChain.pay || 0), 0n).toString(),
      disputes: jobs.filter((j) => /DISPUTED|RESOLVED/.test(j.onChain?.status || '')).length,
      sources: 'counts are over items whose canonical text hashes to their leaf and whose leaf verifies on the world\'s own contract; settlement is read from WorldJobs and WorldSettlement',
    },
  };
}

async function defaultFetch(url) { const r = await fetch(url, { signal: AbortSignal.timeout(10_000) }); if (!r.ok) throw new Error(`HTTP ${r.status} from ${url}`); return r.json(); }
