// THE WORLD DEPLOYER (docs/worlds-sdk.md; the CLI is tools/worldnew.mjs). Everything a world needs on a chain, and the
// index that lists it, deployed from the city's own contracts and nothing else:
//   startAnvil()                     a local chain (31337) with anvil's public dev accounts; stopped with stop()
//   deployCore(c, { owner, monitor }) the stand-in identity registry (test chains only) and WorldIndex
//   deployWorld(c, { id, lister, index, manifestURI, signer, committer })
//                                    the world's CityCommitsV2 (streams 1 records, 2 decisions, 16 manifest), its
//                                    KeyRegistry (the city's, its signer the genesis RESPONSE_SIGNER), the committer's
//                                    gas, and its WorldIndex listing (worldId = keccak256(id))
//   scaffold(dir, { id, name, template, berths })  a new world's folder: world.json (its config) and world.mjs
// LOCAL ONLY: every deploy refuses any chain but anvil's 31337. A public deployment is the Foundry scripts' business
// (contracts/*/script/DeployPublic.s.sol), behind an explicit approval, never this module's.
import { spawn, execFileSync } from 'node:child_process';
import { readFileSync, existsSync, writeFileSync, mkdirSync, realpathSync } from 'node:fs';
import { fileURLToPath, pathToFileURL } from 'node:url';
import { dirname, join, relative, sep } from 'node:path';
import * as viem from 'viem';
import { mnemonicToAccount, privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import * as P from './protocol.js';
import { COMMITS_ABI } from './chain.js';
import { normalizeSpec, specProblems } from './worldspec.js';

const here = dirname(fileURLToPath(import.meta.url));
const CONTRACTS = join(here, '../../contracts');
export const LOCAL_CHAIN = 31337;
export const ANVIL_MNEMONIC = 'test test test test test test test test test test test junk'; // anvil's public dev mnemonic
export const devKey = (i) => viem.toHex(mnemonicToAccount(ANVIL_MNEMONIC, { addressIndex: i }).getHdKey().privateKey);
export const worldIdOf = (id) => viem.keccak256(viem.toBytes(String(id)));

// a contract's ABI and bytecode, built by forge in its project if not yet
export function artifact(project, file, name) {
  const root = join(CONTRACTS, project);
  const p = join(root, 'out', file, `${name}.json`);
  if (!existsSync(p)) execFileSync('forge', ['build', '--root', root], { stdio: 'ignore', env: { ...process.env, FOUNDRY_LINT_LINT_ON_BUILD: 'false' } });
  const a = JSON.parse(readFileSync(p, 'utf8'));
  return { abi: a.abi, bytecode: a.bytecode.object, deployed: a.deployedBytecode.object };
}

export async function startAnvil({ port = 8549, quiet = true } = {}) {
  const anvil = spawn('anvil', ['--port', String(port), '--silent', '--slots-in-an-epoch', '1', '--no-cors'], { stdio: 'ignore' }); // no page on another site reaches its unlocked accounts
  const rpc = `http://127.0.0.1:${port}`;
  const until = Date.now() + 15_000;
  for (;;) {
    try { const r = await fetch(rpc, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_chainId', params: [] }) }); if (r.ok) break; } catch { /* not up */ }
    if (Date.now() > until) { anvil.kill(); throw new Error(`anvil did not answer at ${rpc}`); }
    await new Promise((r) => setTimeout(r, 200));
  }
  void quiet;
  return { rpc, stop: () => anvil.kill(), ...clientsFor(rpc) };
}

// a public client and, per key, a wallet client; every write waits for its receipt and is logged in `txs`
// chainId: the chain these clients are for (a real chain's run attaches with js/worlds/publicnet.js and deploys through the
// Foundry scripts); guard() stays anvil's: nothing in this file deploys anywhere else, whatever the clients are for
export function clientsFor(rpc, { chainId = LOCAL_CHAIN } = {}) {
  const chainDef = viem.defineChain({ id: chainId, name: chainId === LOCAL_CHAIN ? 'anvil' : `chain ${chainId}`, nativeCurrency: { name: 'Ether', symbol: 'ETH', decimals: 18 }, rpcUrls: { default: { http: [rpc] } } });
  // a local chain mines at once: poll for receipts every 200 ms, not viem's default 4 s
  const local = /^https?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(rpc);
  const transport = () => viem.http(rpc, local ? {} : { timeout: 30_000, retryCount: 6, retryDelay: 1500 });
  const pub = viem.createPublicClient({ chain: chainDef, transport: transport(), pollingInterval: local ? 200 : 1500 });
  const txs = [];
  // A REAL CHAIN'S FEES ARE STATED, NOT GUESSED: twice the block's base fee at most and no tip, so a key's gas is what it was
  // sized for (forge and viem otherwise assume a tip that can be many times a cheap chain's whole price); anvil's are its own
  const fees = chainId === LOCAL_CHAIN ? null : async () => { const b = await pub.getBlock({ blockTag: 'latest' }); const cap = (b.baseFeePerGas ?? await pub.getGasPrice()) * 2n; return { maxFeePerGas: cap > 20_000_000n ? cap : 20_000_000n, maxPriorityFeePerGas: 0n }; };
  const walletOf = (key) => viem.createWalletClient({ account: privateKeyToAccount(key), chain: chainDef, transport: transport() });
  async function receipt(hash, label) {
    const r = await pub.waitForTransactionReceipt({ hash });
    if (r.status !== 'success') throw new Error(`${label} reverted in ${hash}`);
    txs.push({ label, tx: hash, block: Number(r.blockNumber), gasUsed: Number(r.gasUsed), from: r.from, to: r.to, contract: r.contractAddress || null });
    return r;
  }
  return {
    chainDef, pub, txs, walletOf, rpc, fees,
    async guard() { const id = await pub.getChainId(); if (id !== LOCAL_CHAIN) throw new Error(`the deployer runs on a local chain (${LOCAL_CHAIN}) only; this RPC is chain ${id}`); },
    async deploy(key, art, args, label) { const hash = await walletOf(key).deployContract({ abi: art.abi, bytecode: art.bytecode, args, ...(fees ? await fees() : {}) }); return (await receipt(hash, label)).contractAddress; },
    async write(key, address, abi, functionName, args, label) { const hash = await walletOf(key).writeContract({ address, abi, functionName, args, ...(fees ? await fees() : {}) }); await receipt(hash, label || functionName); return hash; },
    async send(key, to, value, label) { const hash = await walletOf(key).sendTransaction({ to, value, ...(fees ? await fees() : {}) }); await receipt(hash, label || 'gas'); return hash; },
    read: (address, abi, functionName, args = []) => pub.readContract({ address, abi, functionName, args }),
    mine: (n = 2) => pub.request({ method: 'anvil_mine', params: ['0x' + n.toString(16)] }),
    warp: async (seconds) => { await pub.request({ method: 'evm_increaseTime', params: [seconds] }); await pub.request({ method: 'evm_mine', params: [] }); },
  };
}

export async function deployCore(c, { owner = devKey(0), monitor = privateKeyToAccount(devKey(1)).address } = {}) {
  await c.guard();
  const reg = artifact('worldlocal', 'LocalIdentityRegistry.sol', 'LocalIdentityRegistry');
  const idx = artifact('worldindex', 'WorldIndex.sol', 'WorldIndex');
  const identity = await c.deploy(owner, reg, [], 'deploy the stand-in identity registry (test chains only)');
  // WorldIndex lists only worlds whose commits and key registry are approved code: the builds this deployer deploys
  const allowedCode = codeHashesOfWorldBuilds();
  // no listers named: listing is open, as a local network's is (a mainnet index is closed from its first block: DeployIndex)
  const index = await c.deploy(owner, idx, [privateKeyToAccount(owner).address, monitor, allowedCode, [], viem.zeroHash, [], []], 'deploy WorldIndex (allowing the CityCommitsV2 and KeyRegistry builds)');
  await c.mine();
  return { identity, index, owner, allowedCode, abis: { identity: reg.abi, index: idx.abi } };
}

// a world on chain: its commits, its key registry, its committer's gas, its listing. Keys are made here unless given:
// disposable, local; the caller keeps them (the CLI in a mode-600 file outside git, the demo in memory)
export async function deployWorld(c, { id, lister = devKey(0), index = null, manifestURI = null, signer = generatePrivateKey(), committer = generatePrivateKey(), streams = [[1, 'records'], [2, 'decisions'], [16, 'manifest']], burnLabel = null, role = P.ROLE_NAME, cadence = P.CADENCE, immediateKey = false }) {
  await c.guard();
  const cc = artifact('worldlocal', 'CityCommitsV2.sol', 'CityCommitsV2');
  // immediateKey: a WorldKeyRegistry, whose first key is active from its deployment and whose every later key waits the 7 days
  const kr = immediateKey ? artifact('worldkeys', 'WorldKeyRegistry.sol', 'WorldKeyRegistry') : artifact('worldlocal', 'KeyRegistry.sol', 'KeyRegistry');
  const listerAddr = privateKeyToAccount(lister).address;
  const commits = await c.deploy(lister, cc, [listerAddr], `${id}: deploy CityCommitsV2`);
  for (const [s, n] of streams) await c.write(lister, commits, COMMITS_ABI, 'addStream', [BigInt(s), n, cadence, privateKeyToAccount(committer).address], `${id}: addStream ${s} ${n}`);
  const roleHash = viem.keccak256(viem.toBytes(role));
  const keyRegistry = await c.deploy(lister, kr, [listerAddr, [roleHash], [privateKeyToAccount(signer).address]], `${id}: deploy KeyRegistry (genesis ${role} proposed)`);
  await c.send(devKey(0), privateKeyToAccount(committer).address, viem.parseEther('1'), `${id}: committer gas (local)`);
  let listing = null;
  if (index) {
    const idx = artifact('worldindex', 'WorldIndex.sol', 'WorldIndex');
    // a LOCAL listing: no burn happens on anvil, so the burn hash is a labelled placeholder (§4.1: checked off chain)
    const burn = viem.keccak256(viem.toBytes(burnLabel || `local placeholder burn for ${id}: no burn happens on anvil`));
    const tx = await c.write(lister, index, idx.abi, 'list', [worldIdOf(id), manifestURI || `/${id}/.well-known/world.json`, commits, keyRegistry, burn], `${id}: WorldIndex.list`);
    listing = { worldId: worldIdOf(id), tx, burn };
  }
  await c.mine();
  return { id, commits, keyRegistry, role, roleHash, cadence, lister: listerAddr, keys: { committer, signer }, signer: privateKeyToAccount(signer).address, committer: privateKeyToAccount(committer).address, listing };
}

// the runtime code hashes of the CityCommitsV2 and KeyRegistry builds deployWorld deploys (neither has immutables, so
// every deployment of a build has this codehash): what WorldIndex is told to allow
export function codeHashesOfWorldBuilds() {
  return [artifact('worldlocal', 'CityCommitsV2.sol', 'CityCommitsV2'), artifact('worldlocal', 'KeyRegistry.sol', 'KeyRegistry'), artifact('worldkeys', 'WorldKeyRegistry.sol', 'WorldKeyRegistry')].map((a) => viem.keccak256(a.deployed));
}

// the registry's 7 days, passed on anvil's clock, and the genesis key activated (as anyone may, on the day)
export async function activateAfterDelay(c, worlds) {
  const kr = artifact('worldlocal', 'KeyRegistry.sol', 'KeyRegistry');
  await c.warp(7 * 86400 + 60);
  for (const d of worlds) await c.write(devKey(0), d.keyRegistry, kr.abi, 'activateKey', [d.roleHash], `${d.id}: KeyRegistry.activateKey (after 7 days)`);
  await c.mine(4);
}

// a new world's folder, from a template: its config (world.json) and the module that defines it (world.mjs)
export const TEMPLATES = Object.freeze({ jobs: { module: 'jobs.js', factory: 'jobsWorld' }, guild: { module: 'guild.js', factory: 'guildWorld' }, policy: { module: 'policy.js', factory: 'policyWorld' } });
export function scaffold(dir, { id, name, template = 'jobs', berths = 8, seats = 6, cadence = null, spec = null, sdk = null }) {
  const t = TEMPLATES[template];
  if (!t) throw new Error(`no template ${template} (there are: ${Object.keys(TEMPLATES).join(', ')})`);
  if (existsSync(join(dir, 'world.json'))) throw new Error(`${dir}/world.json exists: a world is never overwritten`);
  mkdirSync(dir, { recursive: true });
  // the policy template's config is the spec, checked before anything is written (js/worlds/worldspec.js)
  if (template === 'policy') { const bad = specProblems({ ...(spec || {}), id, name, base: undefined, api: undefined }); if (bad.length) throw new Error(`this world's configuration has problems: ${bad.map((p) => `${p.field}: ${p.problem}`).join('; ')}`); }
  const config = template === 'policy'
    ? { ...normalizeSpec({ ...(spec || {}), ...(cadence ? { cadence: Number(cadence) } : {}), id, name, base: undefined, api: undefined }), generatedBy: 'tools/worldnew.mjs create, template policy' }
    : { id, name, base: `/${id}`, api: `/api/worlds/${id}`, template, ...(template === 'jobs' ? { berths, jobs: [], operatorDoor: true } : { seats }), ...(cadence ? { cadence: Number(cadence) } : {}), generatedBy: `tools/worldnew.mjs create, template ${template}` };
  // a world may live outside this repository: its module imports the SDK by the path from where it is, or `sdk` if given
  const sdkPath = sdk || (relative(realpathSync(dir), realpathSync(here)).split(sep).join('/') || '.'); // real paths: a folder reached through a symlink resolves from where it really is
  writeFileSync(join(dir, 'world.json'), JSON.stringify(config, null, 2) + '\n');
  const safeName = String(name).replace(/[\u0000-\u001f\u007f\u2028\u2029]/g, ' '); // it goes in a comment
  writeFileSync(join(dir, 'world.mjs'), `// ${safeName}: a world of the GRIFT worlds protocol, generated by tools/worldnew.mjs from the "${template}" template.
// Its rules are its own: edit world.json (its places, rules, cadence) or replace this definition with js/worlds/kit.js
// defineWorld. Nothing here touches San Verano's code; the engine (api/_worlds.js) runs it on its own contract and keys.
import { readFileSync } from 'node:fs';
import { ${t.factory} } from '${sdkPath}/templates/${t.module}';

const config = JSON.parse(readFileSync(new URL('./world.json', import.meta.url), 'utf8'));
export default ${t.factory}(config);
`);
  writeFileSync(join(dir, '.gitignore'), '.keys.*\n');
  return config;
}

export async function loadWorld(dir) { return (await import(pathToFileURL(join(dir, 'world.mjs')).href)).default; }
