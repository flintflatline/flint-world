// THE CROSS-WORLD JOB MARKET, FROM JS (contracts/worldjobs: WorldJobs, WorldSettlement, LocalTestToken; docs/worlds-sdk.md).
// A thin client over the deployer's clients (js/worlds/deployer.js clientsFor): every write waits for its receipt and is
// logged with its hash, block and gas; every read is the chain's. Nothing here decides anything a contract decides.
//
//   deployJobs(c, { index, identity })      LocalTestToken (refuses 4663), WorldJobs(index, identity), WorldSettlement
//   market(c, deployed)                     → { offer, fund, accept, complete, release, refund, dispute, cancel, expire,
//                                               jobOf, escrowOf, releasable, offers, released, balanceOf, mint, … }
// WITH NO SETTLEMENT (deployed.settlement null: a chain where escrow is deferred, docs/worlds-mainnet.md) the market is WorldJobs
// alone: no money moves, every job has pay 0, the money calls refuse, and each escrow reads NONE.
// LOCAL ONLY here: deployJobs runs through the deployer's guard (31337); public deployment is
// contracts/worldjobs/script/DeployPublic.s.sol, behind an explicit approval, and never with the test token on 4663.
import * as viem from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { artifact, devKey } from './deployer.js';

export const JOB_STATUS = ['NONE', 'OPEN', 'ACCEPTED', 'COMPLETED', 'DISPUTED', 'CANCELLED', 'EXPIRED', 'RESOLVED_PAID', 'RESOLVED_REFUNDED'];
export const ESCROW_STATE = ['NONE', 'HELD', 'RELEASED', 'REFUNDED'];
const ART = () => ({ jobs: artifact('worldjobs', 'WorldJobs.sol', 'WorldJobs'), settlement: artifact('worldjobs', 'WorldSettlement.sol', 'WorldSettlement'), token: artifact('worldjobs', 'LocalTestToken.sol', 'LocalTestToken') });

export async function deployJobs(c, { index, identity, owner = devKey(0), maxPerJob = viem.parseEther('10000') }) {
  await c.guard();
  const a = ART();
  const token = await c.deploy(owner, a.token, [], 'deploy LocalTestToken (WTEST: a local test token with no value; refuses 4663)');
  const jobs = await c.deploy(owner, a.jobs, [index, identity], 'deploy WorldJobs');
  const settlement = await c.deploy(owner, a.settlement, [jobs, token, maxPerJob], 'deploy WorldSettlement');
  await c.mine();
  return { token, jobs, settlement, minter: owner, maxPerJob: maxPerJob.toString() };
}

export function market(c, d) {
  const a = ART();
  const ev = [...a.jobs.abi, ...a.settlement.abi, ...a.token.abi].filter((x) => x.type === 'event');
  const steps = [];
  const receiptOf = async (hash) => c.pub.getTransactionReceipt({ hash });
  const decode = (rc) => rc.logs.map((l) => { try { const x = viem.decodeEventLog({ abi: ev, data: l.data, topics: l.topics }); return { address: viem.getAddress(l.address), event: x.eventName, args: x.args }; } catch { return null; } }).filter(Boolean);
  async function tx(key, address, abi, fn, args, label) {
    const hash = await c.write(key, address, abi, fn, args, label);
    const rc = await receiptOf(hash);
    const out = { label, tx: hash, block: Number(rc.blockNumber), gasUsed: Number(rc.gasUsed), from: rc.from, events: decode(rc) };
    steps.push(out);
    return out;
  }
  // a call expected to fail: the contract's own error name, never a write
  async function refused(key, address, abi, fn, args) {
    try { await c.pub.simulateContract({ account: privateKeyToAccount(key), address, abi, functionName: fn, args }); return { refused: false }; }
    catch (e) { const name = e?.cause?.data?.errorName || e?.data?.errorName || /reverted with the following reason:\s*\n?(.*)/.exec(String(e?.message))?.[1] || String(e?.shortMessage || e?.message).slice(0, 120); return { refused: true, error: name, args: (e?.cause?.data?.args || []).map(String) }; }
  }
  const job = async (jobId) => {
    const j = await c.read(d.jobs, a.jobs.abi, 'jobOf', [BigInt(jobId)]);
    return { jobId: String(jobId), worldId: j.worldId, specHash: j.specHash, funder: j.funder, status: JOB_STATUS[Number(j.status)], acceptBy: Number(j.acceptBy), doneBy: Number(j.doneBy), payee: j.payee, agentId: j.agentId.toString(), pay: j.pay.toString(), epoch: j.epoch.toString(), resultLeaf: j.resultLeaf, completedAt: Number(j.completedAt), offeredAt: Number(j.offeredAt), acceptedAt: Number(j.acceptedAt), evidence: j.evidence };
  };
  const escrow = async (jobId) => { if (!d.settlement) return { state: 'NONE', amount: '0' }; const [state, amount] = await c.read(d.settlement, a.settlement.abi, 'escrowOf', [BigInt(jobId)]); return { state: ESCROW_STATE[Number(state)], amount: amount.toString() }; };
  const noMoney = (what) => { if (!d.settlement) throw new Error(`${what}: no WorldSettlement on this chain, so nothing here moves money`); };
  return {
    d, abis: { jobs: a.jobs.abi, settlement: a.settlement.abi, token: a.token.abi }, steps, money: !!d.settlement,
    chainNow: async () => Number((await c.pub.getBlock({ blockTag: 'latest' })).timestamp),
    mint: (to, amount) => (noMoney('mint'), 0) || tx(d.minter, d.token, a.token.abi, 'mint', [to, BigInt(amount)], `mint ${viem.formatEther(BigInt(amount))} WTEST (local test token) to ${to}`),
    balanceOf: async (who) => { noMoney('balanceOf'); return (await c.read(d.token, a.token.abi, 'balanceOf', [who])).toString(); },
    // the world's operator: offer on WorldJobs (it must be the world's lister on WorldIndex), then escrow the pay
    async offer(listerKey, { worldId, specHash, pay, acceptBy, doneBy, label }) {
      if (!d.settlement && BigInt(pay) !== 0n) throw new Error('a job on this chain pays nothing: there is no WorldSettlement to hold its pay');
      const t = await tx(listerKey, d.jobs, a.jobs.abi, 'offer', [worldId, specHash, BigInt(pay), BigInt(acceptBy), BigInt(doneBy)], label || 'WorldJobs.offer');
      const e = t.events.find((x) => x.event === 'JobOffered');
      return { ...t, jobId: e.args.jobId.toString() };
    },
    async fund(listerKey, jobId, pay) {
      noMoney('fund');
      const ap = await tx(listerKey, d.token, a.token.abi, 'approve', [d.settlement, BigInt(pay)], `approve WorldSettlement for job ${jobId}'s pay (bounded to it)`);
      const f = await tx(listerKey, d.settlement, a.settlement.abi, 'fund', [BigInt(jobId)], `WorldSettlement.fund job ${jobId}`);
      return { approve: ap, fund: f };
    },
    accept: (agentKey, jobId, agentId) => tx(agentKey, d.jobs, a.jobs.abi, 'accept', [BigInt(jobId), BigInt(agentId)], `WorldJobs.accept job ${jobId} as agent ${agentId}`),
    // the world's completion record, as its canonical text's hash: WorldJobs rebuilds the record leaf itself (a job.completed
    // item of the job's own agent, in that epoch) and checks it against the world's own commits
    complete: (listerKey, jobId, itemHash, epoch, proof) => tx(listerKey, d.jobs, a.jobs.abi, 'complete', [BigInt(jobId), itemHash, BigInt(epoch), proof], `WorldJobs.complete job ${jobId} (its record proven against the world's own commits)`),
    release: (key, jobId) => (noMoney('release'), 0) || tx(key, d.settlement, a.settlement.abi, 'release', [BigInt(jobId)], `WorldSettlement.release job ${jobId}`),
    refund: (key, jobId) => (noMoney('refund'), 0) || tx(key, d.settlement, a.settlement.abi, 'refund', [BigInt(jobId)], `WorldSettlement.refund job ${jobId}`),
    cancel: (listerKey, jobId) => tx(listerKey, d.jobs, a.jobs.abi, 'cancel', [BigInt(jobId)], `WorldJobs.cancel job ${jobId}`),
    expire: (key, jobId) => tx(key, d.jobs, a.jobs.abi, 'expire', [BigInt(jobId)], `WorldJobs.expire job ${jobId}`),
    dispute: (key, jobId, evidence) => tx(key, d.jobs, a.jobs.abi, 'dispute', [BigInt(jobId), evidence], `WorldJobs.dispute job ${jobId}`),
    resolve: (ownerKey, jobId, payAgent, evidence) => tx(ownerKey, d.jobs, a.jobs.abi, 'resolve', [BigInt(jobId), !!payAgent, evidence], `WorldJobs.resolve job ${jobId}`),
    refusedAccept: (agentKey, jobId, agentId) => refused(agentKey, d.jobs, a.jobs.abi, 'accept', [BigInt(jobId), BigInt(agentId)]),
    refusedComplete: (key, jobId, itemHash, epoch, proof) => refused(key, d.jobs, a.jobs.abi, 'complete', [BigInt(jobId), itemHash, BigInt(epoch), proof]),
    completionLeaf: async (epoch, agentId, itemHash) => c.read(d.jobs, a.jobs.abi, 'completionLeaf', [BigInt(epoch), BigInt(agentId), itemHash]),
    refusedRelease: (key, jobId) => (noMoney('release'), 0) || refused(key, d.settlement, a.settlement.abi, 'release', [BigInt(jobId)]),
    refusedRefund: (key, jobId) => (noMoney('refund'), 0) || refused(key, d.settlement, a.settlement.abi, 'refund', [BigInt(jobId)]),
    jobOf: job,
    escrowOf: escrow,
    releasable: async (jobId) => c.read(d.jobs, a.jobs.abi, 'releasable', [BigInt(jobId)]),
    // every job offered, from the chain's own log
    async offers() {
      const logs = await c.pub.getContractEvents({ address: d.jobs, abi: a.jobs.abi, eventName: 'JobOffered', fromBlock: BigInt(d.fromBlock ?? 0) });
      return Promise.all(logs.map(async (l) => ({ ...(await job(l.args.jobId)), offerTx: l.transactionHash, escrow: await escrow(l.args.jobId) })));
    },
    // the release of a job, from the chain's own log: its tx and who was paid
    async released(jobId) {
      if (!d.settlement) return null;
      const logs = await c.pub.getContractEvents({ address: d.settlement, abi: a.settlement.abi, eventName: 'Released', args: { jobId: BigInt(jobId) }, fromBlock: BigInt(d.fromBlock ?? 0) });
      return logs[0] ? { tx: logs[0].transactionHash, payee: logs[0].args.payee, amount: logs[0].args.amount.toString(), block: Number(logs[0].blockNumber) } : null;
    },
  };
}

// what a kit world's `take` reads (ctx.jobsOnChain) and what the passport joins (jobFacts), from one market
export function hooksFor(m, { agentWalletOf = null } = {}) {
  return {
    jobsOnChain: async (chainJobId) => { const j = await m.jobOf(chainJobId); return { status: j.status, agentId: j.agentId, specHash: j.specHash, payee: j.payee }; },
    jobFacts: async (chainJobId) => {
      const j = await m.jobOf(chainJobId), e = await m.escrowOf(chainJobId), r = await m.released(chainJobId);
      const wallet = agentWalletOf ? await agentWalletOf(j.agentId) : null;
      return { status: j.status, pay: j.pay, agentId: j.agentId, payee: j.payee, escrow: e.state, settled: e.state === 'RELEASED', paidTo: r?.payee || null, releaseTx: r?.tx || null, payeeIsAgent: !!(r?.payee && (!wallet || viem.getAddress(r.payee) === viem.getAddress(wallet))), completedLeaf: j.resultLeaf, completedEpoch: j.epoch };
    },
  };
}
