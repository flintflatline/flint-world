// THE CITY'S NIGHTLY MERKLE TREE (docs/verify.md) — one module for the server
// that seals a night, the script that posts its root, and the browser that
// checks a proof, so the three can never build different trees.
//
// A LEAF is one resident at the end of one city night:
//   abi.encode(uint256 night, uint256 resident, int256 cashMicros)
// hashed twice, keccak256(keccak256(that)), so a leaf can never be read as an
// inner node. `night` is the city's day index (floor(ms / DAY_MS)), `resident`
// is the resident's number (citizen.i), `cashMicros` is the resident's city
// cash in micro-dollars (the books' own precision: $12.345678 is 12345678).
//
// THE TREE: leaves sorted by hash, ascending; each layer pairs neighbours,
// hashing the two sorted (keccak256(min ‖ max)); an odd last node is carried up
// unchanged. Sorted pairs are OpenZeppelin's MerkleProof convention, so the
// contract's verify() and any standard tool check the same proof. A proof is
// the sibling list from the leaf up.
import { keccak256, encodeAbiParameters, concat } from 'viem';

export const LEAF_TYPES = [{ type: 'uint256', name: 'night' }, { type: 'uint256', name: 'resident' }, { type: 'int256', name: 'cashMicros' }];
export const SCHEMA = 'resident-cash/1';

// city cash (dollars, carried to the micro-dollar) → integer micro-dollars
export const toMicros = (dollars) => {
  const n = Number(dollars);
  if (!Number.isFinite(n)) throw new Error(`cash ${dollars} is not a number`);
  return BigInt(Math.round(n * 1e6));
};

export function leafHash(night, resident, cashMicros) {
  const enc = encodeAbiParameters(LEAF_TYPES, [BigInt(night), BigInt(resident), BigInt(cashMicros)]);
  return keccak256(keccak256(enc));
}

const cmp = (a, b) => (BigInt(a) < BigInt(b) ? -1 : BigInt(a) > BigInt(b) ? 1 : 0);
export const hashPair = (a, b) => (cmp(a, b) <= 0 ? keccak256(concat([a, b])) : keccak256(concat([b, a])));

// leaves: [{ resident, cashMicros }] for one night → { root, layers, order }
// order[k] is the k-th leaf's index in the input, after sorting by hash
export function buildTree(night, leaves) {
  const seen = new Set();
  for (const l of leaves) {
    const id = String(l.resident);
    if (seen.has(id)) throw new Error(`resident ${id} appears twice`);
    seen.add(id);
  }
  return buildHashTree(leaves.map((l) => leafHash(night, l.resident, l.cashMicros)));
}

// THE SAME TREE OVER ANY LEAF HASHES (the v2 streams, js/verify/streams.js). A hash twice is refused:
// two identical leaves are one fact said twice, and would make one of them unprovable by position.
export function buildHashTree(hashes) {
  if (!hashes.length) throw new Error('a tree needs at least one leaf');
  if (new Set(hashes.map((h) => h.toLowerCase())).size !== hashes.length) throw new Error('a leaf appears twice');
  const hashed = hashes.map((h, k) => ({ k, h })).sort((a, b) => cmp(a.h, b.h));
  const layers = [hashed.map((x) => x.h)];
  while (layers[layers.length - 1].length > 1) {
    const prev = layers[layers.length - 1], next = [];
    for (let i = 0; i < prev.length; i += 2) next.push(i + 1 < prev.length ? hashPair(prev[i], prev[i + 1]) : prev[i]);
    layers.push(next);
  }
  return { root: layers[layers.length - 1][0], layers, order: hashed.map((x) => x.k) };
}

// the proof for the leaf at sorted position `pos`
export function proofAt(layers, pos) {
  const proof = [];
  for (let d = 0; d < layers.length - 1; d++) {
    const layer = layers[d], sib = pos ^ 1;
    if (sib < layer.length) proof.push(layer[sib]);
    pos = pos >> 1;
  }
  return proof;
}

// fold a proof up from a leaf hash; the root it reaches
export const rootFrom = (leaf, proof) => proof.reduce((h, p) => hashPair(h, p), leaf);
export const verifyProof = (leaf, proof, root) => rootFrom(leaf, proof).toLowerCase() === String(root).toLowerCase();

// the contract's read side, for viem's readContract
export const CITY_COMMITS_ABI = [
  { type: 'function', name: 'rootOf', stateMutability: 'view', inputs: [{ name: 'night', type: 'uint256' }], outputs: [{ type: 'bytes32' }] },
  { type: 'function', name: 'commitOf', stateMutability: 'view', inputs: [{ name: 'night', type: 'uint256' }], outputs: [{ name: 'root', type: 'bytes32' }, { name: 'leafCount', type: 'uint64' }, { name: 'postedAt', type: 'uint64' }, { name: 'postedBlock', type: 'uint64' }] },
  { type: 'function', name: 'latestNight', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'nightCount', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256' }] },
  { type: 'function', name: 'committer', stateMutability: 'view', inputs: [], outputs: [{ type: 'address' }] },
  { type: 'function', name: 'verify', stateMutability: 'view', inputs: [{ name: 'night', type: 'uint256' }, { name: 'leaf', type: 'bytes32' }, { name: 'proof', type: 'bytes32[]' }], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'commit', stateMutability: 'nonpayable', inputs: [{ name: 'night', type: 'uint256' }, { name: 'root', type: 'bytes32' }, { name: 'leafCount', type: 'uint64' }], outputs: [] },
];
