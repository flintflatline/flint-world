// THE V2 STREAMS (docs/verify.md, contracts/citycommits/src/CityCommitsV2.sol) — what each stream's leaf
// is, one definition for the server that seals, the cron that posts and the browser that checks.
//
// Every leaf is keccak256(keccak256(abi.encode(...fields))) and every tree the v1 tree (js/verify/tree.js
// buildHashTree): sorted pairs, OpenZeppelin's convention. Cash stays on CityCommits v1 (resident-cash/1).
//
//   id stream      cadence      epoch            leaf
//   2  decisions   city night   night            (night, resident, kind, keccak(reason), keccak(trace))
//   3  businesses  city night   night            (night, business, salesMicros, orders, griftBoughtRaw, griftBurntRaw)
//   4  x402        city tick    tick             (tick, payer, endpoint, priceRaw, settleTx, keccak(response body))
//   5  hook        city night   night            (night, business, tx, keccak(reason), burntRaw)
//   6  loans       city night   night            (night, loan, resident, principalMicros, rateBps, status) — the Bank of
//                                                 San Verano's credit desk's whole book as it stood that night
//
// A night is floor(ms / 30 min) and a tick floor(ms / 2 min), both of the unix clock, so the contract's
// "no far-future epoch" bound (block.timestamp / cadence + 1) is the same clock.
import { keccak256, encodeAbiParameters, toBytes, getAddress } from 'viem';
import { buildHashTree, proofAt, rootFrom } from './tree.js';

export const NIGHT_SECONDS = 1800, TICK_SECONDS = 120;
const sha = (text) => keccak256(toBytes(String(text ?? '')));
const leafOf = (types, values) => keccak256(keccak256(encodeAbiParameters(types, values)));

// CANONICAL JSON: keys sorted at every depth, no spaces — the text a trace's hash is taken of
export function canonical(v) {
  if (Array.isArray(v)) return `[${v.map(canonical).join(',')}]`;
  if (v && typeof v === 'object') return `{${Object.keys(v).filter((k) => v[k] !== undefined).sort().map((k) => `${JSON.stringify(k)}:${canonical(v[k])}`).join(',')}}`;
  return JSON.stringify(v ?? null);
}

export const STREAMS = {
  decisions: {
    id: 2, key: 'decisions', label: 'Decisions', cadence: NIGHT_SECONDS, epochName: 'night', schema: 'decisions/1',
    // a leaf as kept: { resident, kind, reason, traceHash } — the reason as TEXT, hashed into the leaf; the trace's
    // text served beside it (api/verify.js traceText) and its hash checked in the browser
    types: [{ type: 'uint256', name: 'night' }, { type: 'uint256', name: 'resident' }, { type: 'string', name: 'kind' }, { type: 'bytes32', name: 'reasonHash' }, { type: 'bytes32', name: 'traceHash' }],
    leaf: (night, l) => leafOf(STREAMS.decisions.types, [BigInt(night), BigInt(l.resident), String(l.kind), sha(l.reason), l.traceHash || sha(l.trace)]),
    idOf: (l) => String(l.resident),
    findBy: 'resident',
  },
  businesses: {
    id: 3, key: 'businesses', label: 'Businesses', cadence: NIGHT_SECONDS, epochName: 'night', schema: 'businesses/1',
    // { business, salesMicros, orders, boughtRaw, burntRaw }: sales in city micro-dollars, $GRIFT in raw units (18 decimals)
    types: [{ type: 'uint256', name: 'night' }, { type: 'string', name: 'business' }, { type: 'int256', name: 'salesMicros' }, { type: 'uint256', name: 'orders' }, { type: 'uint256', name: 'griftBoughtRaw' }, { type: 'uint256', name: 'griftBurntRaw' }],
    leaf: (night, l) => leafOf(STREAMS.businesses.types, [BigInt(night), String(l.business), BigInt(l.salesMicros), BigInt(l.orders), BigInt(l.boughtRaw), BigInt(l.burntRaw)]),
    idOf: (l) => String(l.business),
    findBy: 'business',
  },
  x402: {
    id: 4, key: 'x402', label: 'x402', cadence: TICK_SECONDS, epochName: 'tick', schema: 'x402/1',
    // { payer, endpoint, priceRaw, settleTx, bodyHash }: one paid call, as its settle receipt and the body it was answered with
    types: [{ type: 'uint256', name: 'tick' }, { type: 'address', name: 'payer' }, { type: 'string', name: 'endpoint' }, { type: 'uint256', name: 'priceRaw' }, { type: 'bytes32', name: 'settleTx' }, { type: 'bytes32', name: 'bodyHash' }],
    leaf: (tick, l) => leafOf(STREAMS.x402.types, [BigInt(tick), getAddress(l.payer), String(l.endpoint), BigInt(l.priceRaw), l.settleTx, l.bodyHash]),
    idOf: (l) => String(l.settleTx).toLowerCase(),
    findBy: 'tx',
  },
  hook: {
    id: 5, key: 'hook', label: 'Hook', cadence: NIGHT_SECONDS, epochName: 'night', schema: 'hook/2',
    // { business, tx, reason, burntRaw }: a business's buy through the wrapper on the pons pool, as its Bought event
    // says it (buyer → business, the reason it gave, the $GRIFT burnt in the same transaction); the reason is the
    // TEXT, hashed into the leaf
    types: [{ type: 'uint256', name: 'night' }, { type: 'string', name: 'business' }, { type: 'bytes32', name: 'tx' }, { type: 'bytes32', name: 'reasonHash' }, { type: 'uint256', name: 'burntRaw' }],
    leaf: (night, l) => leafOf(STREAMS.hook.types, [BigInt(night), String(l.business), l.tx, sha(l.reason), BigInt(l.burntRaw)]),
    idOf: (l) => String(l.tx).toLowerCase(),
    findBy: 'tx',
  },
  loans: {
    id: 6, key: 'loans', label: 'Loans', cadence: NIGHT_SECONDS, epochName: 'night', schema: 'loans/1',
    // { loan, resident, principalMicros, rateBps, status }: one loan on the credit desk's book (js/econ/creditrules.js leafOf) —
    // its id, the borrower's resident number, the principal in city micro-dollars, the flat rate in basis points, and
    // active | repaid | default as it stood that night. City cash: nothing here is $GRIFT.
    types: [{ type: 'uint256', name: 'night' }, { type: 'string', name: 'loan' }, { type: 'uint256', name: 'resident' }, { type: 'int256', name: 'principalMicros' }, { type: 'uint256', name: 'rateBps' }, { type: 'string', name: 'status' }],
    leaf: (night, l) => leafOf(STREAMS.loans.types, [BigInt(night), String(l.loan), BigInt(l.resident), BigInt(l.principalMicros), BigInt(l.rateBps), String(l.status)]),
    idOf: (l) => String(l.loan),
    findBy: 'loan',
  },
};
export const STREAM_LIST = Object.values(STREAMS);
export const streamById = (id) => STREAM_LIST.find((s) => s.id === Number(id)) || null;
export { sha as textHash };

// one epoch's tree over its leaves (as kept, not hashed)
export function streamTree(stream, epoch, leaves) {
  const s = typeof stream === 'string' ? STREAMS[stream] : stream;
  return buildHashTree(leaves.map((l) => s.leaf(epoch, l)));
}
export function streamProof(stream, epoch, leaves, k) {
  const s = typeof stream === 'string' ? STREAMS[stream] : stream;
  const { root, layers, order } = streamTree(s, epoch, leaves);
  return { root, leaf: s.leaf(epoch, leaves[k]), proof: proofAt(layers, order.indexOf(k)) };
}
export { rootFrom };

// CityCommitsV2's read side and its posts, for viem
export const CITY_COMMITS_V2_ABI = [
  { type: 'function', name: 'rootOf', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'epoch', type: 'uint256' }], outputs: [{ type: 'bytes32' }] },
  { type: 'function', name: 'commitOf', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'epoch', type: 'uint256' }], outputs: [{ name: 'root', type: 'bytes32' }, { name: 'count', type: 'uint64' }, { name: 'postedAt', type: 'uint64' }] },
  { type: 'function', name: 'streamOf', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }], outputs: [{ name: 'name', type: 'string' }, { name: 'cadence', type: 'uint32' }, { name: 'committer', type: 'address' }, { name: 'latestEpoch', type: 'uint64' }, { name: 'commitCount', type: 'uint64' }] },
  { type: 'function', name: 'allStreams', stateMutability: 'view', inputs: [], outputs: [{ type: 'uint256[]' }] },
  { type: 'function', name: 'verify', stateMutability: 'view', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'epoch', type: 'uint256' }, { name: 'leaf', type: 'bytes32' }, { name: 'proof', type: 'bytes32[]' }], outputs: [{ type: 'bool' }] },
  { type: 'function', name: 'commit', stateMutability: 'nonpayable', inputs: [{ name: 'streamId', type: 'uint256' }, { name: 'epoch', type: 'uint256' }, { name: 'root', type: 'bytes32' }, { name: 'count', type: 'uint64' }], outputs: [] },
  { type: 'function', name: 'commitBatch', stateMutability: 'nonpayable', inputs: [{ name: 'streamIds', type: 'uint256[]' }, { name: 'epochs', type: 'uint256[]' }, { name: 'roots', type: 'bytes32[]' }, { name: 'counts', type: 'uint64[]' }], outputs: [] },
  { type: 'event', name: 'Committed', inputs: [{ name: 'streamId', type: 'uint256', indexed: true }, { name: 'epoch', type: 'uint256', indexed: true }, { name: 'root', type: 'bytes32', indexed: false }, { name: 'count', type: 'uint256', indexed: false }, { name: 'committer', type: 'address', indexed: true }] },
];
