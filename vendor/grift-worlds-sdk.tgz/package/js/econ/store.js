// THE ECONOMY STORE — the one interface every record goes through, and the
// adapters behind it.
//
//   get(key)                      → value or null (values carry `_v`, a version)
//   list(prefix)                  → every value under a key prefix
//   commit(reads, writes)         → atomically: every read's version still
//                                   holds (null = the key must not exist),
//                                   then every write lands with a bumped
//                                   version. Throws CONFLICT otherwise.
//   dump() / load(snapshot)       → the whole store, for tests of a restart
//
// MemoryStore is the development and test adapter, and what a Vercel
// function has when nothing durable is configured: honest about it, one
// instance's memory, gone on a cold start. KvStore is the production
// boundary: a Redis-protocol REST store (Upstash / Vercel KV) with the
// compare-and-swap done in one Lua script so two buyers cannot both win a
// listing. It is exercised by tests only through a fake REST endpoint.

import { econStoreTag } from './deployenv.js';

export class ConflictError extends Error { constructor(key) { super(`CONFLICT ${key}`); this.code = 'CONFLICT'; this.key = key; } }

export class MemoryStore {
  constructor() { this.map = new Map(); this.sides = new Map(); this.kind = 'memory'; }
  async get(key) { const v = this.map.get(key); return v === undefined ? null : clone(v); }
  async list(prefix) { const out = []; for (const [k, v] of this.map) if (k.startsWith(prefix)) out.push(clone(v)); return out; }
  // the keys under a prefix, without their values; and the values of a list of keys
  async listKeys(prefix) { const out = []; for (const k of this.map.keys()) if (k.startsWith(prefix)) out.push(k); return out; }
  async getMany(keys) { return keys.map((k) => { const v = this.map.get(k); return v === undefined ? null : clone(v); }); }
  // SIDE VALUES (js/econ/house.js "sides"): plain strings under their own
  // keys, uploaded with an expiry and made permanent by the commit that names
  // them — the memory twin of SET … EX and the CAS script's PERSIST/EXPIRE.
  // set-if-absent, as KvStore's: a value already there is the same value
  // (the key names its content) and may already be one a document relies on
  async putSide(key, s, ttlSec = 3600) { if (this.sides.has(key)) return; this._expireSide(key, ttlSec); this.sides.get(key).s = s; }
  async getSide(key) { const v = this.sides.get(key); return v ? v.s : null; }
  _expireSide(key, ttlSec) {
    const cur = this.sides.get(key) || { s: null, t: null };
    if (cur.t) clearTimeout(cur.t);
    cur.t = ttlSec == null ? null : setTimeout(() => this.sides.delete(key), ttlSec * 1000);
    if (cur.t && cur.t.unref) cur.t.unref();
    this.sides.set(key, cur);
  }
  async commit(reads = [], writes = [], { persist = [], expire = [], ttl = 600 } = {}) {
    for (const r of reads) {
      const cur = this.map.get(r.key);
      const v = cur === undefined ? null : cur._v;
      if ((r.version ?? null) !== (v ?? null)) throw new ConflictError(r.key);
    }
    for (const k of persist) if (!this.sides.has(k)) throw new ConflictError(k);
    for (const w of writes) {
      const cur = this.map.get(w.key);
      const next = { ...clone(w.value), _v: (cur?._v || 0) + 1 };
      this.map.set(w.key, next);
    }
    for (const k of persist) if (this.sides.has(k)) this._expireSide(k, null);
    for (const k of expire) if (this.sides.has(k)) this._expireSide(k, ttl);
  }
  // COMPACTION NEEDS THE KEYS, not just the values: list() returns rows with
  // no way to address them, and you cannot delete what you cannot name.
  async listWithKeys(prefix) {
    const out = [];
    for (const [k, v] of this.map) if (k.startsWith(prefix)) out.push({ key: k, value: clone(v) });
    return out;
  }
  // the memory twin of SWAP_LUA: indivisible here for free, single-threaded
  async swap(deleteKeys = [], writes = []) {
    let gone = 0;
    for (const k of deleteKeys) if (this.map.delete(k)) gone++;
    for (const w of writes) {
      const cur = this.map.get(w.key);
      this.map.set(w.key, { ...clone(w.value), _v: (cur?._v || 0) + 1 });
    }
    return gone;
  }
  async dump() { return JSON.stringify([...this.map]); }
  async load(snapshot) { this.map = new Map(JSON.parse(snapshot)); }
  async clear() { this.map.clear(); for (const k of [...this.sides.keys()]) this._expireSide(k, 0); this.sides.clear(); }
  // the same health shape KvStore answers, so a probe reads one field name
  async stats() {
    let bytes = 0;
    for (const [k, v] of this.map) bytes += k.length + JSON.stringify(v).length;
    return { kind: 'memory', keys: this.map.size, usedBytes: bytes, maxBytes: null, policy: 'none (in-process)', evicting: false };
  }
}
const clone = (v) => JSON.parse(JSON.stringify(v));

// ---- the durable adapter: Redis-protocol REST (Upstash / Vercel KV) ----
// THE MOST ONE REQUEST CARRIES. Upstash's ceiling is 1 MB; a part stops well
// short of it (560 KiB, under 600 KB with the headers and the count members)
// so no write the city makes approaches the cap — the rule the 4,000-resident
// city was sized to (docs/city-4000.md). It was 900 KiB; a night's rows at
// 4,000 now land in three parts rather than two, a round trip more.
export const MAX_PART_BYTES = 560 * 1024;
// a SCAN page, and an MGET's keys: a ledger key is about 40 bytes and a row
// about 300, so a chunk is 20 KB out and 150 KB back
const SCAN_COUNT = 2000, MGET_CHUNK = 500, MGET_LANES = 4;
const utf8 = (s) => new TextEncoder().encode(s).length;
// Env: KV_REST_API_URL, KV_REST_API_TOKEN. Keys are namespaced; a commit is
// a single EVAL so the version checks and the writes are one operation on
// the server. Nothing here is exercised against a real store in this
// repository — the boundary is the promise, the fake in test/ is the proof.
// THE VERSION IS STAMPED IN BY STRING, NOT BY RE-ENCODING THE DOCUMENT. The
// first version of these scripts did cjson.decode(val), set _v, and wrote
// cjson.encode(obj) back — and the store behind Vercel KV encodes an EMPTY
// Lua table as [] (a Go-side JSON library cannot tell an empty object from an
// empty array). So every map a business saved while it was still empty came
// back as an array, every key set on it after that was dropped by the next
// JSON.stringify, and a guard that lived in such a map never held: the
// night market's mirrored-take guard read empty on every heartbeat and the
// same take booked itself again every five minutes. The client writes
// objects only (commit() and swap() strip any _v first), so the document is
// stored byte for byte as JSON.stringify produced it, with `"_v":N` as its
// first member. Reading the version still decodes — decode is fine.
const STAMP_LUA = `
local function stamp(val, v)
  local n = string.format('%d', v)
  if string.len(val) <= 2 then return '{"_v":' .. n .. '}' end
  return '{"_v":' .. n .. ',' .. string.sub(val, 2)
end`;
const CAS_LUA = STAMP_LUA + `
local n = tonumber(ARGV[1])
for i = 1, n do
  local key = KEYS[i]
  local want = ARGV[1 + i]
  local cur = redis.call('GET', key)
  local have = 'null'
  if cur then have = cjson.decode(cur)['_v'] end
  if tostring(have) ~= tostring(want) then return {err = 'CONFLICT ' .. key} end
end
local m = tonumber(ARGV[2 + n])
-- A DOCUMENT'S SIDE VALUES, MADE PERMANENT WITH IT (js/econ/house.js, "sides").
-- Each was uploaded first under its own content-named key with an expiry;
-- the script that lands the document naming them makes them permanent and
-- gives the ones the document stopped naming a short expiry of their own.
-- One that has gone missing since it was uploaded is a CONFLICT, before
-- anything is written, and the writer uploads it again. Optional and
-- trailing: a commit without them runs exactly as before.
local base = 3 + n + m
local p = 0
if ARGV[base] then p = tonumber(ARGV[base]) end
local e = 0
if ARGV[base + 1] then e = tonumber(ARGV[base + 1]) end
for k = 1, p do
  if redis.call('EXISTS', KEYS[n + m + k]) == 0 then return {err = 'CONFLICT ' .. KEYS[n + m + k]} end
end
for j = 1, m do
  local key = KEYS[n + j]
  local val = ARGV[2 + n + j]
  local cur = redis.call('GET', key)
  local v = 0
  if cur then v = cjson.decode(cur)['_v'] end
  redis.call('SET', key, stamp(val, v + 1))
end
for k = 1, p do redis.call('PERSIST', KEYS[n + m + k]) end
for k = 1, e do redis.call('EXPIRE', KEYS[n + m + p + k], ARGV[base + 2]) end
return 'OK'`;
// COMPACTION'S ONE ATOMIC STEP. Rolling a day up means writing its summary
// rows and deleting the originals, and those two must be INDIVISIBLE: a crash
// after the write and before the delete double-counts the day in every future
// reconcile, silently and permanently. Redis runs a script to completion, so
// one EVAL is the whole guarantee.
//
// Deletes come first, then writes, and js/econ/compact.js guarantees the two
// key sets never overlap — so a summary that lands on an existing summary's
// key updates it rather than being deleted by its own batch.
const SWAP_LUA = STAMP_LUA + `
local d = tonumber(ARGV[1])
local w = tonumber(ARGV[2])
local gone = 0
for i = 1, d do gone = gone + redis.call('DEL', KEYS[i]) end
for j = 1, w do
  local key = KEYS[d + j]
  local cur = redis.call('GET', key)
  local v = 0
  if cur then v = cjson.decode(cur)['_v'] end
  redis.call('SET', key, stamp(ARGV[2 + j], v + 1))
end
return gone`;
// what goes over the wire: a plain object, its own _v (if it came from a read) left behind — the script stamps the new one in
const wire = (v) => {
  if (!v || typeof v !== 'object' || Array.isArray(v)) throw new Error('the store writes objects only');
  const { _v, ...rest } = v;
  return JSON.stringify(rest);
};
export const _wireForTests = wire;
export const _luaForTests = () => ({ CAS_LUA, SWAP_LUA });

export class KvStore {
  constructor({ url = process.env.KV_REST_API_URL, token = process.env.KV_REST_API_TOKEN, ns = 'grift:econ:', fetchImpl = fetch } = {}) {
    if (!url || !token) throw new Error('KV_REST_API_URL and KV_REST_API_TOKEN are required');
    this.url = url.replace(/\/$/, ''); this.token = token; this.ns = ns; this.fetchImpl = fetchImpl; this.kind = 'kv';
  }
  async cmd(...args) {
    const r = await this.fetchImpl(this.url, { method: 'POST', headers: { authorization: `Bearer ${this.token}`, 'content-type': 'application/json' }, body: JSON.stringify(args) });
    const j = await r.json();
    if (j.error) { if (/CONFLICT/.test(j.error)) throw new ConflictError(j.error.replace('CONFLICT ', '')); throw new Error(j.error); }
    return j.result;
  }
  async get(key) { const s = await this.cmd('GET', this.ns + key); return s ? JSON.parse(s) : null; }
  // a side value: a plain string under its own key, uploaded with an expiry
  // that the commit naming it lifts (CAS_LUA's trailing PERSIST/EXPIRE).
  // NX: the key names its content, so one already there is this value — and
  // may be one a document already relies on, whose expiry must not be reset.
  async putSide(key, s, ttlSec = 3600) { await this.cmd('SET', this.ns + key, s, 'EX', String(ttlSec), 'NX'); }
  async getSide(key) { return this.cmd('GET', this.ns + key); }
  // A LEDGER HAS OUTGROWN ONE CALL. list() used to SCAN every key and hand all
  // of them to ONE MGET by spreading the array into the call's arguments. Past
  // about 125,000 keys that spread overflows the stack ("Maximum call stack
  // size exceeded" — the casino's compaction and the city's ledger window read
  // on production, 2026-10-01), and long before it the request itself would be
  // over the megabyte Upstash accepts. Keys now come back a SCAN page at a
  // time, and values in MGETs of MGET_CHUNK keys, a few in flight at once.
  async listKeys(prefix) {
    const keys = []; let cursor = '0';
    do {
      const [next, batch] = await this.cmd('SCAN', cursor, 'MATCH', `${this.ns}${prefix}*`, 'COUNT', String(SCAN_COUNT));
      cursor = String(next);
      for (const k of batch) keys.push(k.slice(this.ns.length));
    } while (cursor !== '0');
    return keys;
  }
  // the parsed values of `keys` (not namespaced), in order, null where absent
  async getMany(keys) {
    const out = new Array(keys.length).fill(null);
    let next = 0;
    const lane = async () => {
      while (next < keys.length) {
        const at = next; next += MGET_CHUNK;
        const vals = await this.cmd('MGET', ...keys.slice(at, at + MGET_CHUNK).map((k) => this.ns + k));
        for (let i = 0; i < vals.length; i++) out[at + i] = vals[i] ? JSON.parse(vals[i]) : null;
      }
    };
    await Promise.all(Array.from({ length: Math.min(MGET_LANES, Math.ceil(keys.length / MGET_CHUNK)) }, lane));
    return out;
  }
  async list(prefix) {
    return (await this.getMany(await this.listKeys(prefix))).filter(Boolean);
  }
  // A REQUEST HAS A CEILING, AND ONE NIGHT AT 1,200 RESIDENTS IS OVER IT.
  // Upstash refuses a body over 1 MB. The city's planner commits the city's
  // document and one PLAN row per resident together, and the vote the document
  // and one VOTE row each: at 1,200 residents that is a 680 KB document beside
  // 300 to 420 KB of rows, 1.1 to 1.2 MB on the wire, and the vote's commit
  // passes the megabyte at about 950 residents (docs/city-500.md). One EVAL
  // cannot carry it, so a commit that would not fit is sent in PARTS, each
  // under MAX_PART_BYTES: the first carries every version check and the first
  // writes — every caller puts the document those checks guard first — and
  // the rest follow with no checks. The checks and the document are still one
  // operation, so a conflict still costs nothing and lands nothing. What is
  // no longer atomic with them is the tail of NEW rows under keys of their
  // own, which nothing else writes, and which the document's own recentLedger
  // carries meanwhile. A part that fails throws like any command, after the
  // document has landed. A single write larger than a part goes alone, and
  // fails as it always did.
  // `persist` and `expire` name side values (putSide): made permanent, or
  // given `ttl` seconds, in the FIRST part — the one script that checks the
  // versions and lands the document naming them.
  async commit(reads = [], writes = [], extra = {}) {
    for (const part of this.parts(reads, writes, extra)) await this.cmd('EVAL', CAS_LUA, ...part);
  }
  // the EVAL arguments of each part, measured as the request body would be:
  // one JSON array, each member with its quotes, escapes and comma
  parts(reads = [], writes = [], { persist = [], expire = [], ttl = 600 } = {}) {
    const member = (s) => utf8(JSON.stringify(s)) + 1;
    const checks = reads.map((r) => this.ns + r.key), versions = reads.map((r) => String(r.version ?? 'null'));
    const sideKeys = [...persist, ...expire].map((k) => this.ns + k);
    const rows = writes.map((w) => { const key = this.ns + w.key, val = wire(w.value); return { key, val, bytes: member(key) + member(val) }; });
    const fixed = member('EVAL') + member(CAS_LUA) + 3 * member('00000');
    const head = fixed + checks.reduce((n, k) => n + member(k), 0) + versions.reduce((n, v) => n + member(v), 0)
      + sideKeys.reduce((n, k) => n + member(k), 0) + 3 * member('00000');
    const out = [];
    let i = 0;
    do {
      const first = out.length === 0;
      let bytes = first ? head : fixed;
      const take = [];
      while (i < rows.length && (take.length === 0 || bytes + rows[i].bytes <= MAX_PART_BYTES)) { bytes += rows[i].bytes; take.push(rows[i]); i++; }
      const keys = [...(first ? checks : []), ...take.map((r) => r.key), ...(first ? sideKeys : [])];
      out.push([String(keys.length), ...keys, ...(first ? [String(reads.length), ...versions] : ['0']), String(take.length), ...take.map((r) => r.val),
        ...(first && sideKeys.length ? [String(persist.length), String(expire.length), String(ttl)] : [])]);
    } while (i < rows.length);
    return out;
  }
  // SCAN gives keys; MGET gives values; compaction needs them paired, because
  // a row it cannot name is a row it cannot delete.
  async listWithKeys(prefix) {
    const keys = await this.listKeys(prefix);
    const vals = await this.getMany(keys);
    const out = [];
    for (let i = 0; i < keys.length; i++) if (vals[i]) out.push({ key: keys[i], value: vals[i] });
    return out;
  }
  // deletes and writes in ONE script — see the note on SWAP_LUA
  async swap(deleteKeys = [], writes = []) {
    if (!deleteKeys.length && !writes.length) return 0;
    const keys = [...deleteKeys.map((k) => this.ns + k), ...writes.map((w) => this.ns + w.key)];
    const args = [String(deleteKeys.length), String(writes.length), ...writes.map((w) => wire(w.value))];
    return Number(await this.cmd('EVAL', SWAP_LUA, String(keys.length), ...keys, ...args));
  }
  async dump() { throw new Error('dump is a test affordance of the memory store'); }

  // ---- WHAT THE STORE ITSELF SAYS ABOUT ITS HEALTH ------------------------
  // The books are only auditable while the oldest line still exists. Under an
  // LRU policy a full database silently drops the OLDEST keys first, and the
  // oldest key a business has is its SEED_CAPITAL row — so the first thing a
  // full store costs is the drift gate, with no error anywhere. The preview's
  // bar has already lost its seed row this way (reconcile reads drift $500,
  // seed 0, and has since before the heartbeat existed).
  //
  // This reads Redis's own numbers rather than estimating from row counts.
  // maxmemory 0 means "no limit configured on the instance" — a hosted plan
  // can still cap the database above that, so a 0 here is reported as unknown
  // rather than as headroom.
  async stats() {
    const out = { kind: 'kv', keys: null, usedBytes: null, maxBytes: null, policy: null, evicting: null };
    try { out.keys = Number(await this.cmd('DBSIZE')); } catch (e) { out.keysError = String(e.message || e); }
    try {
      const info = String(await this.cmd('INFO', 'memory') || '');
      const field = (n) => { const m = info.match(new RegExp(`^${n}:(.*)$`, 'm')); return m ? m[1].trim() : null; };
      const used = field('used_memory'), max = field('maxmemory'), pol = field('maxmemory_policy');
      if (used != null) out.usedBytes = Number(used);
      if (max != null) out.maxBytes = Number(max) || null;
      if (pol != null) out.policy = pol;
    } catch (e) { out.infoError = String(e.message || e); }
    if (out.policy == null) {
      try { const c = await this.cmd('CONFIG', 'GET', 'maxmemory-policy'); if (Array.isArray(c) && c[1]) out.policy = String(c[1]); } catch { /* CONFIG is often disabled on hosted Redis */ }
    }
    // AN LRU OR RANDOM POLICY EVICTS THE BOOKS. noeviction fails the write
    // instead, which is loud and recoverable; anything else is silent loss.
    out.evicting = out.policy == null ? null : !/^noeviction$/i.test(out.policy);
    if (out.usedBytes != null && out.maxBytes) out.usedPct = Math.round((out.usedBytes / out.maxBytes) * 1000) / 10;
    return out;
  }
}

// ---- what an endpoint calls the store it is on -----------------------------
// THE FIELD IS `store`, everywhere, on every view. api/economy.js,
// api/token.js, api/casino.js and api/stockpayout.js already answered under
// that name; the bar and the gym answered `storeKind` instead, so a status
// check across the venues had to know which venue it was asking before it
// could read the one field that says whether the numbers survive a deploy.
// A venue stamps its answers through `withStore` and is consistent for free —
// including the fourth one, whenever it lands.
export const storeKindOf = (store) => (store ? store.kind : 'memory');
export const withStore = (body, store) => ({ ...body, store: storeKindOf(store) });

// THE NAMESPACE A DEPLOYMENT'S ECONOMY LIVES UNDER. Untagged, it is the one
// production has always used. A preview shares production's Upstash database
// (docs/poker-night.md), so a preview that writes the city writes production's
// city — unless it carries a tag (GRIFT_ECON_STORE_TAG, or its branch entry in
// js/econ/deployenv.js), which gives it `grift:econ:<tag>:` and a whole economy
// of its own: residents, venues, wallets and ledgers together, so nothing in it
// can reach across to a book it cannot see.
export const econNamespace = (env = process.env) => {
  const tag = econStoreTag(env);
  return tag ? `grift:econ:${tag}:` : 'grift:econ:';
};

// what a deployment has: KV when configured, memory (and a warning) otherwise
export function storeFromEnv(env = process.env) {
  // the same two variables the profile store reads (api/profile.js), under
  // either of the names the Upstash integration sets
  const url = env.KV_REST_API_URL || env.UPSTASH_REDIS_REST_URL;
  const token = env.KV_REST_API_TOKEN || env.UPSTASH_REDIS_REST_TOKEN;
  if (url && token) return new KvStore({ url, token, ns: econNamespace(env) });
  return new MemoryStore();
}
