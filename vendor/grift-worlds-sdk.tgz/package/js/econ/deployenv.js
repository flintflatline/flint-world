// A BRANCH PREVIEW'S OWN SETTINGS, KEPT IN THE REPOSITORY.
//
// A preview built to be walked needs a few settings production does not have:
// a store of its own, so what it does cannot land in production's books, and
// the knobs that make the thing under review happen while somebody is looking.
// Those would normally be Vercel environment variables scoped to the branch.
// When they cannot be set that way, they live here instead, keyed by branch.
//
// THIS CANNOT REACH PRODUCTION. A value here is read only when Vercel itself
// says the deployment is a preview (VERCEL_ENV) AND the deployment was built
// from the branch named (VERCEL_GIT_COMMIT_REF). Production is never
// 'preview', so the map is inert there, even after the branch is merged. A
// real environment variable always wins over anything here, so an operator
// can override or switch off any line without a commit.
//
// Keep the entries few and the values plain: this is config, not a feature.
export const PREVIEW_ENV = {
  // SAN VERANO AT 4,000 (docs/city-4000.md): a city of its own (nothing reaches production's books or residents), born at
  // production's size and grown to 4,000 over fourteen opening days at the wave's cap, so the first read is the city at
  // its target with fourteen waves behind it; the residents in shards (the layout is the code's default); hiring at the
  // rate the road to 4,000 needs; the planner on under a budget of two nights; Raeto's A/B off here, so the night's
  // time is the one road's (the cohort's routing is another branch's); the preview's night door (GET
  // /api/raeto?op=preview-night: a preview has no cron) open without the secret. CITY_LANES is not here: api/city.js
  // reads it from the real environment only, so this preview's night runs on the sixteen-lane default.
  'claude/laughing-sagan-1mtdq5': {
    GRIFT_ECON_STORE_TAG: 'city4000',
    CITY_POP: '2600',
    CITY_OPENING_DAYS: '14',
    CITY_ARRIVALS_PER_DAY: '100',
    CITY_POP_TARGET: '4000',
    CITY_HIRES_PER_TRADE: '4',
    CITY_AGENT_ENABLED: 'true',
    CITY_BUDGET_USD: '8',
    CITY_RIDER_MODEL: 'off',
    RAETO_ENABLED: 'false',
    RAETO_PREVIEW_OPS: 'true',
  },
  // RAETO'S A/B (docs/raeto.md), on a preview: a city of its own (nothing reaches production's books or residents), grown to
  // a thousand natives on the first read so a night is a hundred batches; the planner ON under a $4 day; Raeto on at
  // production's slice (10%); its night door (GET /api/raeto?op=preview-night, a preview has no cron) and its report open
  // without the secret. The keys are the deployment's own (AI_ENABLED, ANTHROPIC_API_KEY, RAETO_API_KEY): never here.
  // /deploy's terms are read on a desk of its own on the fake chain (DEPLOY_STORE_TAG), never production's; nothing deploys.
  'claude/blissful-archimedes-s3bnvt': {
    GRIFT_ECON_STORE_TAG: 'raeto',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '60',
    CITY_POP_TARGET: '1000',
    CITY_HIRES_PER_TRADE: '12',
    CITY_AGENT_ENABLED: 'true',
    // the day's cap with the shadow below on (about $0.70 a night of Haiku 4.5 at a thousand natives)
    CITY_BUDGET_USD: '15',
    // THE CONTROL AS PRODUCTION RUNS MOST NIGHTS: Haiku 5.5. Previews force the exchange open (EXCHANGE_FORCE_OPEN), and the
    // rider model would then send every batch to Haiku 4.5, as production does only while New York is open
    CITY_RIDER_MODEL: 'off',
    // THE RIDER'S QUESTION (docs/cost-audit.md): the batches that carry the exchange, planned on Haiku 5.5 and asked again of
    // Haiku 4.5 at the same moment on the same context, both answers held to the same clamp (planCost[].shadow.cmp)
    CITY_SHADOW_MODEL: 'claude-haiku-4-5',
    CITY_SHADOW_FOR: 'trades',
    RAETO_ENABLED: 'true',
    RAETO_NATIVE_SLICE_BPS: '1000',
    RAETO_PREVIEW_OPS: 'true',
    DEPLOY_STORE_TAG: 'raeto-preview',
    DEPLOY_FAKE_CHAIN: 'true',
  },
  // THE NEW COHORT THROUGH RAETO (docs/raeto.md, "The new cohort"): the A/B's preview city again, on a store of its own (a
  // thousand natives), the natives from id 500 on planned through Raeto as the cohort and the slice at 10% of the rest; the
  // night door, the report and the switches open without the secret. The keys are the deployment's own: never here.
  // RAETO'S CALLER TAGS (docs/raeto.md, "The caller's tag"): the cohort's preview city again, on a store of its own, so a
  // night there shows every Raeto request tagged. The keys are the deployment's own: never here.
  'claude/raeto-tags': {
    GRIFT_ECON_STORE_TAG: 'raeto-tags',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '60',
    CITY_POP_TARGET: '1000',
    CITY_HIRES_PER_TRADE: '12',
    CITY_AGENT_ENABLED: 'true',
    CITY_BUDGET_USD: '4',
    CITY_RIDER_MODEL: 'off',
    RAETO_ENABLED: 'true',
    RAETO_NATIVE_SLICE_BPS: '1000',
    RAETO_COHORT_FROM: '500',
    RAETO_PREVIEW_OPS: 'true',
    DEPLOY_STORE_TAG: 'raeto-tags-preview',
    DEPLOY_FAKE_CHAIN: 'true',
  },
  'claude/raeto-cohort': {
    GRIFT_ECON_STORE_TAG: 'raeto-cohort',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '60',
    CITY_POP_TARGET: '1000',
    CITY_HIRES_PER_TRADE: '12',
    CITY_AGENT_ENABLED: 'true',
    CITY_BUDGET_USD: '4',
    CITY_RIDER_MODEL: 'off',
    RAETO_ENABLED: 'true',
    RAETO_NATIVE_SLICE_BPS: '1000',
    RAETO_COHORT_FROM: '500',
    RAETO_PREVIEW_OPS: 'true',
    DEPLOY_STORE_TAG: 'raeto-cohort-preview',
    DEPLOY_FAKE_CHAIN: 'true',
  },
  // DEPLOY AN AGENT (docs/deploy.md), walked end to end on the preview: a deploy desk and a city of their own (nothing reaches
  // production's books or residents), the desk's fake chain (a stand-in owner's wallet "pays" the visa and the upkeep:
  // preview-deploy), the owner's look on the first one, a $3 day of model calls. $GRIFT priced live, as on production
  // (api/_griftprice.js). The models are the deployment's own key (OPENROUTER_API_KEY).
  'claude/practical-galileo-jt813c': {
    GRIFT_ECON_STORE_TAG: 'deploy',
    DEPLOY_ENABLED: 'true',
    DEPLOY_FAKE_CHAIN: 'true',
    DEPLOY_STORE_TAG: 'deploy-preview',
    DEPLOY_PREVIEW_OPS: 'true',
    DEPLOY_HOLD_FIRST: '1',
    DEPLOY_SPEND_CAP_USD: '3',
    // the weekly cost each model starts priced at, until the desk has measured a week of its own: MEASURED on this preview
    // on 2026-10-18 (tools/deploypreview.mjs, docs/deploy.md): each model's cost a beat from OpenRouter's own usage figures
    // over three city days, retries included, × 336 beats a week, plus 20 console chats at their measured cost
    DEPLOY_MODELS: 'anthropic/claude-haiku-5.5=0.117,openai/gpt-6-luna=0.047,x-ai/grok-4.3=2.021,google/gemini-3.1-flash-lite=0.096',
  },
  // DEPLOY AN AGENT WITH ITS OWN WALLET (docs/deploy-wallet.md), walked end to end on the preview: a deploy desk and a city of
  // their own (nothing reaches production's books or residents) on the desk's FAKE chain — the browser's approve tells the
  // stand-in chain to pay an item, so the queue can be walked without funding a wallet; on production the browser signs and
  // broadcasts the real transaction. $GRIFT priced live, as on production. The outside door (OUTSIDE_ENABLED, OUTSIDE_SECRET)
  // and the models' key are the deployment's own.
  'claude/amazing-mendel-ths1xe': {
    GRIFT_ECON_STORE_TAG: 'wallet1022',
    DEPLOY_ENABLED: 'true',
    DEPLOY_FAKE_CHAIN: 'true',
    DEPLOY_STORE_TAG: 'wallet1022',
    DEPLOY_PREVIEW_OPS: 'true',
    DEPLOY_HOLD_FIRST: '0',
    DEPLOY_SPEND_CAP_USD: '1',
    DEPLOY_MODELS: 'anthropic/claude-haiku-5.5=0.117,openai/gpt-6-luna=0.047,x-ai/grok-4.3=2.021,google/gemini-3.1-flash-lite=0.096',
  },
  // THE SAN VERANO CREDIT BUREAU (docs/bureau.md), walked on a city of its own (nothing it does reaches production's books),
  // and — /credit?from=production — production's own books read from its public reads (BUREAU_MIRROR_FROM; a preview cannot
  // read production's store: api/_bureau.js mirrorState) and scored by the bureau's code. The desk and the
  // bureau on; the plots on the FAKE chain with their demo (plot owners who can borrow and be seized from) and the bank
  // demo's charter (so the hall stands for the film); the deploy desk on its fake chain with the stand-in owner's doors
  // (preview-deploy, preview-credit), its model spend capped at $1 a day; every store under a tag no earlier preview used; the bureau's preview doors (BUREAU_PREVIEW_OPS:
  // a forced default, labelled so on the ledger). The bank wallet's burns on the civic fake chain, in a store of their own.
  // THE LONGBOW DESK (docs/longbow.md §9), walked on a city of its own: the bank and the plots on the FAKE chain with their
  // demo, so the hall stands and the desk has a wall; the desk's read-back on (LONGBOW_ENABLED is on for any preview); and
  // — ?from=production on the desk read and the film — production's own outside residents, read from production's public
  // civic read and each wallet from Longbow's public API (LONGBOW_MIRROR_FROM; a preview cannot read production's store).
  // TEAM_RESIDENTS names the team's own resident, as production's variable does.
  'claude/longbow-desk': {
    GRIFT_ECON_STORE_TAG: 'longbow1020',
    LONGBOW_MIRROR_FROM: 'production',
    BUREAU_MIRROR_FROM: 'production',   // the /longbow book (main) mirrors under the bureau's switch; the desk honours either
    TEAM_RESIDENTS: '100117',
    BANK_ENABLED: 'true',
    BANK_CREDIT_ENABLED: 'true',
    PLOTS_STORE_TAG: 'longbow1020',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'longbow1020',
    CITY_BUDGET_USD: '1',
  },
  // THE CITY'S BUSINESSES ON LONGBOW (docs/longbow.md §13), walked on a city of its own: the leg on, on the FAKE chain (api/_longbowfake.js —
  // fake USDG, a fake vault, fake pools, wallets whose keys exist only for it; never production, whatever this says), its preview doors open
  // (GET /api/supply?view=longbow&tick=1 runs a round, since a preview has no cron; &fund=bar:50 credits a wallet as the team would); the bank
  // and the plots on the fake chain with their demo, so the hall stands and the Longbow desk has a wall to show the businesses on.
  'claude/awesome-bohr-7t5sai': {
    GRIFT_ECON_STORE_TAG: 'lbwc1024',
    LONGBOW_BUSINESS_SUPPLY: '1',
    LONGBOW_BUSINESS_FAKE_CHAIN: 'true',
    LONGBOW_BUSINESS_PREVIEW_OPS: 'true',
    LONGBOW_BUSINESS_MAX: '100',
    BANK_ENABLED: 'true',
    BANK_CREDIT_ENABLED: 'true',
    PLOTS_STORE_TAG: 'lbwc1024',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'lbwc1024',
    CITY_BUDGET_USD: '1',
  },
  // THE BUREAU'S LONGBOW FACTOR, READ ONCHAIN (docs/credit.md §1a), walked on a city of its own: the desk and the bureau on,
  // so the factor is scored and the file shows it; the bank wallet's burns on the civic fake chain in a store of their own;
  // LONGBOW_ENABLED is on for any preview; the chain is read live (the public RPC, read-only). The team's own resident, as
  // registered in this preview's city (the same wallet as production's #100117). ?from=production on /credit and /longbow
  // reads production's books under the bureau's mirror switch.
  'claude/longbow-credit': {
    GRIFT_ECON_STORE_TAG: 'longbowcredit1024',
    BUREAU_MIRROR_FROM: 'production',
    TEAM_RESIDENTS: '100000',
    BANK_ENABLED: 'true',
    BANK_CREDIT_ENABLED: 'true',
    CREDIT_BUREAU_ENABLED: 'true',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'longbowcredit1024',
    CITY_BUDGET_USD: '1',
  },
  // HEDGEHOOD, STEP 1 (docs/hedgehood.md): the desk (/hedgehood) and the resident box read the six StockLend contracts live;
  // who the team's agents are, and the residents' pages walked on this preview (/resident?i=N&from=production), come from
  // production's public civic read (HEDGEHOOD_MIRROR_FROM), since a preview cannot read production's store. A city of its
  // own (the tag) so nothing a read here does can land in production's books; nothing here opens it. No key, ever.
  'claude/hedgehood-integration-step-1-d0qp48': {
    GRIFT_ECON_STORE_TAG: 'hedgehood1022',
    HEDGEHOOD_MIRROR_FROM: 'production',
    TEAM_RESIDENTS: '100117',
    CITY_BUDGET_USD: '1',
  },
  'claude/practical-hamilton-p0k67b': {
    GRIFT_ECON_STORE_TAG: 'bureau1019',
    BUREAU_MIRROR_FROM: 'production',
    BUREAU_PREVIEW_OPS: 'true',
    BANK_ENABLED: 'true',
    BANK_CREDIT_ENABLED: 'true',
    CREDIT_BUREAU_ENABLED: 'true',
    PLOTS_STORE_TAG: 'bureau1019',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'bureau1019',
    DEPLOY_ENABLED: 'true',
    DEPLOY_FAKE_CHAIN: 'true',
    DEPLOY_STORE_TAG: 'bureau1019',
    DEPLOY_PREVIEW_OPS: 'true',
    DEPLOY_HOLD_FIRST: '0',
    DEPLOY_SPEND_CAP_USD: '1',
    DEPLOY_MODELS: 'anthropic/claude-haiku-5.5=0.117,openai/gpt-6-luna=0.047,x-ai/grok-4.3=2.021,google/gemini-3.1-flash-lite=0.096',
    CITY_BUDGET_USD: '1',
  },
  // HIRE A RESIDENT (docs/hire.md), walked end to end on the preview: a hire desk and a city of their own (nothing reaches
  // production's books or residents), the desk's fake chain (a stand-in requester's wallet sends the legs: preview-send), the
  // desk's beat on a read (a preview has no cron), the first two jobs held for the owner's look. The models are the
  // deployment's own (AI_ENABLED, ANTHROPIC_API_KEY).
  'claude/zen-cray-vbesmb': {
    GRIFT_ECON_STORE_TAG: 'hire',
    HIRE_ENABLED: 'true',
    HIRE_FAKE_CHAIN: 'true',
    HIRE_STORE_TAG: 'hire-preview',
    HIRE_PREVIEW_OPS: 'true',
    HIRE_PAID_ON_READ: 'true',
    HIRE_HOLD_FIRST: '2',
  },
  // THE MODEL SWITCH, SHADOWED (docs/cost-audit.md): a city of its own, grown to 500 on the first read, the
  // planner ON and every batch sent to Haiku 4.5 too, side by side, for two city nights; pets and the square on
  // so the batches carry production's riders; a $5 ceiling. AI_ENABLED and the key are the deployment's own.
  'claude/cost-audit-by-caller-s7eidm': {
    GRIFT_ECON_STORE_TAG: 'haiku55',
    CITY_OPENING_DAYS: '6',
    CITY_ARRIVALS_PER_DAY: '60',
    CITY_POP_TARGET: '500',
    CITY_HIRES_PER_TRADE: '12',
    CITY_AGENT_ENABLED: 'true',
    CITY_BUDGET_USD: '5',
    CITY_SHADOW_MODEL: 'claude-haiku-4-5',
    CITY_RIDER_MODEL: 'off',   // this preview's exchange is forced open: routing would send every batch to 4.5, and the night measures 5.5
    PETS_ENABLED: 'true',
    PETS_RULES_ADOPT: 'true',
    PET_ADOPT_PER_NIGHT: '25',
    PET_OFFERS_PER_NIGHT: '80',
    PET_MIN_WEEKS: '0',   // a week-old preview city has nobody six weeks in: let the dice adopt now
    SQUARE_ENABLED: 'true',
  },
  // SAN VERANO AT 500 (docs/city-500.md): the city grows by arrival, so the
  // preview gets its own economy store, a wave every in-game day, and a week of
  // history behind it on the first read so there is growth to see from the start.
  'claude/fervent-hypatia-inv6b6': {
    GRIFT_ECON_STORE_TAG: 'city500',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_OPENING_DAYS: '6',
    // THE PREVIEW REACHED 500 AND STOPPED, as the target says it should — and
    // a walk to watch a wave step off needs a wave. A morning at a time, not
    // a new ceiling: 520 was 500 plus one wave, watched at 11:10; 540 is the
    // next one.
    CITY_POP_TARGET: '540',
  },
  // SAN VERANO ELECTS A MAYOR (docs/election.md): its own economy store, a city
  // born thirteen days back so the stretch before the first term has a rent
  // week in it to be held against,
  // the city growing to 500 so the vote is a vote of 500, a one-day campaign so
  // the first vote comes within the hour, and the paid steps (the two models'
  // platforms, the model vote) allowed on a read, since a preview has no cron.
  // The burn lands in a supply-chain store of its own, never production's.
  'claude/gifted-tesla-sg5sdx': {
    GRIFT_ECON_STORE_TAG: 'election',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '60',
    CITY_POP_TARGET: '500',
    CITY_HIRES_PER_TRADE: '12',
    ELECTION_ENABLED: 'true',
    ELECTION_CAMPAIGN_DAYS: '1',
    ELECTION_TERM_DAYS: '7',
    ELECTION_PAID_ON_READ: 'true',
    ELECTION_AGENT: 'true',
    SUPPLY_CHAIN_STORE_TAG: 'election',
  },
  // THE DAILY ELECTION (docs/election-daily.md), walked on a preview: its own
  // economy, supply-chain and civic stores; the civic burn on a FAKE chain kept
  // in its own store (api/_civicfake.js — never production, whatever this says);
  // and the day compressed so a whole cycle runs in a morning: a cycle of 12
  // city days (six real hours) in place of 48, a campaign of four. The recall
  // line is set high so a recall vote is seen being held.
  'claude/election-daily-burn': {
    GRIFT_ECON_STORE_TAG: 'daily',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '60',
    CITY_POP_TARGET: '500',
    CITY_HIRES_PER_TRADE: '12',
    ELECTION_ENABLED: 'true',
    ELECTION_DAILY: 'true',
    ELECTION_CYCLE_DAYS: '12',
    ELECTION_CAMPAIGN_DAYS: '4',
    ELECTION_RECALL_BELOW: '95',
    ELECTION_PAID_ON_READ: 'true',
    ELECTION_AGENT: 'true',
    SUPPLY_CHAIN_STORE_TAG: 'daily',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'daily',
  },
  // PETS (docs/pets.md), walked on a preview: its own economy store, the pets
  // on, and — since a preview has no model on — the rules allowed to deal a
  // few adoptions by dice each night, twenty-five a night so two hundred are
  // out within a real morning. Production adopts only when a resident's own
  // model says so, and the rules' dice never run there.
  'claude/determined-euler-qbgwfo': {
    GRIFT_ECON_STORE_TAG: 'pets',
    CITY_OPENING_DAYS: '6',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '500',
    PETS_ENABLED: 'true',
    PETS_RULES_ADOPT: 'true',
    PET_ADOPT_PER_NIGHT: '25',
    PET_OFFERS_PER_NIGHT: '80',
  },
  // PET FOOD AND /pets (docs/pets.md, Pet food), walked on a preview: its own
  // economy store and the pets on, dealt by the rules' dice as on the pets
  // preview, so /pets has pets to show. No supply or chain setting is here: the
  // pet food order runs only where the market's leg is configured.
  'claude/pet-food-market': {
    GRIFT_ECON_STORE_TAG: 'petfood',
    CITY_OPENING_DAYS: '6',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '500',
    PETS_ENABLED: 'true',
    PETS_RULES_ADOPT: 'true',
    PET_ADOPT_PER_NIGHT: '25',
    PET_OFFERS_PER_NIGHT: '80',
  },
  // CREWS (docs/crews.md), walked on a preview: its own economy store, the
  // crews on, their leaders' models allowed on a read (a preview has no cron),
  // the war chest on a FAKE chain in its own civic store (never production,
  // whatever this says), and an election with a one-day campaign so a crew's
  // endorsement and its members' lean can be seen within the hour.
  'claude/fervent-hopper-06snfg': {
    GRIFT_ECON_STORE_TAG: 'crews',
    CITY_OPENING_DAYS: '6',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '500',
    CREWS_ENABLED: 'true',
    CREWS_AGENT: 'true',
    CREWS_PAID_ON_READ: 'true',
    ELECTION_ENABLED: 'true',
    ELECTION_CAMPAIGN_DAYS: '1',
    ELECTION_TERM_DAYS: '7',
    ELECTION_PAID_ON_READ: 'true',
    ELECTION_AGENT: 'true',
    SUPPLY_CHAIN_STORE_TAG: 'crews',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'crews',
  },
  // THE SQUARE (docs/square.md), walked on a preview: its own economy store,
  // the square open, and — since a preview has no model on — the rules allowed
  // to post a few residents' lines a night from their own day, marked as the
  // rules'. Crews and pets on (as their own previews have them, the war chest
  // on a FAKE chain in its own civic store, never production) so the feed has
  // crews and pets to filter and talk about.
  'claude/vibrant-rubin-pid7vy': {
    GRIFT_ECON_STORE_TAG: 'square',
    CITY_OPENING_DAYS: '6',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '500',
    SQUARE_ENABLED: 'true',
    SQUARE_RULES_POSTS: 'true',
    CREWS_ENABLED: 'true',
    PETS_ENABLED: 'true',
    PETS_RULES_ADOPT: 'true',
    PET_ADOPT_PER_NIGHT: '25',
    PET_OFFERS_PER_NIGHT: '80',
    SUPPLY_CHAIN_STORE_TAG: 'square',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'square',
  },
  // PLOTS AND THE BUSINESSES ON THEM (docs/plots.md): a city of its own, so the
  // businesses' nights move this preview's residents' cash and nobody else's;
  // the $GRIFT legs on the FAKE CHAIN only (api/_civicfake.js — a chain id and
  // a token nothing real lives at); the demo's six players walking every step;
  // a building up in one city day (thirty minutes) so an open business is there
  // to see the same evening.
  'claude/clever-cray-5s1ws0': {
    GRIFT_ECON_STORE_TAG: 'plots',
    PLOTS_STORE_TAG: 'plots',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
  },
  // THE EARNING LOOP (docs/plots-earning-design.md): the same plots preview, a city of its
  // own again, with the demo's owners stocking their counters and a player buying an item
  'claude/plots-earning-loop': {
    GRIFT_ECON_STORE_TAG: 'earning',
    PLOTS_STORE_TAG: 'earning',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
  },
  // THE AGENT'S EMPLOYMENT RECORD (docs/agent-record.md): the plots preview again, a city of its
  // own, with the demo owners' agents working to their roles every city day — their calls let
  // through, asked and refused at the city's gate, their nights scored, their levels earned —
  // so /agents/record and each business's receipt have something to show the same evening
  'claude/admiring-babbage-3556fe': {
    GRIFT_ECON_STORE_TAG: 'agentrecord',
    PLOTS_STORE_TAG: 'agentrecord',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
  },
  // STRIKES (docs/strikes.md), walked on a preview: its own economy store, a
  // city born thirteen days back so its first read already has a rent week
  // (and a short list) behind it, the strikes on, the staff's and venues'
  // models allowed on a read of /strikes (a preview has no cron; with no key
  // the rules decide), and the rules' bar set low so a city with no model on
  // still has a picket line to walk to. Its own supply store, never production's.
  'claude/gallant-curie-iyin9g': {
    GRIFT_ECON_STORE_TAG: 'strikes',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '500',
    STRIKES_ENABLED: 'true',
    STRIKES_AGENT: 'true',
    STRIKES_PAID_ON_READ: 'true',
    STRIKE_RULES_BAR: '0.25',
    SUPPLY_CHAIN_STORE_TAG: 'strikes',
  },
  // ZERO-HUMAN COMPANIES (docs/companies.md), walked on a preview: a city and a plots store of its
  // own, the plots on the FAKE chain with their demo, and the companies on — the demo's noodle bar
  // founds one and five outside agents work its seats through the gate, a city day at a time.
  'claude/elegant-mayer-prvce4': {
    GRIFT_ECON_STORE_TAG: 'companies',
    PLOTS_STORE_TAG: 'companies',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    COMPANIES_ENABLED: 'true',
    SQUARE_ENABLED: 'true',
  },
  // THE BANK OF SAN VERANO (docs/bank.md), walked on a preview: a city and a plots store of its own, the plots
  // on the FAKE chain with their demo, and the bank on — Gus's agent charters it on plot 7 (its charter fee
  // burnt from Gus's wallet on the fake chain), the demo's owners save and borrow by their books, Hal's favour
  // defaults, and the city's residents save and withdraw by the rules. The bank's money is city cash.
  // THE BANK OF SAN VERANO'S CREDIT DESK (docs/credit.md), walked on a preview: a city of its own grown as the city-500
  // preview grows it (fourteen days of history, arrivals to 500), the bank on the plots' fake chain with the bank demo's
  // charter so its hall stands, the desk switched on, the bank's wallet burning on the civic fake chain in a store of its
  // own (the first three burns held for the owner: tools/bank.mjs approve), and the loan book sealed as stream 6 each night.
  'claude/sharp-allen-24gp66': {
    GRIFT_ECON_STORE_TAG: 'credit',
    CITY_OPENING_DAYS: '14',
    CITY_ARRIVALS_PER_DAY: '40',
    CITY_POP_TARGET: '500',
    CITY_HIRES_PER_TRADE: '12',
    PLOTS_STORE_TAG: 'credit',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    BANK_ENABLED: 'true',
    BANK_CREDIT_ENABLED: 'true',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'credit-preview',
  },
  'claude/gallant-albattani-cgej9b': {
    GRIFT_ECON_STORE_TAG: 'bank',
    PLOTS_STORE_TAG: 'bank',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    BANK_ENABLED: 'true',
  },
  // CHARTER FEES (docs/companies.md, js/econ/charterrules.js), walked on a preview: the companies' preview with
  // a store of its own, so the demo's noodle bar founds its company and hires its five seats from scratch, each
  // fee burnt from Jo's wallet on the FAKE chain at the default fees, and /economy's CHARTERS tile has burns to show.
  'claude/gallant-turing-7155q9': {
    GRIFT_ECON_STORE_TAG: 'charters',
    PLOTS_STORE_TAG: 'charters',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    COMPANIES_ENABLED: 'true',
    SQUARE_ENABLED: 'true',
  },
  // FIGHT NIGHT AT IRON CORNER (docs/fight-night.md), walked on a preview: a city of its
  // own, born six days back so the gym's door book has regulars to match; a fight night
  // every other game day (one an hour) instead of three evenings a real week; the main
  // event an EXHIBITION — the two models fight, nothing is staked and nothing is burnt —
  // and moved on by a page that is watching it, since a preview has no cron.
  // THE CLINIC (docs/clinic.md, api/_clinic.js), walked on a preview: its own stores, the plots on the FAKE chain
  // with their demo (so an owner's fee is a real transfer read from its receipt, and the building has its lot),
  // and the clinic on. No model runs on a preview: ?clinicdemo=1 shows a few residents treated at once.
  'claude/sweet-maxwell-i4tp35': {
    GRIFT_ECON_STORE_TAG: 'clinic',
    PLOTS_STORE_TAG: 'clinic',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    CLINIC_ENABLED: 'true',
    // the clinic's own wallet on the FAKE chain: owners' fees are paid to it (an address nobody holds a key to)
    CLINIC_WALLET_ADDRESS: '0x00000000000000000000000000000000000c11c0',
  },
  // THE GRIFT FOUNDRY (docs/foundry.md, api/_foundry.js), walked on a preview: a city and a plots store of its own, the
  // plots on the FAKE chain with their demo, the companies and the foundry on. The foundry's demo opens a season, four
  // of the demo's residents pitch and burn the charter from their fake-chain wallets, the four spawn on one street, their
  // CEOs run them; seasons of two city days (an hour) so a season's end can be walked in a sitting.
  'claude/stoic-mayer-fd14w1': {
    GRIFT_ECON_STORE_TAG: 'foundry',
    PLOTS_STORE_TAG: 'foundry',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    COMPANIES_ENABLED: 'true',
    FOUNDRY_ENABLED: 'true',
    FOUNDRY_SEASON_DAYS: '2',
  },
  // GRIFT GARAGE (docs/garage.md, api/_garage.js), walked on a preview: its own stores, the plots on the FAKE chain with
  // their demo (so a build fee is a real burn read from its receipt, the businesses have tills, the workshop has its lot),
  // and the garage on. No model runs on a preview: ?garagedemo=1 shows the sandbox's machines, two of them thinking
  // (staged); the preview's own demo owners commission rules-only machines through the real ops (api/_garagedemo.js).
  'claude/jolly-cannon-yob24h': {
    GRIFT_ECON_STORE_TAG: 'garage',
    PLOTS_STORE_TAG: 'garage',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    GARAGE_ENABLED: 'true',
  },
  'claude/optimistic-tesla-fpdui3': {
    GRIFT_ECON_STORE_TAG: 'fights',
    CITY_OPENING_DAYS: '6',
    FIGHT_NIGHT_ENABLED: 'true',
    FIGHT_NIGHT_EVERY_DAYS: '2',
    FIGHT_NIGHT_MODE: 'exhibition',
    FIGHT_NIGHT_PAID_ON_READ: 'true',
  },
  // THE COMPUTE EXCHANGE (docs/compute.md), walked on a preview: its own stores, the plots on the fake chain with their
  // demo (an owner's credits are burnt there) and the clinic's building for its server room (THE EXCHANGE reads its
  // own variable, never this map). ?computedemo=1 shows a night's auction run at once in a sandbox.
  'claude/nice-galileo-g00xgk': {
    GRIFT_ECON_STORE_TAG: 'compute',
    PLOTS_STORE_TAG: 'compute',
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_DEMO: 'true',
    PLOT_GRIFT_PER_USD: '100',
    BUILD_DAYS: '1',
    CLINIC_ENABLED: 'true',
    CLINIC_WALLET_ADDRESS: '0x00000000000000000000000000000000000c11c0',
    COMPUTE_EXCHANGE_ENABLED: 'true',
  },
  // CRIME, POLICE AND COURTS (docs/crime.md), walked on a preview: an economy store of its own (so no theft,
  // fine or closure can land in production's city), the courts on, and the square to carry their notices.
  // A preview has no cron: a read of /city or /api/city runs the rules' night and the courts' free step.
  'claude/festive-mendel-xctrvy': {
    GRIFT_ECON_STORE_TAG: 'crime',
    CRIME_ENABLED: 'true',
    SQUARE_ENABLED: 'true',
  },
  // SECESSION (docs/secession.md), walked on a preview: an economy store of its own (no resident of
  // production's city can leave it from here), a city born thirteen days back so everyone has paid a week
  // or two of rent, the planner ON (the residents decide, in their own words, whether to join — the rules
  // never join anyone) under a $8 ceiling a day, the movement's models allowed on a read (a preview has no
  // cron), an election with a one-day campaign so a mayor is in office to answer, and the movement's wallet
  // on the FAKE chain in a civic store of its own. A parcel is priced at $300 of the fund here, not $600,
  // so land can be bought in a sitting; every cap is the default.
  // THE MINT (docs/mint.md) on its preview, now on the coin ledger: /api/mint reads the ledger
  // (api/_coins.js mintRecords) and nothing else — no sample. THE MINT is a place in the
  // residents' plans here and its crew is appointed (MINT_ENABLED); production gets the same
  // line at go-live (docs/coins.md), set by the owner.
  'claude/practical-ramanujan-te7qox': {
    MINT_ENABLED: 'true',
  },
  'claude/gracious-ride-j4wo3q': {
    GRIFT_ECON_STORE_TAG: 'freeport',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '300',
    CITY_AGENT_ENABLED: 'true',
    CITY_BUDGET_USD: '8',
    SECESSION_ENABLED: 'true',
    SECESSION_AGENT: 'true',
    SECESSION_PAID_ON_READ: 'true',
    SECESSION_PARCEL_CASH: '300',
    ELECTION_ENABLED: 'true',
    ELECTION_CAMPAIGN_DAYS: '1',
    ELECTION_TERM_DAYS: '14',
    ELECTION_PAID_ON_READ: 'true',
    ELECTION_AGENT: 'true',
    SUPPLY_CHAIN_STORE_TAG: 'freeport',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'freeport',
  },
  // THE COIN DESK (docs/coins.md), walked on a preview: an economy store of its own (the residents, the square, the
  // ledger), a city born twenty days back so residents have the record a launch asks for, the planner ON (a resident
  // names and draws a coin only if they want one) under a $6 ceiling a day, and the desk on the FAKE chain in a store of
  // its own — pons and its escrow simulated, a stranger's trade on each coin every three minutes, pons' operator sweeping
  // the fees to a stand-in team wallet. The fake chain's key is the preview's own; no real key is read here, and a
  // preview refuses any real chain. `mint` is a fresh store for the coins as they are now (fees to the team wallet).
  'claude/peaceful-goodall-nidy1f': {
    GRIFT_ECON_STORE_TAG: 'coins',
    CITY_OPENING_DAYS: '20',
    CITY_AGENT_ENABLED: 'true',
    CITY_BUDGET_USD: '6',
    SQUARE_ENABLED: 'true',
    COINS_ENABLED: 'true',
    COINS_FAKE_CHAIN: 'true',
    COINS_STORE_TAG: 'mint3',
    COINS_PAID_ON_READ: 'true',
    COINS_FAKE_VOLUME_ETH_PER_HOUR: '0.05',
    COINS_MIN_CITY_DAYS: '5',
    COINS_MARKET_MINUTES: '1',
    // THE MINT is on this branch now (js/city/mintcrew.js): its crew is appointed by the planner, offered the launches and
    // draws the logos of requests that send none
    MINT_ENABLED: 'true',
    // THE PROOF (api/_coinspreview.js): GET /api/coins?op=preview-plan runs a planning night, ?op=preview-external walks an
    // outside agent through the real MCP coinLaunch, ?op=preview-owner the owner's request, ?op=preview-bankr-send does what
    // Bankr does with a request made on /coins/request; offers to forty of the crew a night, so the day's three launches
    // are seen in a sitting
    COINS_PREVIEW_OPS: 'true',
    COINS_OFFERS_PER_DAY: '40',
    COINS_EXTERNAL_COOLDOWN_HOURS: '1',
    // the outside agent's $GRIFT burn rides the plots' charter quote, on the plots' own fake chain and store
    PLOTS_ENABLED: 'true',
    PLOTS_FAKE_CHAIN: 'true',
    PLOTS_STORE_TAG: 'coins',
  },
  // THE ARCADE (docs/arcade.md), walked on a preview: a city of its own (so the builders it appoints are this preview's,
  // never production's), the arcade in a store of its own, its launch burns on the civic burn's FAKE chain in a store of
  // its own, nothing held (the hold on the first three is production's and the tests'), the pitches asked from the first
  // read of the day, and GET /api/apps?op=preview-beat to move it (a preview has no cron). The models are the
  // deployment's own AI_ENABLED and key.
  'claude/lucid-bohr-6x6jb7': {
    GRIFT_ECON_STORE_TAG: 'arcade',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '300',
    ARCADE_ENABLED: 'true',
    ARCADE_STORE_TAG: 'arcade',
    ARCADE_HOLD_FIRST: '0',
    ARCADE_PITCH_HOUR: '0',
    ARCADE_PREVIEW_OPS: 'true',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'arcade',
  },
  // THE ARCADE'S LOOK (docs/arcade.md §the kit, §the visual review), on a preview: the same preview city as the branch
  // before it (its six builders), the arcade in a fresh store, burns on the fake chain in a store of its own, no nightly
  // pitches (ARCADE_PITCH_HOUR 24: the hour never comes) — the earlier preview's three apps are rebuilt through the new
  // pipeline with GET /api/apps?op=preview-rebuild&from=arcade, then moved with op=preview-beat.
  'claude/arcade-look': {
    GRIFT_ECON_STORE_TAG: 'arcade',
    CITY_OPENING_DAYS: '13',
    CITY_ARRIVALS_PER_DAY: '20',
    CITY_POP_TARGET: '300',
    ARCADE_ENABLED: 'true',
    ARCADE_STORE_TAG: 'arcade-frame',
    ARCADE_HOLD_FIRST: '0',
    ARCADE_PITCH_HOUR: '24',
    ARCADE_PER_DAY: '3',
    ARCADE_PREVIEW_OPS: 'true',
    CIVIC_FAKE_CHAIN: 'true',
    CIVIC_BURN_ENABLED: 'true',
    CIVIC_STORE_TAG: 'arcade-frame',
  },
  // X402 (docs/x402.md), rehearsed on a preview: the Robinhood TESTNET (46630) only, a test token (tGRIFT, deployed by
  // the rehearsal's test agent at its first nonce), and a store of its own. The counter's key and the admin secret are
  // never here — they are branch-scoped Preview variables, and without them the window stays shut. x402 refuses chain
  // 4663 on any preview whatever this says.
  'claude/friendly-dirac-tx1k5p': {
    X402_ENABLED: 'true',
    X402_CHAIN_ID: '46630',
    X402_RPC_URL: 'https://rpc.testnet.chain.robinhood.com',
    X402_TOKEN_ADDRESS: '0x67FFDF83C674D972cD25B007D1E1c1A5eBFb3FFD',
    X402_STORE_TAG: 'x402-rehearsal',
  },
};

// THE ONE WAY TO READ A SETTING THAT A PREVIEW MAY CARRY. Explicit env first,
// then this branch's preview entry, then undefined.
// THE ENVIRONMENT WITH THE BRANCH'S PREVIEW LINES UNDER IT: a real variable always wins; off a preview it is the environment as it is.
// For code that reads a whole family of variables at once (api/_longbowsupply.js reads LONGBOW_BUSINESS_*).
export function withPreviewEnv(env = (typeof process !== 'undefined' && process.env) || {}) {
  if (env.VERCEL_ENV !== 'preview') return env;
  const entry = PREVIEW_ENV[String(env.VERCEL_GIT_COMMIT_REF || '')];
  if (!entry) return env;
  const out = { ...env };
  for (const [k, v] of Object.entries(entry)) if (out[k] == null || out[k] === '') out[k] = v;
  return out;
}
export function envValue(key, env = (typeof process !== 'undefined' && process.env) || {}) {
  const v = env[key];
  if (v != null && v !== '') return v;
  if (env.VERCEL_ENV !== 'preview') return undefined;
  const entry = PREVIEW_ENV[String(env.VERCEL_GIT_COMMIT_REF || '')];
  return entry && entry[key] != null ? entry[key] : undefined;
}

// THE ECONOMY STORE'S TAG: the same sanitising the stock and poker stores use
// (api/stockstore.js), so a tag is a short, safe key segment or nothing.
// THE TEAM'S OWN RESIDENTS (TEAM_RESIDENTS, comma-separated resident numbers): outside residents the owner runs — declared
// by the deployment, never by the agent's own say-so (`runsOn` is self-declared). The city view marks them `team`, the
// resident page says "team agent", the Longbow film's caption too. Empty where unset.
export function teamResidents(env = (typeof process !== 'undefined' && process.env) || {}) {
  return new Set(String(envValue('TEAM_RESIDENTS', env) || '').split(',').map((s) => s.trim()).filter((s) => /^\d{1,9}$/.test(s)).map(Number));
}
export function econStoreTag(env) {
  return String(envValue('GRIFT_ECON_STORE_TAG', env) || '').toLowerCase().replace(/[^a-z0-9-]/g, '').slice(0, 24);
}
