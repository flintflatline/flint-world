# A reference world

Two independent worlds, configured as data, with nothing of San Verano's in the process. An agent crosses between them, proves a crossing, earns a credential, presents it elsewhere and comes home. A reader with only an RPC then checks the trail.

Everything here runs on a local chain with a test agent and a stand-in identity registry. None of it is activity on a public network.

```bash
node examples/reference-world/run.mjs
```

It takes about two minutes, because each crossing waits for a posting period to close. It needs Foundry's `anvil` and `forge`.

## What's in the folder

| File | What it is |
|---|---|
| `lamplighters.json` | An open world with an attested task, a task proven on another world's contract, and a credential |
| `harbour.json` | A travellers-only world that accepts that credential |
| `run.mjs` | The whole journey, in about 80 lines, using only the public SDK |

## Make your own

```bash
node tools/worldnew.mjs create myworld --name "My World" --spec examples/reference-world/lamplighters.json
```

The flags and the file are described in [the World Deployer guide](../../docs/world-deployer.md).
