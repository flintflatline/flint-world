// A COMPLETE REFERENCE WORLD (docs/world-deployer.md; examples/reference-world/README.md). Two independent worlds, on a local chain, with nothing of San
// Verano's in the process: an agent crosses between them, proves a crossing, earns a credential, presents it elsewhere and comes home, and then a reader
// with nothing but an RPC checks the whole trail. A test agent on a local chain: not activity on any public network.
//   node examples/reference-world/run.mjs [--port 8790] [--anvil-port 8550]
import { readFileSync } from 'node:fs';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { policyWorld } from '../../js/worlds/templates/policy.js';
import { startLocalNet } from '../../js/worlds/localnet.js';
import { agentClient } from '../../js/worlds/tour.js';
import { verifyItem } from '../../js/worlds/verifier.js';
import { operatorMessage, operatorTypedData } from '../../js/worlds/operate.js';

const arg = (k, d) => { const i = process.argv.indexOf(k); return i >= 0 ? process.argv[i + 1] : d; };
const spec = (f) => JSON.parse(readFileSync(new URL(`./${f}`, import.meta.url), 'utf8'));
const yard = policyWorld(spec('lamplighters.json')), harbour = policyWorld(spec('harbour.json'));
const say = (s) => console.log(s);
let failed = 0;
const must = (ok, what, more = '') => { if (!ok) failed++; say(`  ${ok ? '✓' : '✗'} ${what}${ok || !more ? '' : ` — ${String(more).slice(0, 300)}`}`); return ok; };

const net = await startLocalNet({ worlds: [yard, harbour], builtIns: false, port: Number(arg('--port', 8790)), anvilPort: Number(arg('--anvil-port', 8550)) });
try {
  await net.flushAll();
  say(`two worlds up on a local chain: ${Object.values(net.urls).join(' · ')}`);
  for (let i = 0; i < 60; i++) { const d = await net.learn(); if (d.worlds.every((w) => w.verified)) break; await new Promise((r) => setTimeout(r, 1000)); }
  const relearn = setInterval(() => net.learn().catch(() => {}), 3000);

  say('\nan agent, with a new key and a stand-in identity');
  const ada = agentClient({ key: generatePrivateKey(), agentId: '7', worlds: net.urls });
  await net.setAgent('7', ada.address);
  must((await ada.join('harbourmaster', 'Ada')).code === 403, 'the Harbourmaster refuses it: it arrives from nowhere');
  must((await ada.join('lamplighters', 'Ada')).code === 201, 'the Yard admits it: its door is open');
  must((await ada.act('lamplighters', 'task', { taskId: 'light' })).code === 200, 'it lights a lamp: this is the Yard\'s claim, attested');
  must((await ada.act('lamplighters', 'note', { line: 'the first lamp is lit' })).code === 200, 'it leaves a note: this is its own say');
  must(/NOT_EARNED/.test((await ada.act('lamplighters', 'claim', {})).reason), 'it asks for the credential: not yet, it has proven nothing');

  say('\nit leaves, and the Yard posts its period on its own contract');
  const out = await ada.leave('lamplighters');
  const left = await ada.citeWhenPosted('lamplighters', (i) => i.kind === 'departed' && i.verify?.leaf === out.item.leaf);
  must(left, 'its departure is on chain');
  must((await ada.join('harbourmaster', 'Ada', left.cite)).code === 201, 'the Harbourmaster admits it, having checked that departure on the Yard\'s contract');
  const out2 = await ada.leave('harbourmaster');
  const left2 = await ada.citeWhenPosted('harbourmaster', (i) => i.kind === 'departed' && i.verify?.leaf === out2.item.leaf);
  must(left2, 'it leaves the Harbourmaster, and that is on chain too');

  say('\nit comes back to the Yard with proof of where it has been');
  must((await ada.join('lamplighters', 'Ada', left2.cite)).code === 200, 'it returns, citing that departure');
  must((await ada.act('lamplighters', 'task', { taskId: 'carry', result: left2.cite })).proof === 'foreign-item', 'its proof is checked on the Harbourmaster\'s contract: a fact');
  const cred = await ada.act('lamplighters', 'claim', {});
  must(cred.credential?.weight === 'fact', `it earns ${cred.credential?.title}: a fact, because its one required task was proven on chain`, JSON.stringify(cred));

  say('\nthe Yard\'s owner acts, signed and on the record');
  const w = net.engines.lamplighters.w, msg = operatorMessage('lamplighters', 'notice', { text: 'the lamps go out at dusk' }, { nonce: `0x${Buffer.from(globalThis.crypto.getRandomValues(new Uint8Array(32))).toString('hex')}`, contract: w.commits });
  const posted = await fetch(`${net.origin}${w.api}/operator`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ msg, sig: await privateKeyToAccount(net.listers.lamplighters).signTypedData(operatorTypedData(w, msg)) }) });
  must(posted.status === 200, 'it posts a notice: sealed as the owner\'s say, with the owner\'s signature');

  say('\nit takes its credential to the Harbourmaster');
  const out3 = await ada.leave('lamplighters');
  const left3 = await ada.citeWhenPosted('lamplighters', (i) => i.kind === 'departed' && i.verify?.leaf === out3.item.leaf);
  const credCite = (await ada.citeWhenPosted('lamplighters', (i) => i.kind === 'world.credential')).cite;
  must((await ada.join('harbourmaster', 'Ada', left3.cite)).code === 200, 'it travels again');
  const shown = await ada.act('harbourmaster', 'present', { credential: credCite });
  must(shown.accepted?.kind === 'world.credential', 'the Harbourmaster verifies the credential on the Yard\'s contract', JSON.stringify(shown));

  say('\na reader with only an RPC checks the credential: no world\'s server is asked anything');
  const v = await verifyItem({ pub: net.c.pub, index: net.core.index, identity: net.core.identity, cite: credCite, related: [left2.cite] });
  must(v.ok && v.facts.some((f) => f.fact === 'cross-world'), 'it verifies, and so does the crossing it rests on, on the other world\'s contract', JSON.stringify(v.checks.filter((c) => !c.ok)));
  for (const f of v.facts) say(`    FACT   ${f.statement}`);
  for (const c of v.claims) say(`    CLAIM  ${c.field}, the Yard's say: ${JSON.stringify(c.value).slice(0, 90)}`);
  for (const u of v.unverified) say(`    NOT CHECKED  ${u.what}`);
  clearInterval(relearn);
} finally { await net.stop(); }
say(failed ? `\n${failed} step(s) failed` : '\nevery step held. This was a local chain and a test agent.');
process.exit(failed ? 1 : 0);
