// WHAT A RUN ON A REAL CHAIN NEEDS, WHICHEVER CHAIN (tools/worldtestnet.mjs, tools/worldmainnet.mjs): the keys file's rules, the
// deployment record, the Foundry scripts with their keys kept off every command line, and the environment a journey runs in.
// Each tool keeps its own guard on which chain it will touch; nothing here decides that.
import { readFileSync, writeFileSync, existsSync, statSync, mkdirSync } from 'node:fs';
import { spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve, relative, isAbsolute, sep } from 'node:path';
import * as viem from 'viem';

const here = dirname(fileURLToPath(import.meta.url));
export const REPO = resolve(here, '..');
export const CONTRACTS = join(REPO, 'contracts');
// this machine, by the URL's own host: `https://localhost:x@rpc.example.com` is rpc.example.com
export const isLocalRpc = (url) => { try { const u = new URL(String(url)); return /^https?:$/.test(u.protocol) && !u.username && !u.password && ['127.0.0.1', 'localhost', '[::1]'].includes(u.hostname); } catch { return false; } };

// a keys file lives outside the repository, mode 600
export function keysFileProblem(path, { repo = REPO, mustExist = true } = {}) {
  const abs = resolve(path), rel = relative(repo, abs);
  if (rel !== '..' && !rel.startsWith(`..${sep}`) && !isAbsolute(rel)) return `${abs} is inside the repository: a keys file lives outside it`;
  // nor inside any other checkout: something in a working tree is one `git add` from a commit
  for (let dir = dirname(abs); dir !== dirname(dir); dir = dirname(dir)) if (existsSync(join(dir, '.git'))) return `${abs} is inside the repository at ${dir}: a keys file lives outside every checkout`;
  if (mustExist) {
    if (!existsSync(abs)) return `${abs} does not exist`;
    if ((statSync(abs).mode & 0o077) !== 0) return `${abs} can be read by others: chmod 600 it`;
  }
  return null;
}
// a child process's output with every key in it masked: forge prints no key given by the environment, and this makes sure
export const maskKeys = (text, k) => { let s = String(text || ''); for (const v of JSON.stringify(k).match(/0x[0-9a-fA-F]{64}/g) || []) s = s.split(v).join('<key>'); return s; };

// ---- the deployment record ---------------------------------------------------------------------------------------------
export const readDeploy = (path) => (existsSync(path) ? JSON.parse(readFileSync(path, 'utf8')) : null);
export const writeDeploy = (path, d) => { mkdirSync(dirname(resolve(path)), { recursive: true }); writeFileSync(path, JSON.stringify(d, null, 2) + '\n'); };

// one Foundry script, its key in the environment of this child only; its transactions read back from forge's own record.
// The approval passed down is for this chain: the script checks it against the chain it finds (contracts/worldsdeploy PublicGuard)
export function forgeScript({ chainId, project, script, contract, keyFor, env, rpc, keys, log, gasPrice }) {
  const root = join(CONTRACTS, project);
  // the fees are stated (js/worlds/deployer.js fees): forge's own guess of the tip is many times this chain's whole price
  const r = spawnSync('forge', ['script', `script/${script}`, '--tc', contract, '--rpc-url', rpc, '--broadcast', '--slow', '--gas-estimate-multiplier', '200', '--with-gas-price', String(gasPrice), '--priority-gas-price', '0'], { cwd: root, encoding: 'utf8', env: { ...process.env, FOUNDRY_LINT_LINT_ON_BUILD: 'false', WORLDS_PUBLIC_DEPLOY_APPROVED: String(chainId), WORLDS_DEPLOY_KEY: keyFor, ...env }, maxBuffer: 64 * 1024 * 1024 });
  if (r.status !== 0) throw new Error(`forge script ${script} failed:\n${maskKeys(r.stdout, keys).slice(-1200)}\n${maskKeys(r.stderr, keys).slice(-1200)}`);
  const rec = JSON.parse(readFileSync(join(root, 'broadcast', script, String(chainId), 'run-latest.json'), 'utf8'));
  log?.(`    ${contract}: ${rec.transactions.length} transaction(s)`);
  return rec.transactions.map((t) => ({ type: t.transactionType, contract: t.contractName || null, function: t.function || null, address: t.contractAddress ? viem.getAddress(t.contractAddress) : null, tx: t.hash }));
}

// ---- the environment a journey runs in (js/worlds/journeyrun.js) ----------------------------------------------------------
export async function runEnv({ rpc, keys: k, deployment: d, run, port, cronMs, out, withModel, log, store, rehearsal, chainId, network, launch = {}, limits = null, extra = null, evidence = null, cityDoors = true }) {
  const { isolateCity } = await import('../js/worlds/isolate.js');
  isolateCity(); // before anything imports the city: this process can never reach production's store
  const { _resetForTests: resetCity, city, withCity } = await import('../api/city.js');
  const { default: cityDoor, _resetForTests: resetAgents, TYPED } = await import('../api/agents.js');
  const { attachNet } = await import('../js/worlds/publicnet.js');
  const { loadWorld } = await import('../js/worlds/deployer.js');
  const { market: marketOf, hooksFor } = await import('../js/worlds/jobs.js');
  const { ERC8004_ABI } = await import('../js/worlds/chain.js');
  const { jobById } = await import('../js/city/roster.js');
  resetCity(); resetAgents();
  const lumen = await loadWorld(join(REPO, 'worlds/portlumen'));
  const guild = await loadWorld(join(REPO, 'worlds/guildhouse'));
  let hooks = null;
  const net = await attachNet({ rpc, deployment: d, keys: k, worlds: [lumen, guild], city: city(), store, port, cronMs, log, jobsOnChain: (id) => hooks.jobsOnChain(id), launch, limits, extra, cityDoors });
  // WorldSettlement and its token are named only where a chain has them; `minter` is who may mint the test token there
  const market = marketOf(net.c, { jobs: d.jobs, settlement: d.settlement ?? null, token: d.token ?? null, minter: d.settlement ? k.deployer : null, fromBlock: d.fromBlock });
  hooks = hooksFor(market, { agentWalletOf: async (agentId) => net.chain.papers(agentId).then((p) => p.wallet || p.owner) });
  const maxCadence = Math.max(...Object.values(d.worlds).map((w) => Number(w.cadence)));
  const papersPatienceMs = (rehearsal ? 2 : 30) * 60_000;
  const registered = [];
  const env = {
    net, market, hooks, lumen, guild, log, runTag: Number(run) === 1 ? '' : `-r${run}`,
    keys: k.agents[`run${run}`], registered, evidence,
    // on a real chain an agent registers itself, its own transaction, on the ERC-8004 registry the chain's table names
    registerAgent: async (name, key) => {
      const tx = await net.c.write(key, net.core.identity, ERC8004_ABI, 'register', [], `${name} registers on the identity registry`);
      const rc = await net.c.pub.getTransactionReceipt({ hash: tx });
      const hit = rc.logs.map((l) => { try { return viem.decodeEventLog({ abi: ERC8004_ABI, data: l.data, topics: l.topics }); } catch { return null; } }).find((e) => e?.eventName === 'Registered');
      if (!hit) throw new Error(`${name}'s register did not emit Registered (${tx})`);
      log(`  ${name} registered as agent ${hit.args.agentId} (${tx})`);
      registered.push({ name, tx, agentId: hit.args.agentId.toString() });
      return hit.args.agentId.toString();
    },
    // a join reads papers at the safe head (read 2026-10-30: about 11 minutes behind on mainnet, 13 on the testnet)
    waitForPapers: async (agents) => {
      log('  waiting for the registrations to reach the safe head…');
      const until = Date.now() + papersPatienceMs;
      for (const a of agents) for (;;) {
        const p = await net.chain.papers(a.id).catch(() => null);
        if (p && !p.unsettled && p.owner && viem.getAddress(p.owner) === viem.getAddress(a.address)) break;
        if (Date.now() > until) throw new Error(`agent ${a.id}'s papers did not reach the safe head in time`);
        await new Promise((r) => setTimeout(r, 15_000));
      }
    },
    patienceMs: (3 * maxCadence + 120) * 1000, firstPostsMs: (4 * maxCadence + 120) * 1000,
    door: { cityDoor, resetAgents, TYPED, withCity, jobById },
    model: withModel ? (await import('../api/ai.js')).runAgentJSON : null,
    network, out, chainId,
  };
  return env;
}
