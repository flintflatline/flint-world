// WORLD STUDIO'S HOST (docs/world-deployer.md; node tools/worldnew.mjs studio). Two ways to serve js/worlds/studio:
//   startStudio()    A SANDBOX on this machine: a local chain (anvil, 31337), an index, a small open world to travel from, and any world the page
//                    deploys, run here on disposable keys. Listens on loopback only. Nothing touches a public chain.
//   exportStudio()   THE SAME PAGE AS STATIC FILES, for a browser wallet on the testnet. No keys, no server; the world itself is then run by
//                    its operator with `worldnew run`. Mainnet is read-only in the page. Publishing the folder is the owner's step.
import { readFileSync, writeFileSync, mkdirSync, copyFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import * as viem from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { artifact, devKey, LOCAL_CHAIN } from '../js/worlds/deployer.js';
import { startLocalNet } from '../js/worlds/localnet.js';
import { policyWorld } from '../js/worlds/templates/policy.js';
import * as P from '../js/worlds/protocol.js';

const here = dirname(fileURLToPath(import.meta.url));
const REPO = resolve(here, '..');
const SRC = join(REPO, 'js/worlds/studio');
const CSP = (connect) => `default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src ${connect}; frame-ancestors 'none'; base-uri 'none'; form-action 'none'`;
const FONT = join(REPO, 'fonts/manrope-800.woff2'); // GRIFT's own display face (fonts/OFL-NOTICE.txt): served from here, nothing fetched from elsewhere
const SANDBOX_OPERATOR = 2; // anvil's public account 2: the page's operator in the sandbox. Its key is on every anvil's first screen

export async function buildStudio() {
  const esbuild = await import('esbuild');
  const r = await esbuild.build({ absWorkingDir: REPO, entryPoints: [join(SRC, 'studio.js')], bundle: true, format: 'esm', write: false, minify: true, target: 'es2022', platform: 'browser', logLevel: 'silent', define: { 'process.env.VERCEL_ENV': '""', 'process.env': '{}' } });
  return r.outputFiles[0].text;
}
const artifacts = () => {
  const c = artifact('worldlocal', 'CityCommitsV2.sol', 'CityCommitsV2'), k = artifact('worldkeys', 'WorldKeyRegistry.sol', 'WorldKeyRegistry');
  return { commits: { abi: c.abi, bytecode: c.bytecode }, registry: { abi: k.abi, bytecode: k.bytecode } };
};

export async function startStudio({ port = 8700, anvilPort = 8560, log = () => {} } = {}) {
  const js = await buildStudio();
  const css = readFileSync(join(SRC, 'studio.css')), html = readFileSync(join(SRC, 'index.html'));
  const arts = JSON.stringify(artifacts());
  const font = readFileSync(FONT);
  const headers = { 'content-security-policy': CSP("'self'"), 'cache-control': 'no-store', 'x-content-type-options': 'nosniff', 'referrer-policy': 'no-referrer' };
  const page = (type, body) => ({ raw: { type, body, headers } });
  const origin = `http://127.0.0.1:${port}`;
  const worldKeys = new Map();
  const session = randomBytes(8).toString('hex'); // this sandbox chain's: a browser's memory of an earlier one does not carry over
  const waypoint = policyWorld({ id: 'waypoint', name: 'The Waypoint', about: 'A small open world in this sandbox, to travel from', capacity: 256, placeName: 'bench', cadence: 30, notes: { enabled: false } });
  const extra = async (req, url, body, net) => {
    const path = url.pathname;
    // A LOOPBACK TOOL: a page elsewhere, or a name that rebinds to this machine, gets nothing from these routes. Worlds' own routes are not behind this: they are public by design
    if (path === '/' || path.startsWith('/studio')) {
      const host = String(req.headers.host || '');
      if (host !== `127.0.0.1:${port}` && host !== `localhost:${port}`) return [403, { ok: false, reason: 'this tool answers on 127.0.0.1 only' }];
      if (req.headers.origin && req.headers.origin !== origin && req.headers.origin !== `http://localhost:${port}`) return [403, { ok: false, reason: 'not from this page' }];
    }
    if (req.method === 'GET') {
      if (path === '/' || path === '/index.html') return page('text/html; charset=utf-8', html);
      if (path === '/studio.js') return page('text/javascript; charset=utf-8', js);
      if (path === '/studio.css') return page('text/css; charset=utf-8', css);
      if (path === '/fonts/manrope-800.woff2') return page('font/woff2', font);
      if (path === '/studio/artifacts.json') return page('application/json', arts);
      if (path === '/studio/config.json') return [200, { ok: true, mode: 'sandbox', session, chainId: LOCAL_CHAIN, rpc: '/studio/rpc', origin, index: net.core.index, identity: net.core.identity, sandbox: { key: devKey(SANDBOX_OPERATOR), address: privateKeyToAccount(devKey(SANDBOX_OPERATOR)).address }, helperWorlds: ['waypoint'], running: Object.keys(net.engines) }];
    }
    if (req.method !== 'POST') return null;
    if (path === '/studio/rpc') { const r = await fetch(net.c.rpc, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(body) }); return page('application/json', await r.text()); }
    if (path === '/studio/worlds/keys') {
      const id = String(body?.id || '');
      if (!/^[a-z0-9]{3,24}$/.test(id)) return [422, { ok: false, reason: 'an id is 3 to 24 of a-z and 0-9' }];
      if (net.engines[id]) return [409, { ok: false, reason: `${id} is running already` }];
      if (!worldKeys.has(id)) worldKeys.set(id, { committer: generatePrivateKey(), signer: generatePrivateKey() });
      const k = worldKeys.get(id), committer = privateKeyToAccount(k.committer).address;
      await net.c.send(devKey(0), committer, viem.parseEther('1'), `${id}: committer gas (sandbox)`);
      return [200, { ok: true, committer, signer: privateKeyToAccount(k.signer).address }];
    }
    if (path === '/studio/worlds/start') {
      const spec = body?.spec, commits = body?.commits, keyRegistry = body?.keyRegistry;
      if (!viem.isAddress(String(commits)) || !viem.isAddress(String(keyRegistry))) return [422, { ok: false, reason: 'commits and keyRegistry are addresses' }];
      let def; try { def = policyWorld({ ...spec, generatedBy: 'World Studio' }); } catch (e) { return [422, { ok: false, reason: String(e.message).slice(0, 400) }]; }
      const keys = worldKeys.get(def.id);
      if (!keys) return [409, { ok: false, reason: `no keys were made for ${def.id} here` }];
      const eng = net.addWorld(def, { commits: viem.getAddress(commits), keyRegistry: viem.getAddress(keyRegistry), keys });
      await eng.flush().catch((e) => log(`flush ${def.id}: ${String(e?.reason || e?.message).slice(0, 160)}`));
      await net.learn().catch(() => {});
      return [200, { ok: true, url: net.urls[def.id], running: Object.keys(net.engines) }];
    }
    if (path === '/studio/agent') {
      if (!P.agentIdOk(String(body?.agentId)) || !viem.isAddress(String(body?.wallet))) return [422, { ok: false, reason: 'agentId and wallet' }];
      await net.setAgent(String(body.agentId), body.wallet);
      return [200, { ok: true, standIn: true }];
    }
    return null;
  };
  const net = await startLocalNet({ worlds: [waypoint], builtIns: false, port, anvilPort, log, extra });
  // A SANDBOX HAS NO DAILY CAP on listings: a person may try as many worlds as they like. Public indexes keep theirs
  await net.c.write(devKey(0), net.core.index, net.core.abis.index, 'setListingsPerDay', [0n], 'sandbox: no daily cap on listings');
  await net.flushAll();
  const relearn = setInterval(() => net.learn().catch(() => {}), 5_000);
  await net.learn().catch(() => {});
  return { url: `${origin}/`, origin, net, stop: async () => { clearInterval(relearn); await net.stop(); } };
}

// the static page, for a wallet on the testnet: nothing in it can send to mainnet, and it holds no key
export async function exportStudio({ out, index = null, chainId = 46630 }) {
  mkdirSync(out, { recursive: true });
  writeFileSync(join(out, 'studio.js'), await buildStudio());
  for (const f of ['index.html', 'studio.css']) copyFileSync(join(SRC, f), join(out, f));
  mkdirSync(join(out, 'fonts'), { recursive: true });
  copyFileSync(FONT, join(out, 'fonts/manrope-800.woff2'));
  mkdirSync(join(out, 'studio'), { recursive: true });
  writeFileSync(join(out, 'studio/artifacts.json'), JSON.stringify(artifacts()));
  writeFileSync(join(out, 'studio/config.json'), JSON.stringify({ ok: true, mode: 'wallet', chainId, rpc: P.RPC_FOR[chainId], index, identity: P.ERC8004_BY_CHAIN[chainId] ?? null, running: [] }, null, 1));
  const connect = `'self' ${new URL(P.RPC_FOR[chainId]).origin} https: http://127.0.0.1:* http://localhost:*`;
  writeFileSync(join(out, 'vercel.json'), JSON.stringify({ cleanUrls: true, headers: [{ source: '/(.*)', headers: [{ key: 'Content-Security-Policy', value: CSP(connect) }, { key: 'X-Content-Type-Options', value: 'nosniff' }, { key: 'Referrer-Policy', value: 'no-referrer' }, { key: 'Cache-Control', value: 'no-store' }] }] }, null, 1) + '\n');
  return { out };
}

if (process.argv[1] && fileURLToPath(import.meta.url) === process.argv[1]) {
  const i = process.argv.indexOf('--export');
  if (i >= 0) { const r = await exportStudio({ out: resolve(process.argv[i + 1]), index: process.argv[process.argv.indexOf('--index') + 1] && process.argv.includes('--index') ? process.argv[process.argv.indexOf('--index') + 1] : null }); console.log(`exported to ${r.out}. Publishing it is a separate step.`); process.exit(0); }
  const s = await startStudio({ log: console.log });
  console.log(`World Studio: ${s.url}`);
}
