// THE INDEX SERVICE, MINIMAL (docs/worlds-protocol.md §2.4; js/worlds/discovery.js). Reads a WorldIndex on chain, checks
// every listed world's manifest, signer and freshness, and serves what it found. It is a cache of public facts: anyone
// can run it against the same chain and get the same answer, and an agent can check every claim in it itself.
//
//   node tools/worldindexd.mjs --rpc <url> --index <WorldIndex> [--stand-in <identity registry>] [--port 8799] [--every 15]
//   GET /worlds            every listed world: its index entry, its checks, its freshness, whether it is offered
//   GET /worlds/<id>       one
//   GET /health            the block it last read, and when
// On a test chain papers come from a labelled stand-in (--stand-in); on 4663 from the ERC-8004 registry, always.
import http from 'node:http';
import * as viem from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import { viemChain } from '../js/worlds/chain.js';
import { discover } from '../js/worlds/discovery.js';

const argv = process.argv.slice(2);
const opt = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d; };
const rpc = opt('--rpc'), index = opt('--index');
if (!rpc || !index) { console.error('usage: --rpc <url> --index <WorldIndex address> [--stand-in <addr>] [--port 8799] [--every 15]'); process.exit(2); }
const pub = viem.createPublicClient({ transport: viem.http(rpc) });
const chainId = await pub.getChainId();
const chain = viemChain({ ...viem, privateKeyToAccount }, { rpc, chainId, identityStandIn: opt('--stand-in') });
let last = null, lastErr = null;
async function refresh() { try { last = await discover({ chain, pub, index: viem.getAddress(index), chainId }); lastErr = null; } catch (e) { lastErr = String(e?.shortMessage || e?.message || e).slice(0, 200); } }
await refresh();
setInterval(refresh, Number(opt('--every', 15)) * 1000);
const json = (res, code, body) => { res.writeHead(code, { 'content-type': 'application/json', 'access-control-allow-origin': '*' }); res.end(JSON.stringify(body)); };
http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/health') return json(res, 200, { ok: !lastErr, chainId, index, asOf: last?.asOf || null, error: lastErr });
  if (!last) return json(res, 503, { ok: false, reason: lastErr || 'not read yet' });
  if (u.pathname === '/worlds') return json(res, 200, last);
  const m = /^\/worlds\/([a-z0-9]{3,24})$/.exec(u.pathname);
  if (m) { const w = last.worlds.find((x) => x.id === m[1]); return w ? json(res, 200, { asOf: last.asOf, world: w }) : json(res, 404, { ok: false, reason: 'not listed' }); }
  return json(res, 404, { ok: false, reason: 'no such route' });
}).listen(Number(opt('--port', 8799)), '127.0.0.1', () => console.log(`index service on http://127.0.0.1:${opt('--port', 8799)} · chain ${chainId} · WorldIndex ${index}`));
