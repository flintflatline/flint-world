#!/usr/bin/env node
// THE WORLD DEPLOYER CLI (docs/world-deployer.md, docs/worlds-sdk.md). Make a world of the GRIFT worlds protocol, run it, check it and deploy it,
// without touching San Verano's code. Every chain step on a local chain uses disposable keys; anything public asks for its own keys,
// outside the repository, and a typed approval for that step, and mainnet is refused outright.
//
//   MAKE
//   node tools/worldnew.mjs create <id> --name "<Name>" [--template policy|jobs|guild] [--spec spec.json] [--dir <folder>]
//        policy options: [--mode open|travellers|invited] [--capacity 16] [--place berth] [--about "…"] [--cadence 30]
//        jobs and guild options: [--berths 8] [--seats 6]
//        scaffolds <folder>/<id>/ (default worlds/<id>/): world.json, world.mjs, .gitignore; refuses an existing world
//   node tools/worldnew.mjs check <id> [--dir <folder>]              its configuration's problems, its rules in words, its refusal codes
//
//   RUN IT HERE
//   node tools/worldnew.mjs dev <id> [<id> …] [--with-city] [--port 8790] [--anvil-port 8550]
//        a local chain, an index and only the worlds named, no San Verano unless --with-city, found through the index; Ctrl-C stops it
//   node tools/worldnew.mjs try <id> [--port 8790] [--anvil-port 8550]
//        the same, plus an agent's whole tour: out of a waypoint world, into this one, doing what it permits, and back, with every
//        crossing verified from the chain alone; exit 0 only if everything checked
//   node tools/worldnew.mjs studio [--port 8700] [--anvil-port 8560]  the frontend, on a local sandbox chain (tools/worldstudio.mjs)
//   node tools/worldnew.mjs conform <id> [<id> …] [--independent] [--json <file>]   the twelve conformance rules; --independent runs them with no San Verano
//   node tools/worldnew.mjs net [<id> …]                                            the network with San Verano and ONE STREET
//
//   READ AND OPERATE
//   node tools/worldnew.mjs status <id> --rpc <url> [--index <addr>] [--commits <addr>]     what the chain says, what is wrong, what comes next
//   node tools/worldnew.mjs operate <id> <action> [--args '{"open":false}'] --url <world base url> --keys <file> | --dev-account <n>
//        door | refuse | allow | invite | uninvite | notice: signed by the owner of the world's contracts, and sealed
//   node tools/worldnew.mjs verify --cite <file.json> --rpc <url> --index <addr> [--related <file.json>] [--identity <registry, for a chain with a stand-in>]
//        an item another world sealed, checked with only an RPC: what is fact, what is only that world's claim, what was not checked
//
//   DEPLOY (the testnet; a chain id of 46630 on a local RPC is a rehearsal; --direct, or an installed SDK, needs no Foundry)
//   node tools/worldnew.mjs keys <id> --out <file>                   its operator's, signer's and committer's keys, outside the repository, mode 600
//   node tools/worldnew.mjs deploy <id> --rpc http://127.0.0.1:8545 [--index <addr>] [--origin <url>]   a local chain (31337), disposable keys
//   node tools/worldnew.mjs deploy <id> --network testnet --keys <file> --origin <https url> --approve 46630 [--index <addr>] [--rpc <url>]
//   node tools/worldnew.mjs run <id> --deploy <record.json> --keys <file> [--rpc <url>] [--port 8790] [--store <file>] [--trust <id>=<contract>,…] [--trust-proxy cloudflare|last-hop]
import { writeFileSync, chmodSync, existsSync, readFileSync, mkdirSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join, resolve } from 'node:path';
import { randomBytes } from 'node:crypto';
import * as viem from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import { scaffold, loadWorld, clientsFor, deployWorld, devKey, LOCAL_CHAIN } from '../js/worlds/deployer.js';
import { normalizeSpec, specProblems, rulesOf, codesOf } from '../js/worlds/worldspec.js';
import * as P from '../js/worlds/protocol.js';

const here = dirname(fileURLToPath(import.meta.url));
// in this repository a world's folder defaults to worlds/; from an installed SDK, to worlds/ where you are
const INREPO = existsSync(join(here, '../.git'));
const WORLDS = INREPO ? join(here, '../worlds') : join(process.cwd(), 'worlds');
const CLI = INREPO ? 'node tools/worldnew.mjs' : 'npx worldnew';
const TESTNET = 46630;
const argv = process.argv.slice(2);
const opt = (k, d = null) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : d; };
const has = (k) => argv.includes(k);
const BOOL_FLAGS = ['--with-city', '--independent'];
const positional = argv.filter((a, i) => !a.startsWith('--') && !(i > 0 && argv[i - 1].startsWith('--') && !BOOL_FLAGS.includes(argv[i - 1])));
const [cmd, ...ids] = positional;
const dirOf = (id) => join(resolve(opt('--dir', WORLDS)), id || '');
const readJson = (f) => JSON.parse(readFileSync(f, 'utf8'));
const need = (v, what) => { if (v == null) throw new Error(`${cmd} needs ${what}`); return v; };
const specFlags = () => {
  const admission = { ...(opt('--mode') ? { mode: opt('--mode') } : {}) };
  return {
    ...(opt('--spec') ? readJson(opt('--spec')) : {}),
    ...(opt('--about') ? { about: opt('--about') } : {}),
    ...(opt('--capacity') ? { capacity: Number(opt('--capacity')) } : {}),
    ...(opt('--place') ? { placeName: opt('--place') } : {}),
    ...(opt('--cadence') ? { cadence: Number(opt('--cadence')) } : {}),
    ...(Object.keys(admission).length ? { admission } : {}),
  };
};
const printStatus = (s) => {
  console.log(`chain ${s.chainId}, block ${s.asOfBlock}`);
  console.log(`  contract  ${s.commits ?? 'none'}`);
  console.log(`  registry  ${s.keyRegistry ?? 'none'}`);
  console.log(`  owner     ${s.owner ?? '—'}${s.pendingOwner ? ` (offered to ${s.pendingOwner})` : ''}`);
  console.log(`  signer    ${s.signer.active ?? 'none active'}${s.signer.pending ? `; ${s.signer.pending.key} proposed` : ''}`);
  console.log(`  listing   ${s.listing ? `${s.listing.status}, lister ${s.listing.lister}, ${s.listing.manifestURI}` : 'not listed'}`);
  for (const [name, x] of Object.entries(s.streams)) console.log(`  ${name.padEnd(9)} ${x.commits} commits, latest period ${x.latestEpoch}, ${x.behind == null ? 'nothing posted' : `${x.behind} periods behind`}, every ${x.cadence} s`);
  for (const p of s.problems) console.log(`  PROBLEM   ${p}`);
  for (const n of s.next) console.log(`  NEXT      ${n}`);
};

async function main() {
  if (cmd === 'create') {
    const id = ids[0];
    const named = opt('--name') || (opt('--spec') && existsSync(opt('--spec')) ? readJson(opt('--spec')).name : null); // a whole configuration names itself
    if (!id || !named) throw new Error('usage: create <id> --name "<Name>" [--template policy|jobs|guild] (see the head of tools/worldnew.mjs)');
    const dir = dirOf(id), template = opt('--template', 'policy');
    const config = scaffold(dir, { id, name: named, template, berths: Number(opt('--berths', 8)), seats: Number(opt('--seats', 6)), cadence: opt('--cadence'), spec: template === 'policy' ? specFlags() : null, sdk: opt('--sdk') });
    const def = await loadWorld(dir); // it must load and pass defineWorld's checks
    console.log(`created ${dir}: ${def.name}, template ${template}${config.capacity ? `, ${config.capacity} ${config.placeName}s` : ''}${config.berths ? `, ${config.berths} berths` : ''}${config.seats ? `, ${config.seats} seats` : ''}, cadence ${def.cadence ?? 30} s; manifest at ${config.base}/.well-known/world.json`);
    console.log(`next: ${CLI} try ${id}${opt('--dir') ? ` --dir ${opt('--dir')}` : ''}`);
    return;
  }
  if (cmd === 'check') {
    const id = need(ids[0], '<id>');
    const config = readJson(join(dirOf(id), 'world.json'));
    if ((config.template ?? 'policy') === 'policy') {
      const problems = specProblems(config);
      for (const p of problems) console.log(`PROBLEM ${p.field}: ${p.problem}`);
      if (problems.length) process.exit(1);
      const s = normalizeSpec(config);
      for (const [k, v] of Object.entries(rulesOf(s))) console.log(`rule ${k}: ${v}`);
      console.log(`codes: ${Object.keys(codesOf(s)).join(', ')}`);
    }
    const def = await loadWorld(dirOf(id));
    console.log(`${def.name} is a world: actions ${Object.keys(def.actions).join(', ') || 'none'}; reads ${Object.keys(def.reads).join(', ') || 'none'}; operator ${Object.keys(def.operatorOps || {}).join(', ') || 'none'}`);
    return;
  }
  if (cmd === 'studio') {
    const { startStudio } = await import('./worldstudio.mjs');
    const s = await startStudio({ port: Number(opt('--port', 8700)), anvilPort: Number(opt('--anvil-port', 8560)), log: console.log });
    console.log(`World Studio: ${s.url}\nA local sandbox chain: nothing here is on a public chain. Ctrl-C stops it.`);
    process.on('SIGINT', async () => { await s.stop(); process.exit(0); });
    return;
  }
  if (cmd === 'keys') {
    const { keysFileProblem } = await import('./worldrun.mjs');
    const id = need(ids[0], '<id>'), out = need(opt('--out'), '--out <file>');
    const bad = keysFileProblem(out, { mustExist: false });
    if (bad) throw new Error(bad);
    if (existsSync(out)) throw new Error(`${out} exists: keys are never overwritten`);
    const k = { id, operator: generatePrivateKey(), signer: generatePrivateKey(), committer: generatePrivateKey() };
    mkdirSync(dirname(resolve(out)), { recursive: true, mode: 0o700 });
    writeFileSync(out, JSON.stringify(k, null, 2) + '\n', { mode: 0o600 });
    chmodSync(out, 0o600);
    console.log(`keys written to ${resolve(out)} (mode 600). Fund these with testnet ETH before deploying; no key is printed:`);
    console.log(`  operator   ${privateKeyToAccount(k.operator).address}  owns the world's contracts and lists it; pays for the deployment`);
    console.log(`  committer  ${privateKeyToAccount(k.committer).address}  posts its roots; needs a little gas for as long as it runs`);
    console.log(`  signer     ${privateKeyToAccount(k.signer).address}  signs its answers; needs no gas`);
    return;
  }
  if (cmd === 'deploy') {
    const id = need(ids[0], '<id>');
    const dir = dirOf(id);
    if (!existsSync(join(dir, 'world.json'))) throw new Error(`${dir} is not a world: create it first`);
    const def = await loadWorld(dir);
    if (opt('--network') === 'mainnet' || opt('--approve') === '4663') throw new Error('this deployer sends nothing to mainnet: its index is closed to the listers its owner names, and a listing burns the fee (docs/worlds-mainnet.md)');
    if (opt('--network') && opt('--network') !== 'testnet') throw new Error(`no network ${opt('--network')}: this deployer deploys to a local chain or to the testnet`);
    if (opt('--network') === 'testnet') {
      const { forgeScript, keysFileProblem, isLocalRpc } = await import('./worldrun.mjs');
      const keyFile = need(opt('--keys'), '--keys <file> (npx worldnew keys)');
      const bad = keysFileProblem(keyFile); if (bad) throw new Error(bad);
      if (opt('--approve') !== String(TESTNET)) throw new Error(`deploying sends transactions: it needs --approve ${TESTNET}, typed for this step`);
      const rpc = opt('--rpc', P.RPC_FOR[TESTNET]);
      const c = clientsFor(rpc, { chainId: TESTNET });
      const live = await c.pub.getChainId();
      if (live !== TESTNET) throw new Error(`that RPC is chain ${live}, not the testnet (${TESTNET})`);
      const rehearsal = isLocalRpc(rpc);
      const origin = need(opt('--origin'), '--origin <the public URL this world will be served from>');
      if (!rehearsal && !/^https:\/\//.test(origin)) throw new Error('a public world is served over https: --origin https://…');
      const k = readJson(keyFile);
      if (k.id !== id) throw new Error(`${keyFile} holds keys for ${k.id}, not ${id}`);
      const record = join(dir, `deploy.${TESTNET}${rehearsal ? '.rehearsal' : ''}.json`);
      if (existsSync(record)) throw new Error(`${record} exists: this world is deployed on this chain already`);
      const addr = (x) => privateKeyToAccount(x).address;
      const index = opt('--index');
      const cadence = def.cadence ?? P.CADENCE;
      const identityPart = opt('--stand-in') ? { identity: { address: opt('--stand-in'), standIn: true } } : {};
      const script = join(here, '../contracts/worldsdeploy/script/DeployWorld.s.sol');
      let d;
      if (existsSync(script) && !has('--direct')) {
        const gasPrice = (await c.fees()).maxFeePerGas;
        const fromBlock = Number(await c.pub.getBlockNumber());
        const t = forgeScript({ chainId: TESTNET, project: 'worldsdeploy', script: 'DeployWorld.s.sol', contract: 'DeployWorld', keyFor: k.operator, rpc, keys: k, gasPrice, log: console.log,
          env: { WORLD_ID: id, WORLD_COMMITTER: addr(k.committer), WORLD_SIGNER: addr(k.signer), WORLD_CADENCE: String(cadence), WORLD_SIGNER_IMMEDIATE: 'true', WORLDS_PUBLIC_DEPLOY_APPROVED: String(TESTNET), ...(index ? { WORLD_INDEX: index, WORLD_MANIFEST_URI: `${origin.replace(/\/$/, '')}${def.base}/.well-known/world.json` } : {}) } });
        d = { chainId: TESTNET, rehearsal, id, worldId: viem.keccak256(viem.toBytes(id)), origin, cadence, fromBlock, index: index || null, role: P.ROLE_NAME, commits: t.find((x) => x.contract === 'CityCommitsV2').address, keyRegistry: t.find((x) => /KeyRegistry/.test(x.contract || '')).address, operator: addr(k.operator), signer: addr(k.signer), committer: addr(k.committer), txs: t, ...identityPart };
      } else {
        // the SDK on its own: the same steps and refusals, sent directly (js/worlds/publicdeploy.js), with no Foundry needed
        const { deployWorldPublic } = await import('../js/worlds/publicdeploy.js');
        d = { ...(await deployWorldPublic({ rpc, chainId: TESTNET, id, keys: k, cadence, origin, base: def.base, index, log: console.log })), rehearsal, ...identityPart };
      }
      writeFileSync(record, JSON.stringify(d, null, 2) + '\n');
      console.log(`deployed ${def.name} on ${rehearsal ? 'a REHEARSAL of ' : ''}the testnet: CityCommitsV2 ${d.commits}, key registry ${d.keyRegistry}${index ? `, listed in ${index}` : ', not listed'}. Record: ${record}`);
      const { worldStatus } = await import('../js/worlds/operate.js');
      printStatus(await worldStatus({ pub: c.pub, index, id, commits: d.commits, keyRegistry: d.keyRegistry }));
      console.log(`next: ${CLI} run ${id} --deploy ${record} --keys ${keyFile}${rehearsal ? ` --rpc ${rpc}` : ''}`);
      return;
    }
    const c = clientsFor(opt('--rpc', 'http://127.0.0.1:8545'));
    await c.guard();
    const keyFile = join(dir, '.keys.31337.json');
    if (existsSync(keyFile)) throw new Error(`${keyFile} exists: this world is deployed on this chain already (a world's keys are never overwritten)`);
    const origin = opt('--origin', 'http://127.0.0.1:8790');
    const d = await deployWorld(c, { id, index: opt('--index'), manifestURI: `${origin}${def.base}/.well-known/world.json`, lister: devKey(0), cadence: def.cadence ?? P.CADENCE });
    writeFileSync(keyFile, JSON.stringify({ id, note: 'LOCAL, DISPOSABLE keys for anvil (31337) only; never funded anywhere else', ...d.keys }, null, 2) + '\n', { mode: 0o600 });
    chmodSync(keyFile, 0o600);
    writeFileSync(join(dir, 'deploy.31337.json'), JSON.stringify({ chainId: 31337, id, commits: d.commits, keyRegistry: d.keyRegistry, lister: d.lister, signer: d.signer, committer: d.committer, listing: d.listing, txs: c.txs }, null, 2) + '\n');
    console.log(`deployed ${def.name} on 31337: CityCommitsV2 ${d.commits}, KeyRegistry ${d.keyRegistry}${d.listing ? `, listed in ${opt('--index')} (${d.listing.tx})` : ''}`);
    return;
  }
  if (cmd === 'run') {
    const id = need(ids[0], '<id>');
    const d = readJson(need(opt('--deploy'), '--deploy <record.json>'));
    if (d.id !== id) throw new Error(`that record is ${d.id}'s, not ${id}'s`);
    const { keysFileProblem } = await import('./worldrun.mjs');
    const keyFile = need(opt('--keys'), '--keys <file>');
    const badKeys = keysFileProblem(keyFile); if (badKeys && !d.rehearsal) throw new Error(badKeys);
    const k = readJson(keyFile);
    if (k.id !== id) throw new Error(`that keys file is ${k.id}'s, not ${id}'s`);
    const { runWorld } = await import('../js/worlds/runworld.js');
    const def = await loadWorld(dirOf(id));
    const r = await runWorld({ def, rpc: opt('--rpc', P.RPC_FOR[d.chainId]), deployment: d, keys: k, storePath: opt('--store', join(dirOf(id), `.store.${d.chainId}.json`)), port: Number(opt('--port', 8790)), log: console.log, proxy: opt('--trust-proxy'), trust: Object.fromEntries(String(opt('--trust', '')).split(',').filter(Boolean).map((x) => x.split('='))) });
    if (!d.index && !opt('--trust')) console.log('this world names no index and trusts no other world: it refuses every citation until it does (--trust <id>=<contract>)');
    console.log(`${def.name} is up on ${r.network}${d.rehearsal ? ' (REHEARSAL)' : ''}: ${r.url}/.well-known/world.json`);
    process.on('SIGINT', async () => { await r.stop(); process.exit(0); });
    return;
  }
  if (cmd === 'status') {
    const id = need(ids[0], '<id>');
    const { worldStatus } = await import('../js/worlds/operate.js');
    const pub = viem.createPublicClient({ transport: viem.http(need(opt('--rpc'), '--rpc <url>')) });
    printStatus(await worldStatus({ pub, index: opt('--index'), id, commits: opt('--commits'), keyRegistry: opt('--registry') }));
    return;
  }
  if (cmd === 'operate') {
    const [id, action] = ids;
    need(id, '<id>'); need(action, '<action>');
    const url = need(opt('--url'), '--url <the world\'s base URL>');
    const manifest = (await (await fetch(`${url}/.well-known/world.json`)).json()).manifest;
    if (manifest?.id !== id) throw new Error(`${url} serves ${manifest?.id}, not ${id}`);
    if (manifest.chain === P.CHAIN_ID) throw new Error('this deployer sends nothing to mainnet worlds: their owner acts through docs/worlds-mainnet.md');
    if (opt('--dev-account') != null && manifest.chain !== LOCAL_CHAIN) throw new Error('--dev-account is anvil\'s public keys: only on a local chain');
    if (opt('--dev-account') == null) { const { keysFileProblem } = await import('./worldrun.mjs'); const bad = keysFileProblem(need(opt('--keys'), '--keys <file> or --dev-account <n>')); if (bad && manifest.chain === 46630 && !/127\.0\.0\.1|localhost/.test(url)) throw new Error(bad); }
    const key = opt('--dev-account') != null ? devKey(Number(opt('--dev-account'))) : readJson(need(opt('--keys'), '--keys <file> or --dev-account <n>')).operator;
    const { operatorMessage, operatorTypedData } = await import('../js/worlds/operate.js');
    const w = { name: manifest.name, chainId: manifest.chain, commits: manifest.commits.address };
    const msg = operatorMessage(id, action, JSON.parse(opt('--args', '{}')), { nonce: `0x${randomBytes(32).toString('hex')}`, contract: manifest.commits.address });
    const r = await fetch(`${new URL(url).origin}${manifest.api}/operator`, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ msg, sig: await privateKeyToAccount(key).signTypedData(operatorTypedData(w, msg)) }) });
    const body = await r.json();
    console.log(r.ok ? `${action}: done, sealed in period ${body.item?.epoch} as ${body.item?.kind}` : `${action}: refused (${r.status}): ${body.reason}`);
    if (!r.ok) process.exit(1);
    return;
  }
  if (cmd === 'verify') {
    const { verifyItem } = await import('../js/worlds/verifier.js');
    const pub = viem.createPublicClient({ transport: viem.http(need(opt('--rpc'), '--rpc <url>')) });
    const v = await verifyItem({ pub, index: need(opt('--index'), '--index <WorldIndex>'), identity: opt('--identity'), cite: readJson(need(opt('--cite'), '--cite <file>')), related: opt('--related') ? readJson(opt('--related')) : [] });
    // what a cited file holds is someone else's text: one line per statement, so it cannot print a line that looks like this tool's own
    const one = (x) => String(x).replace(/[\u0000-\u001f\u007f\u2028\u2029]/g, ' ');
    for (const c of v.checks) console.log(`${c.ok ? 'PASS' : 'FAIL'}  ${one(c.statement)}`);
    for (const f of v.facts) console.log(`FACT  ${one(f.statement)}  [${one(f.basis)}]`);
    for (const c of v.claims) console.log(`CLAIM ${one(c.field)}, as ${one(c.by)}'s operator states it: ${one(JSON.stringify(c.value)).slice(0, 140)}`);
    for (const u of v.unverified) console.log(`NOT CHECKED  ${one(u.what)}`);
    process.exit(v.ok ? 0 : 1);
  }
  if (cmd === 'dev' || cmd === 'try') {
    const { startLocalNet } = await import('../js/worlds/localnet.js');
    const { policyWorld } = await import('../js/worlds/templates/policy.js');
    const worlds = [];
    for (const id of ids) worlds.push(await loadWorld(dirOf(id)));
    if (!worlds.length && cmd === 'try') throw new Error('usage: try <id>');
    // the tour needs somewhere to leave from: a small open world of its own, deployed beside the one being tried
    if (cmd === 'try') worlds.push(policyWorld({ id: 'waypoint', name: 'The Waypoint', about: 'where a tour starts', capacity: 64, cadence: 30, notes: { enabled: false } }));
    const net = await startLocalNet({ worlds, builtIns: has('--with-city'), port: Number(opt('--port', 8790)), anvilPort: Number(opt('--anvil-port', 8550)), log: console.log });
    const stop = async () => { await net.stop(); process.exit(0); };
    process.on('SIGINT', stop);
    console.log(`network up, chain ${LOCAL_CHAIN}: ${Object.entries(net.urls).map(([id, u]) => `${id} ${u}`).join(' · ')} · discovery ${net.origin}/index/worlds`);
    const learnWhenVerified = async () => { for (let i = 0; i < 90; i++) { const d = await net.learn(); if (d.worlds.every((w) => w.verified)) return d; await new Promise((r) => setTimeout(r, 2000)); } return net.learn(); };
    await net.flushAll();
    const d = await learnWhenVerified();
    for (const w of d.worlds) console.log(`  ${w.id.padEnd(12)} ${w.status.padEnd(8)} ${w.offered ? 'OFFERED' : 'not offered yet'}${w.why.length ? ` (${w.why.join('; ')})` : ''}`);
    const relearn = setInterval(() => net.learn().catch(() => {}), 5_000);
    if (cmd === 'dev') {
      console.log(`\nan operator's act: ${CLI} operate ${ids[0] ?? '<id>'} door --args '{"open":false}' --url ${net.urls[ids[0]] ?? '<url>'} --dev-account ${5 + (has('--with-city') ? 2 : 0)}\nCtrl-C stops it.`);
      return;
    }
    const { runTour } = await import('../js/worlds/tour.js');
    const { operatorMessage, operatorTypedData } = await import('../js/worlds/operate.js');
    const target = ids[0];
    console.log(`\nthe tour: waypoint → ${target} → waypoint`);
    const invite = async (agentId) => {
      const w = net.engines[target].w, msg = operatorMessage(target, 'invite', { agentId: String(agentId) }, { nonce: `0x${randomBytes(32).toString('hex')}`, contract: w.commits });
      await net.engines[target].operator({ msg, sig: await privateKeyToAccount(net.listers[target]).signTypedData(operatorTypedData(w, msg)) });
    };
    const r = await runTour({ urls: net.urls, home: 'waypoint', target, agentId: String(Math.floor(Math.random() * 1e6) + 1), pub: net.c.pub, index: net.core.index, identity: net.core.identity, setAgent: net.setAgent, invite, log: console.log });
    clearInterval(relearn);
    console.log(`\n${r.ok ? 'PASS' : 'FAIL'}: ${r.steps.filter((s) => s.ok).length} of ${r.steps.length} steps; ${r.verified.filter((v) => v.ok).length} of ${r.verified.length} items verified from the chain alone. This was a local chain and a test agent.`);
    await net.stop();
    process.exit(r.ok ? 0 : 1);
  }
  if (cmd === 'net' || cmd === 'conform') {
    const { startLocalNet } = await import('../js/worlds/localnet.js');
    const targets = cmd === 'conform' ? ids : [];
    const worlds = [];
    for (const id of ids) if (!['sanverano', 'onestreet'].includes(id)) worlds.push(await loadWorld(dirOf(id)));
    // --independent: no San Verano and no ONE STREET; each world is probed beside a small open world of its own
    const independent = has('--independent');
    if (independent) worlds.push((await import('../js/worlds/templates/policy.js')).policyWorld({ id: 'waypoint', name: 'The Waypoint', about: 'a helper for these checks', capacity: 64, cadence: 30, notes: { enabled: false } }));
    const net = await startLocalNet({ worlds, builtIns: !independent, port: Number(opt('--port', 8790)), anvilPort: Number(opt('--anvil-port', 8550)), log: console.log });
    const stop = async () => { await net.stop(); process.exit(0); };
    process.on('SIGINT', stop);
    console.log(`network up: ${Object.entries(net.urls).map(([id, u]) => `${id} ${u}`).join(' · ')} · discovery ${net.origin}/index/worlds`);
    console.log('  waiting for every world\'s first posts (two cadences)…');
    await new Promise((r) => setTimeout(r, 70_000));
    const d = await net.learn();
    for (const w of d.worlds) console.log(`  ${w.id.padEnd(10)} ${w.status.padEnd(8)} ${w.offered ? 'OFFERED' : 'not offered'}${w.why.length ? ` (${w.why.join('; ')})` : ''}`);
    if (cmd === 'net') return;
    const { conform, table } = await import('./worldconform.mjs');
    const runs = [];
    for (const target of targets) {
      const pairWith = independent ? 'waypoint' : target === 'onestreet' ? 'sanverano' : 'onestreet';
      runs.push(await conform(net.urls[target], { rpc: net.c.rpc, pair: net.urls[pairWith], log: console.log, index: net.core.index }));
    }
    console.log('  idle for three cadences: rule 9 is then kept only by the heartbeat');
    await new Promise((r) => setTimeout(r, (3 * 30 + 10) * 1000));
    for (const run of runs) await run.finishCadence();
    for (const run of runs) console.log(`\n${table(run)}`);
    if (opt('--json')) writeFileSync(opt('--json'), JSON.stringify(runs.map(({ finishCadence, ...r }) => (void finishCadence, r)), null, 2) + '\n');
    await stop();
  }
  throw new Error('usage: create | check | dev | try | studio | status | operate | verify | keys | deploy | run | net | conform (see the head of tools/worldnew.mjs)');
}
main().catch((e) => { console.error(String(e?.message || e)); process.exit(1); });
