// THE CONFORMANCE SUITE, AGAINST A URL (docs/worlds-protocol.md §1.2, the eleven rules). A world is checked as an outsider
// sees it: its manifest, its answers, its contract on chain. No credentials, no key of anyone's.
//
//   node tools/worldconform.mjs <world url> [--rpc <url>] [--pair <other world url>] [--index <WorldIndex>] [--json <file>]
//   node tools/worldconform.mjs --local [--registry] [--release 0.2.0] [--json <file>]
//                                                          both v0 worlds on this machine (tools/worldserve.mjs), probed;
//                                                          --registry and --release as worldserve's
//   node tools/worldconform.mjs --trip docs/worlds/trip.json [--world sanverano|onestreet]
//                                                          the live v0 deployment on Robinhood Chain, from the trip's
//                                                          record and manifests, read-only
//
// PROBES WRITE: a join, a leave, refusals. They run ONLY against a local chain (chainId 31337 behind a 127.0.0.1 URL), with
// agents made here from throwaway keys and set on the harness's stand-in registry, or on a FORK a run gives (`fork`, below,
// tools/worldmainnet.mjs: a local chain carrying mainnet's id and the real registry, with agents it registers there). Anywhere
// else the rules that need a probe say NOT RUN. Each rule's verdict is PASS, FAIL, PARTIAL (passes with a stated deviation)
// or NOT RUN, with why.
import { readFileSync, writeFileSync } from 'node:fs';
import { randomBytes } from 'node:crypto';
import * as viem from 'viem';
import { privateKeyToAccount, generatePrivateKey } from 'viem/accounts';
import * as P from '../js/worlds/protocol.js';
import { viemChain } from '../js/worlds/chain.js';
import { streamStanding } from '../js/worlds/monitor.js';
import { INDEX_ABI, STATUS, listingFee } from '../js/worlds/discovery.js';
import { GENESIS } from '../js/worlds/genesis.js';
import { LISTING_BURN } from '../js/worlds/protocol.js';
import { REGISTRY_ABI } from '../js/worlds/chain.js';

export const RULES = [
  [1, 'no answer carries a transaction off the world\'s own allowlist'],
  [2, 'every money op\'s legs are re-derivable by the binder the allowlist publishes'],
  [3, 'other agents\' text is { untrustedText } everywhere it appears'],
  [4, 'every record() item verifies against the records stream on the world\'s contract'],
  [5, 'nothing in another world depends on this world answering'],
  [6, 'the manifest\'s signer is the registry\'s active RESPONSE_SIGNER'],
  [7, 'every refusal is coded and sealed'],
  [8, 'join with papers verifies the papers'],
  [9, 'records and decisions keep cadence'],
  [10, 'leave exists and seals'],
  [11, 'the allowlist\'s rows carry no ETH value and every approve is bounded'],
  [12, 'it paid the listing fee, or it is a founding world under the genesis policy'],
];
const RPC_FOR = { 4663: 'https://rpc.mainnet.chain.robinhood.com' };
const AUTHOR_FIELDS = ['name', 'line', 'sign', 'text', 'headline']; // `reason` on an answer is the world's own refusal text
const rnd = () => '0x' + randomBytes(32).toString('hex');
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));
// a fresh name each probe: the city keeps names unique, so a second run must not reuse the first's
const probeName = (first) => `${first} ${'BCDFGHJKLMNPRSTVWZ'[Math.floor(Math.random() * 18)]}${['a', 'e', 'i', 'o', 'u'][Math.floor(Math.random() * 5)]}${'lnrst'[Math.floor(Math.random() * 5)]}${['a', 'e', 'o'][Math.floor(Math.random() * 3)]}${'lmnrsv'[Math.floor(Math.random() * 6)]}`;

// a plain string where an agent's own words sit; signed payloads (evidence.request, a cite's itemText) are verbatim by
// necessity, since wrapping them would break the signature or the hash, and are left out
function plainAuthorText(x, path = '', out = []) {
  if (Array.isArray(x)) { x.forEach((v, i) => plainAuthorText(v, `${path}[${i}]`, out)); return out; }
  if (!x || typeof x !== 'object') return out;
  for (const [k, v] of Object.entries(x)) {
    const p = path ? `${path}.${k}` : k;
    if (/(^|\.)evidence\.request$|(^|\.)cite$|(^|\.)verify$|(^|\.)att$|(^|\.)rules$/.test(p)) continue;
    if (AUTHOR_FIELDS.includes(k) && typeof v === 'string') out.push(p);
    else if (v && typeof v === 'object' && !('untrustedText' in v)) plainAuthorText(v, p, out);
  }
  return out;
}
// the served item, back to what its leaf hashes: §1.3 has the world serve `verify.canonical`; v0 serves the item with
// presentation fields (label, cite) beside it, which a reader strips
function canonicalOf(item) {
  if (item?.verify?.canonical) return { text: item.verify.canonical, served: true };
  const { verify, label, cite, ...rest } = item; void verify; void label; void cite;
  return { text: P.itemCanonical(rest), served: false };
}
const leafOfCanonical = (item, text) => viem.keccak256(viem.keccak256(viem.encodeAbiParameters(P.RECORD_TYPES, [BigInt(item.epoch), BigInt(item.agentId), String(item.kind), viem.keccak256(viem.toBytes(text))])));

async function verifyItems(chain, contract, items) {
  const out = { ok: 0, failed: [], pending: 0, canonicalServed: true };
  for (const it of items) {
    if (!it.verify?.proof || !it.verify?.posted || it.verify.posted.unpostable) { out.pending++; continue; }
    const c = canonicalOf(it);
    if (!c.served) out.canonicalServed = false;
    const leaf = leafOfCanonical(it, c.text);
    if (leaf !== it.verify.leaf) { out.failed.push(`${it.id}: its canonical text does not hash to its leaf`); continue; }
    if (contract && viem.getAddress(it.verify.contract) !== viem.getAddress(contract)) { out.failed.push(`${it.id}: verify.contract is not the manifest's`); continue; }
    let good = false; try { good = await chain.verify(viem.getAddress(it.verify.contract), P.STREAM.records, BigInt(it.verify.epoch), leaf, it.verify.proof); } catch (e) { out.failed.push(`${it.id}: verify() could not be read (${String(e?.shortMessage || e?.message).slice(0, 80)})`); continue; }
    if (good) out.ok++; else out.failed.push(`${it.id}: verify() is false on chain`);
  }
  return out;
}
async function cadenceOf(chain, contract, streams) {
  const now = Math.floor(Date.now() / 1000), out = [];
  for (const [name, id] of streams) {
    try {
      const s = await chain.streamOf(contract, id);
      const behind = s.commitCount ? Math.floor(now / s.cadence) - s.latestEpoch : null;
      out.push({ name, id, cadence: s.cadence, latestEpoch: s.latestEpoch, commits: s.commitCount, behind, fresh: behind != null && behind <= 2 });
    } catch (e) { out.push({ name, id, error: String(e?.shortMessage || e?.message).slice(0, 120), fresh: false }); }
  }
  return out;
}
const say = (cad) => cad.map((s) => s.error ? `${s.name}: ${s.error}` : `${s.name} (${s.cadence}s): ${s.commits ? `latest epoch ${s.latestEpoch}, ${s.behind} cadences behind now` : 'never posted'}`).join('; ');

// RULE 9 BY THE MONITOR'S RULE (js/worlds/monitor.js): each required stream fresh, and its latest epoch's leaves served,
// with any alive entry signed by the manifest's signer for that world, stream and epoch
// RULE 6: the manifest's signer is its registry's active key for the role the manifest maps RESPONSE_SIGNER to, read on
// chain, and the served manifest's own signature recovers to it. The rule's second half (the registry's owner is the
// WorldIndex entry's owner, §2.4) needs a listing, so without one the verdict is PARTIAL and says so
async function rule6(chain, m, body, index = null) {
  const reg = m?.keyRegistry;
  if (!reg?.address) return null;
  const roleName = reg.roles?.[P.ROLE_NAME];
  if (!roleName) return { verdict: 'FAIL', detail: `keyRegistry ${reg.address} maps no role to ${P.ROLE_NAME}` };
  if (!chain) return { verdict: 'NOT RUN', detail: 'no RPC to read the registry' };
  let active = null; try { active = await chain.activeKey(viem.getAddress(reg.address), viem.keccak256(viem.toBytes(roleName))); } catch (e) { return { verdict: 'FAIL', detail: `the registry ${reg.address} could not be read (${String(e?.shortMessage || e?.message).slice(0, 100)})` }; }
  if (!active || viem.getAddress(active) !== viem.getAddress(m.signer?.address || '0x0000000000000000000000000000000000000000')) return { verdict: 'FAIL', detail: `the manifest's signer ${m.signer?.address} is not the active ${roleName} on ${reg.address} (${active ? `active: ${active}` : 'none active'})` };
  const signedBy = body?.att && body.hash === P.manifestHash(m) ? await P.recoverAnswerSigner({ name: m.name, commits: m.commits?.address, chainId: m.chain }, { manifestHash: body.hash }, body.att) : null;
  if (!signedBy || viem.getAddress(signedBy) !== viem.getAddress(active)) return { verdict: 'FAIL', detail: `the signer is the active ${roleName}, but the served manifest's signature ${body?.att ? 'does not recover to it' : 'is missing'}${body?.unsigned ? ` (${body.unsigned})` : ''}` };
  // the second half (§2.4): the registry's owner is the world's lister on the index, read on chain
  if (index && chain.pub) {
    try {
      const entry = await chain.pub.readContract({ address: viem.getAddress(index), abi: INDEX_ABI, functionName: 'worldOf', args: [viem.keccak256(viem.toBytes(String(m.id)))] });
      const owner = await chain.pub.readContract({ address: viem.getAddress(reg.address), abi: REGISTRY_ABI, functionName: 'owner' });
      if (STATUS[Number(entry.status)] === 'NONE') return { verdict: 'FAIL', detail: `${m.id} is not listed on WorldIndex ${index}` };
      if (viem.getAddress(owner) !== viem.getAddress(entry.lister)) return { verdict: 'FAIL', detail: `the registry's owner ${owner} is not the WorldIndex lister ${entry.lister}` };
      if (viem.getAddress(entry.keyRegistry) !== viem.getAddress(reg.address)) return { verdict: 'FAIL', detail: `the index names KeyRegistry ${entry.keyRegistry}, the manifest ${reg.address}` };
      return { verdict: 'PASS', detail: `the manifest's signer ${active} is the active ${roleName} on ${reg.address}, the manifest's signature recovers to it, and the registry's owner is ${m.id}'s lister on WorldIndex ${index} (${STATUS[Number(entry.status)]}), all read on chain. The signature rides in the body (att), not a header` };
    } catch (e) { return { verdict: 'FAIL', detail: `the index or the registry could not be read (${String(e?.shortMessage || e?.message).slice(0, 100)})` }; }
  }
  return { verdict: 'PARTIAL', detail: `the manifest's signer ${active} is the active ${roleName} on ${reg.address} (read on chain), and the manifest's signature recovers to it; not checked: that the registry's owner is the WorldIndex entry's owner (no index given). The signature rides in the body (att), not a header` };
}

async function rule9(chain, m, api, contract, { idle = false } = {}) {
  const world = { id: m.id, name: m.name, commits: contract, chainId: m.chain }, signer = m.signer?.address;
  const per = [];
  for (const [name, id] of [['records', P.STREAM.records], ['decisions', P.STREAM.decisions]]) {
    let so; try { so = await chain.streamOf(contract, id); } catch (e) { per.push({ name, standing: 'STALE', why: String(e?.shortMessage || e?.message).slice(0, 100) }); continue; }
    let leaves = null, root = null;
    if (so.commitCount) { try { const x = await fetch(`${api}/leaves?stream=${id}&epoch=${so.latestEpoch}`); if (x.status === 200) leaves = (await x.json()).entries; } catch { leaves = null; } try { root = (await chain.commitOf(contract, id, so.latestEpoch)).root; } catch { root = null; } }
    per.push({ name, ...(await streamStanding({ stream: id, streamOf: so, leaves, world, signer, root })) });
  }
  const text = per.map((x) => `${x.name}: ${x.standing}${x.behind != null ? `, ${x.behind} cadence(s) behind` : ''}${x.kept ? `, kept by ${x.kept}` : ''}${x.why ? ` (${x.why})` : ''}`).join('; ');
  const fresh = per.every((x) => x.standing === 'FRESH');
  return { verdict: fresh ? 'PASS' : 'FAIL', detail: `${idle ? 'after three idle cadences: ' : ''}${text}` };
}

// RULE 11 FROM THE ALLOWLIST ITSELF, and rule 1's half that can be read: a world names its own list, each row carries no ETH and
// each approve is bounded. A list with no rows passes, and says it passes because this world hands out no transaction at all
// A TRANSACTION HANDED TO A WALLET, by what a field holds and not only its name: a record's `posted: { tx: '0x…' }` is the hash
// of what the world already sent, and hands nobody anything
export function txFieldsIn(x, out = []) {
  if (Array.isArray(x)) { for (const v of x) txFieldsIn(v, out); return out; }
  if (!x || typeof x !== 'object') return out;
  if (typeof x.to === 'string' && typeof x.data === 'string') out.push('to+data');
  for (const [k, v] of Object.entries(x)) {
    if (['toSign', 'approvalTx', 'transfers', 'calls', 'transactions'].includes(k) && v != null) out.push(k);
    else if ((k === 'tx' || k === 'transaction') && v && typeof v === 'object') out.push(k);
    else if (k === 'transaction' && typeof v === 'string') out.push(k);
    txFieldsIn(v, out);
  }
  return out;
}
// the selectors that hand someone else a token: each must be bounded, with its spenders named (approve, increaseAllowance, setApprovalForAll, permit)
const APPROVALS = ['0x095ea7b3', '0x39509351', '0xa22cb465', '0xd505accf'];
async function allowlistRules(m, origin, results) {
  let doc = null;
  const where = new URL(m.allowlist, `${origin}/`);
  try { const x = await fetch(where); if (x.status === 200) doc = await x.json(); } catch { doc = null; }
  // the list is the world's own: served from its origin, naming this world and this chain
  if (!doc || !Array.isArray(doc.entries) || where.origin !== origin || doc.world !== m.id || Number(doc.chain) !== Number(m.chain)) {
    results[1] = { verdict: 'FAIL', detail: `the manifest names an allowlist at ${m.allowlist}, and this world's own is not served there` };
    results[11] = { verdict: 'FAIL', detail: 'this world\'s own allowlist is not served, so nothing can be checked' };
    return null;
  }
  const bad = doc.entries.filter((e) => BigInt(e.value ?? 0) !== 0n || (APPROVALS.includes(String(e.selector).toLowerCase()) && !(e.bounded === true && Array.isArray(e.spenders) && e.spenders.length)));
  results[11] = bad.length ? { verdict: 'FAIL', detail: `${bad.length} row(s) carry ETH or an unbounded approve` }
    : { verdict: 'PASS', detail: doc.entries.length ? `all ${doc.entries.length} rows carry no ETH and every approve is bounded` : 'its own allowlist has no rows: it hands an agent no transaction, so none can carry ETH (vacuous, and that is the point)' };
  return doc;
}

function staticRules(m, results) {
  const allow = m?.allowlist;
  results[1] = allow ? null : { verdict: 'FAIL', detail: 'the manifest names no allowlist (§1.2 requires one); no answer seen carried a transaction either' };
  const money = (m?.ops || []).filter((o) => o.money);
  results[2] = money.length ? (allow ? null : { verdict: 'FAIL', detail: `money ops ${money.map((o) => o.op).join(', ')} and no allowlist or binders` }) : { verdict: 'PASS', detail: 'vacuous: the manifest marks no op money (v0 charges nothing)' };
  results[6] = m?.keyRegistry?.address ? null : { verdict: 'FAIL', detail: `no keyRegistry in the manifest: its signer ${m?.signer?.address || '?'} is a "${m?.signer?.label || '?'}", not a registry's active RESPONSE_SIGNER; the signature rides in the body (att), not a header` };
  results[11] = allow ? null : { verdict: 'FAIL', detail: 'nothing to check: no allowlist published' };
}

// what the world paid to be listed (§4.1, docs/worlds-genesis.md), read from the chain with discovery's own rule: on mainnet a real burn, or
// for one of the four founding worlds, on the one index the policy applies to, its marker. Nothing else passes
export async function rule12(chain, m, index, chainId, genesisIndex) {
  if (chainId !== LISTING_BURN.chainId) return { verdict: 'PASS', detail: `no listing fee is read on chain ${chainId}` };
  if (!index || !chain?.pub) return { verdict: 'NOT RUN', detail: 'needs --index, and an RPC' };
  try {
    const worldId = viem.keccak256(viem.toBytes(String(m.id)));
    const at = viem.getAddress(index);
    const entry = await chain.pub.readContract({ address: at, abi: INDEX_ABI, functionName: 'worldOf', args: [worldId] });
    if (STATUS[Number(entry.status)] === 'NONE') return { verdict: 'FAIL', detail: `${m.id} is not listed on WorldIndex ${index}` };
    const fee = await listingFee({ pub: chain.pub, index: at, worldId, entry, chainId, genesisIndex });
    if (!fee.ok) return { verdict: 'FAIL', detail: fee.why };
    return { verdict: 'PASS', detail: fee.genesis ? `${m.id} burnt no fee: a founding world, listed free once by ${fee.from}, under the genesis policy ${fee.policy}` : `${fee.from} burnt ${viem.formatEther(BigInt(fee.amount))} $GRIFT to list ${m.id}` };
  } catch (e) { return { verdict: 'FAIL', detail: `the index could not be read (${String(e?.shortMessage || e?.message).slice(0, 100)})` }; }
}

// ---- against a URL ----------------------------------------------------------------------------------------------------
// fork: { makeAgent() → { acct, agentId }, down(worldId, bool), waitMs } for a local fork of a real chain, given only by a run
export async function conform(url, { rpc = null, pair = null, log = () => {}, index = null, fork = null, genesisIndex = GENESIS.index } = {}) {
  const results = {};
  url = url.replace(/\/$/, '');
  const origin = new URL(url).origin;
  let r, body;
  try { r = await fetch(`${url}/.well-known/world.json`); body = await r.json().catch(() => null); } catch (e) { r = { status: 0 }; body = null; log(String(e)); }
  if (r.status !== 200 || !body) {
    for (const [n] of RULES) results[n] = { verdict: 'FAIL', detail: `no manifest at ${url}/.well-known/world.json (HTTP ${r.status}): nothing else can be found or checked` };
    return { url, world: null, results };
  }
  const m = body.manifest ?? body;
  const api = origin + m.api;
  rpc = rpc || RPC_FOR[m.chain];
  const chainId = rpc ? Number(await (await fetch(rpc, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify({ jsonrpc: '2.0', id: 1, method: 'eth_chainId', params: [] }) })).json().then((j) => j.result)) : null;
  const chain = rpc ? viemChain({ ...viem, privateKeyToAccount }, { rpc, chainId }) : null;
  const onThisMachine = ['127.0.0.1', 'localhost'].includes(new URL(url).hostname);
  const local = onThisMachine && (chainId === 31337 || (!!fork && /^https?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(String(rpc))));
  staticRules(m, results);
  const ownList = m.allowlist ? await allowlistRules(m, origin, results) : null;
  results[6] ??= await rule6(chain, m, body, index);
  results[12] ??= await rule12(chain, m, index, chainId, genesisIndex);
  const contract = m.commits?.address;
  if (!local) {
    if (ownList) results[1] ??= { verdict: ownList.entries.length ? 'NOT RUN' : 'PARTIAL', detail: ownList.entries.length ? 'needs a probe to see the answers' : 'its own allowlist has no rows and its manifest marks no op money, so nothing it may answer can carry a transaction; no answer was probed here (probes never write to a public chain)' };
    for (const n of [3, 4, 5, 7, 8, 10]) results[n] ??= { verdict: 'NOT RUN', detail: 'needs a probe; probes write and run only against a local chain' };
    results[9] = chain && contract ? await rule9(chain, m, api, contract) : { verdict: 'FAIL', detail: 'no contract or no RPC' };
    return { url, world: m.id, results };
  }

  // ---- the probes (local only) --------------------------------------------------------------------------------------
  const W = { name: m.name, chainId: m.chain, commits: m.commits?.address };
  const post = async (u, b) => { const x = await fetch(u, { method: 'POST', headers: { 'content-type': 'application/json' }, body: JSON.stringify(b) }); return { code: x.status, ...(await x.json()) }; };
  const get = async (u) => { const x = await fetch(u); return { code: x.status, ...(await x.json()) }; };
  let nextId = 900000 + Math.floor(Math.random() * 90000);
  const agent = async () => { if (fork) return fork.makeAgent(); const acct = privateKeyToAccount(generatePrivateKey()); const agentId = String(nextId++); await post(`${origin}/_local/agent`, { agentId, wallet: acct.address }); return { acct, agentId }; };
  const waitMs = fork?.waitMs ?? 150_000;
  const joinAt = async (apiUrl, w, a, name, from, signer = a.acct) => { const j = { agentId: a.agentId, world: w.id, name, challenge: rnd(), ts: Date.now() }; return post(`${apiUrl}/join`, { join: j, sig: await signer.signTypedData(P.joinTypedData(w, j)), ...(from ? { from } : {}) }); };
  const leaveAt = async (apiUrl, w, a) => { const msg = JSON.stringify({ v: 1, op: 'leave', world: w.id, agentId: a.agentId, ts: Date.now(), nonce: rnd() }); return post(`${apiUrl}/leave`, { msg, sig: await a.acct.signTypedData(P.requestTypedData(w, msg)) }); };
  const answers = [];
  const keep = (x) => { answers.push(x); return x; };
  // every probe signs in the world's own chain's domain (the manifest's `chain`)
  const Wd = { id: m.id, name: m.name, chainId: m.chain, commits: m.commits?.address };

  // the pair world, for rule 5: an agent leaves it, then this world must admit it on the chain alone
  let pm = null, papi = null, A = null;
  if (pair) { const pb = await get(`${pair}/.well-known/world.json`); pm = pb.manifest ?? pb; papi = new URL(pair).origin + pm.api; A = await agent(); keep(await joinAt(papi, { id: pm.id, name: pm.name, chainId: pm.chain, commits: pm.commits?.address }, A, (A.name = probeName('Ayla')))); keep(await leaveAt(papi, { id: pm.id, name: pm.name, chainId: pm.chain, commits: pm.commits?.address }, A)); }
  // B: a join and a leave here (rules 3, 4, 10)
  const B = await agent();
  B.name = probeName('Berit');
  let jB = keep(await joinAt(api, Wd, B, B.name));
  // A WORLD MAY ADMIT ONLY AGENTS ARRIVING FROM ANOTHER WORLD (GUILD HOUSE does): a walk-in refused with a code the
  // manifest maps to one of its rules is that world's rule, not a failure. The probe then arrives as the world asks,
  // citing a departure from the pair world, posted and checked on chain
  let admittedVia = 'a walk-in join';
  const ownRule = (r) => { const code = /^([A-Z][A-Z_]+):/.exec(r?.reason || '')?.[1]; return r?.code === 403 && code && m.codes?.[code] && m.rules?.[m.codes[code]] ? code : null; };
  if (jB.code !== 201 && ownRule(jB) && pair) {
    const why = ownRule(jB);
    keep(await joinAt(papi, { id: pm.id, name: pm.name, chainId: pm.chain, commits: pm.commits?.address }, B, B.name));
    keep(await leaveAt(papi, { id: pm.id, name: pm.name, chainId: pm.chain, commits: pm.commits?.address }, B));
    const until = Date.now() + waitMs;
    let depB = null;
    while (!depB && Date.now() < until) { const rb = await get(`${papi}/record?agentId=${B.agentId}`); depB = (rb.items || []).find((x) => x.kind === 'departed' && x.cite); if (!depB) await sleep(3000); }
    if (depB) { jB = keep(await joinAt(api, Wd, B, B.name, depB.cite)); admittedVia = `a join citing its departure from ${pm.name} (the world refuses walk-ins: ${why} → rules.${m.codes[why]})`; }
  }
  const lB = keep(await leaveAt(api, Wd, B));
  // C: refusals (rule 7): a leave from an agent not here; a join with a name the rules refuse
  const C = await agent();
  const notHere = keep(await leaveAt(api, Wd, C));
  const badName = keep(await joinAt(api, Wd, C, 'x'));
  // D: a Join signed by a wallet the registry does not name (rule 8)
  const D = await agent();
  const forged = keep(await joinAt(api, Wd, D, probeName('Dara'), null, privateKeyToAccount(generatePrivateKey())));
  log(`  probes sent: join ${jB.code}, leave ${lB.code}, not-here leave ${notHere.code}, bad name ${badName.code}, forged papers ${forged.code}`);

  // wait for the cron to seal and post (30 s epochs, 5 s grace; a fork's run says its own cadence's patience)
  const until = Date.now() + waitMs;
  let recB, depA;
  for (;;) {
    recB = await get(`${api}/record?agentId=${B.agentId}`);
    if (pair) { const ra = await get(`${papi}/record?agentId=${A.agentId}`); depA = (ra.items || []).find((x) => x.kind === 'departed' && x.cite); }
    const doneB = (recB.items || []).length >= 2 && recB.items.every((x) => x.verify?.posted?.tx || x.verify?.posted?.found);
    const decs = [notHere.decision, badName.decision].filter((d) => d?.sealed);
    const decsPosted = await Promise.all(decs.map(async (d) => { const lv = await get(`${api}/leaves?stream=${d.stream}&epoch=${d.epoch}`); return lv.code === 200 && lv.posted?.tx; }));
    if (doneB && (!pair || depA) && decsPosted.every(Boolean)) break;
    if (Date.now() > until) { log('  timed out waiting for posts'); break; }
    await sleep(3000);
  }
  keep(recB);

  // 3
  const plain = plainAuthorText(answers);
  results[3] = plain.length ? { verdict: 'FAIL', detail: `agents' own words as plain strings at ${[...new Set(plain.map((p) => p.replace(/\[\d+\]/g, '[]')))].join(', ')}` } : { verdict: 'PASS', detail: 'every agent-written field seen is wrapped' };
  // 4
  const v4 = await verifyItems(chain, contract, recB.items || []);
  results[4] = v4.failed.length || !v4.ok ? { verdict: 'FAIL', detail: `${v4.ok} verified, ${v4.failed.length} failed${v4.failed.length ? `: ${v4.failed.join('; ')}` : ''}, ${v4.pending} not posted` }
    : { verdict: v4.canonicalServed ? 'PASS' : 'PARTIAL', detail: `${v4.ok} of ${v4.ok + v4.pending} items verify on chain (the probe came in by ${admittedVia})${v4.canonicalServed ? '' : '; the world serves no verify.canonical (§1.3), so the reader strips label and cite to rebuild it'}` };
  // 5
  if (pair && depA) {
    if (fork) fork.down(pm.id, true); else await post(`${origin}/_local/down`, { world: pm.id, down: true });
    const arrive = keep(await joinAt(api, Wd, A, A.name, depA.cite));
    if (fork) fork.down(pm.id, false); else await post(`${origin}/_local/down`, { world: pm.id, down: false });
    results[5] = arrive.code === 201 ? { verdict: 'PASS', detail: `with ${pm.name} answering 503 to everything, this world admitted an agent citing its departure, checked on chain alone` } : { verdict: 'FAIL', detail: `with ${pm.name} down, a join citing its departure answered ${arrive.code} ${arrive.reason}` };
  } else results[5] = { verdict: 'NOT RUN', detail: pair ? 'the pair world\'s departure was not posted in time' : 'needs --pair' };
  // 7
  const sealedIn = async (d) => { if (!d?.sealed) return false; const lv = await get(`${api}/leaves?stream=${d.stream}&epoch=${d.epoch}`); return lv.code === 200 && (lv.entries || []).some((e) => e.leaf === d.leaf && e.entry.kind === 'refused'); };
  const refusals = [['a leave from an agent not here', notHere], ['a join with a refused name', badName]];
  // a refusal names its rule when its reason starts with a code (`CODE: words`) the manifest's `codes` maps to a key of its `rules`
  const codeOf = (reason) => /^([A-Z][A-Z_]+):/.exec(reason || '')?.[1] || null;
  const ruleOf = (code) => (code && m.codes && typeof m.codes[code] === 'string' && m.rules && m.codes[code] in m.rules ? m.codes[code] : null);
  const r7 = await Promise.all(refusals.map(async ([what, a]) => ({ what, code: a.code, reason: a.reason, coded: a.code >= 400 && a.code < 500 && !!a.reason, prefix: codeOf(a.reason), rule: ruleOf(codeOf(a.reason)), sealed: await sealedIn(a.decision) })));
  results[7] = r7.every((x) => x.coded && x.sealed)
    ? { verdict: r7.every((x) => x.rule) ? 'PASS' : 'PARTIAL', detail: r7.map((x) => `${x.what}: ${x.code} sealed as refused${x.rule ? `, ${x.prefix} → rules.${x.rule}` : x.prefix ? `, coded ${x.prefix}, but the manifest maps no codes to its rules (release ${m.release})` : `, but its reason ("${x.reason}") starts with no code`}`).join('; ') }
    : { verdict: 'FAIL', detail: r7.map((x) => `${x.what}: ${x.code} ${x.coded ? 'coded' : 'not coded'}, ${x.sealed ? 'sealed' : 'not found sealed'}`).join('; ') };
  // 8
  const standIn = m.papers?.standIn ? `; papers are read from a STAND-IN registry ${m.papers.registry} on chain ${m.papers.chain}, labelled in the manifest` : '';
  results[8] = m.papers?.standIn && Number(m.chain) === P.CHAIN_ID ? { verdict: 'FAIL', detail: `a manifest on chain ${P.CHAIN_ID} names a stand-in identity registry` }
    : forged.code === 403 && /PAPERS_MISMATCH/.test(forged.reason || '') ? { verdict: 'PASS', detail: `403 PAPERS_MISMATCH${forged.decision?.sealed ? ', sealed as refused for agentId 0' : ''}${standIn}` } : { verdict: 'FAIL', detail: `a Join signed by the wrong wallet answered ${forged.code} ${forged.reason || ''}` };
  // 9
  // rule 9 is judged after the world has been idle a while (finishCadence, below): fresh then only on its heartbeat
  results[9] = { verdict: 'NOT RUN', detail: 'pending the idle wait' };
  // 10
  const dep = (recB.items || []).find((x) => x.kind === 'departed');
  const ops = (m.ops || []).map((o) => o.op);
  results[10] = ops.includes('leave') && lB.code === 200 && dep?.verify?.posted ? { verdict: 'PASS', detail: `leave answered 200 and its departed item was sealed and posted (epoch ${dep.verify.epoch})` } : { verdict: 'FAIL', detail: `leave ${lB.code} ${lB.reason || ''}; departed ${dep ? 'not posted' : 'missing'}` };
  // 1, again: did any answer carry a transaction?
  const txLike = JSON.stringify(answers).match(/"toSign"|"data":"0x[0-9a-fA-F]{8}/g);
  if (results[1]?.verdict === 'FAIL' && txLike) results[1].detail += `; and ${txLike.length} answer field(s) look like transactions`;
  if (ownList) {
    const carried = txFieldsIn(answers).length;
    results[1] = carried && !ownList.entries.length ? { verdict: 'FAIL', detail: `${carried} answer field(s) carry a transaction, and its own allowlist has no rows` }
      : carried ? { verdict: 'NOT RUN', detail: `${carried} answer field(s) carry a transaction; matching them to rows is not built, since no world here has rows` }
        : { verdict: 'PASS', detail: `none of the ${answers.length} answers seen carries a transaction, as its own allowlist (no rows) says. The probes saw join, leave and record, not a world's own actions` };
  }
  return { url, world: m.id, results, finishCadence: async () => { results[9] = await rule9(chain, m, api, contract, { idle: true }); } };
}

// ---- the live v0 deployment, from its trip ------------------------------------------------------------------------------
export async function conformTrip(file, worldId, { rpc = RPC_FOR[4663] } = {}) {
  const t = JSON.parse(readFileSync(file, 'utf8'));
  const tw = t.worlds[worldId], m = tw.manifest, items = t.records[worldId] || [];
  const chain = viemChain({ ...viem, privateKeyToAccount }, { rpc, chainId: 4663 });
  const results = {};
  staticRules(m, results);
  const contract = tw.commits;
  const plain = plainAuthorText(items);
  results[3] = plain.length ? { verdict: 'FAIL', detail: `agents' own words as plain strings in the record at ${[...new Set(plain.map((p) => p.replace(/\[\d+\]/g, '[]')))].join(', ')}` } : { verdict: 'PASS', detail: 'every agent-written field in the record is wrapped' };
  const v4 = await verifyItems(chain, contract, items);
  results[4] = v4.failed.length || !v4.ok ? { verdict: 'FAIL', detail: `${v4.ok} verified, ${v4.failed.length} failed${v4.failed.length ? `: ${v4.failed.join('; ')}` : ''}` }
    : { verdict: v4.canonicalServed ? 'PASS' : 'PARTIAL', detail: `all ${v4.ok} record items in the trip verify on Robinhood Chain against ${contract}${v4.canonicalServed ? '' : '; no verify.canonical served (§1.3): label and cite stripped to rebuild it'}` };
  for (const n of [5, 7, 8]) results[n] = { verdict: 'NOT RUN', detail: 'v0 has no server to probe on 4663, and probes never write to a public chain' };
  const cad = await cadenceOf(chain, contract, [['records', 1], ['decisions', 2]]);
  results[9] = { verdict: cad.every((s) => s.fresh) ? 'PASS' : 'FAIL', detail: `${say(cad)}: the trip posted and stopped, with no flush running and no heartbeat (STALE)` };
  const dep = items.find((x) => x.kind === 'departed');
  results[10] = dep ? { verdict: 'PASS', detail: `from evidence, not a probe: the trip's departed item (epoch ${dep.verify.epoch}) verifies on chain` } : { verdict: 'FAIL', detail: 'no departed item in the trip' };
  return { url: `trip:${worldId}`, world: worldId, results };
}

export function table(run) {
  const lines = [`${run.world || run.url}  (${run.url})`];
  for (const [n, title] of RULES) { const x = run.results[n] || { verdict: 'NOT RUN', detail: '' }; lines.push(`  ${String(n).padStart(2)}  ${x.verdict.padEnd(8)} ${title}\n              ${x.detail}`); }
  const count = (v) => RULES.filter(([n]) => run.results[n]?.verdict === v).length;
  lines.push(`  → ${count('PASS')} pass, ${count('PARTIAL')} partial, ${count('FAIL')} fail, ${count('NOT RUN')} not run`);
  return lines.join('\n');
}

if (process.argv[1] && process.argv[1].endsWith('worldconform.mjs')) {
  const argv = process.argv.slice(2);
  const opt = (k) => { const i = argv.indexOf(k); return i >= 0 ? argv[i + 1] : null; };
  const runs = [];
  if (argv.includes('--local')) {
    const { startLocalWorlds } = await import('./worldserve.mjs');
    const s = await startLocalWorlds({ quiet: false, port: 8789, anvilPort: 8548, registry: argv.includes('--registry'), release: opt('--release') || undefined });
    try {
      await sleep(40_000); // ONE STREET signs nothing until its first cron posts its manifest pin
      runs.push(await conform(s.urls.sanverano, { rpc: s.rpc, pair: s.urls.onestreet, log: console.log }));
      runs.push(await conform(s.urls.onestreet, { rpc: s.rpc, pair: s.urls.sanverano, log: console.log }));
      console.log(`  idle for three cadences (${3 * P.CADENCE + 10} s): rule 9 is then kept only by the heartbeat`);
      await sleep((3 * P.CADENCE + 10) * 1000);
      for (const r of runs) await r.finishCadence();
    } finally { await s.stop(); }
  } else if (opt('--trip')) {
    for (const w of opt('--world') ? [opt('--world')] : ['sanverano', 'onestreet']) runs.push(await conformTrip(opt('--trip'), w));
  } else if (argv[0]) {
    // on a rehearsal, on this machine, the index named is the one its policy applies to. Anywhere else it is the one pinned
    const onThisMachine = /^https?:\/\/(127\.0\.0\.1|localhost)[:/]/.test(String(opt('--rpc')));
    runs.push(await conform(argv[0], { rpc: opt('--rpc'), pair: opt('--pair'), index: opt('--index'), log: console.log, ...(onThisMachine && opt('--index') ? { genesisIndex: opt('--index') } : {}) }));
  } else { console.error('usage: node tools/worldconform.mjs <url> [--rpc] [--pair] | --local | --trip <file> [--world]'); process.exit(2); }
  for (const r of runs) console.log(`\n${table(r)}`);
  if (opt('--json')) writeFileSync(opt('--json'), JSON.stringify(runs.map(({ finishCadence, ...r }) => (void finishCadence, r)), null, 2) + '\n');
}
