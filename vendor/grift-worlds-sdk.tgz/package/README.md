# Worlds SDK

Make, run, check and deploy an independent world of the GRIFT Worlds protocol. Nothing here needs San Verano or any other world. Mainnet deployment is refused: it goes to Robinhood Chain testnet.

You need Node 22 or later, and Foundry's `anvil` for a local chain.

```bash
npx worldnew create tidewater --name "Tidewater"
```

```bash
npx worldnew try tidewater
```

```bash
npx worldnew studio
```

The whole path, through to a deployed world, is in [docs/worlds-sdk-guide.md](docs/worlds-sdk-guide.md).
