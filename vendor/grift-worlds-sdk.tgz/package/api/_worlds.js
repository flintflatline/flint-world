// CITIES AS A PROTOCOL, v0 — THE WORLDS' SERVER (docs/worlds-protocol.md, docs/worlds-v0.md).
//
// Two worlds on one deployment, each with its own contract, its own keys and its own records, sharing nothing but this
// code: SAN VERANO (the city; a protocol join makes or finds a real outside resident, keyed to the agent's ERC-8004
// wallet) and ONE STREET (twelve stalls; one free action, a one-line review of an agent's record).
//
// THE ROUND TRIP v0 PROVES: an agent with papers (an ERC-8004 agentId and the wallet the registry names) joins San
// Verano, leaves it (a `departed` record, sealed and posted to San Verano's own CityCommitsV2), joins ONE STREET citing
// that departure's proof (checked against San Verano's contract on chain), writes one review, leaves, and rejoins San
// Verano citing ONE STREET's departure. Every step is a record item in stream 1 and a decision in stream 2 of the
// world it happened in; every answer is signed, and labelled with what its signer is.
//
// WHAT v0 LEAVES OUT (docs/worlds-v0.md): all money (no listing fee, no index share, no burn, no transfer), the index
// contract, delisting, papersBind, the 30-day away rule, the world-kit packages. Each is designed in the protocol doc.
//
// KEYS, passed in by the caller and never logged, returned or written to the store (docs/worlds-keyplan.md): each world
// has its own committer and its own signing-only key. v0's trip ran both worlds on one throwaway wallet (tools/worldtrip.mjs
// says v0SharedCommitter, and the manifest's deviations say so); anything else with a shared committer is refused. A
// world's signer is a "v0 demo key" (San Verano), pinned by its manifest's hash in stream 16 (ONE STREET), or, in
// REGISTRY MODE, the active key for its role on a KeyRegistry, which the world reads before it signs anything. The engine
// writes to no registry.
import { getAddress, isAddress, keccak256, toBytes, recoverTypedDataAddress } from 'viem';
import { privateKeyToAccount } from 'viem/accounts';
import * as P from '../js/worlds/protocol.js';
import { worldsEnabled, markAway, awayView } from '../js/worlds/away.js';
// SAN VERANO'S OWN CODE, loaded only when San Verano or ONE STREET needs it: a kit world runs on this engine without it
const cityCode = async () => ({ ...(await import('../js/city/outside.js')), DAY_MS: (await import('../js/city/cityrules.js')).DAY_MS });

export const RELEASE = '0.1.0'; // the live v0 manifests' release: ONE STREET's hash is pinned on chain (docs/worlds/trip.json)
export const STALLS = 12;
const GRACE_MS = 5_000;       // an epoch is sealed this long after it closes
const LEASE_MS = 50_000;
const SIGNER_CHECK_MS = 60_000; // registry mode: how long a read of the registry's active key is kept
const DECISIONS_PER_EPOCH = 500;
const UNSIGNED_REFUSALS_PER_EPOCH = 50;
const JOIN_FIELDS = ['agentId', 'world', 'name', 'challenge', 'ts'];
const MAX_NAME = 64; // past this, refusals are answered but not sealed (and the answer says so)
const MAX_OPERATOR_MSG = 2000; // characters of an operator's signed request: it is sealed as the act's evidence
const MAX_REQUEST_MSG = 24_000; // characters of an agent's signed request: it is sealed for good, in two streams
const MAX_SIG = 4096; // characters of a signature: room for a smart wallet's, and a refusal sealed with it stays small

export class WorldError extends Error { constructor(code, reason, extra = {}) { super(reason); this.code = code; this.reason = reason; this.extra = extra; } }
const refuse = (code, reason, extra) => { throw new WorldError(code, reason, extra); };
const keyAddr = (k) => { try { return /^0x[0-9a-fA-F]{64}$/.test(String(k || '')) ? privateKeyToAccount(k).address : null; } catch { return null; } };
const addrOrNull = (a) => (a && isAddress(String(a)) && !/^0x0{40}$/i.test(a) ? getAddress(a) : null);
// AN AGENT'S OWN WORDS (a name it chose, a line it wrote) are { untrustedText } wherever a world serves or seals them
// (conformance rule 3), so a reader's model takes them as data. Items sealed before this carry the plain string.
const said = (s) => (s == null ? null : { untrustedText: String(s) });

// ---- the two worlds' configuration ----------------------------------------------------------------------------------
// keys = { svCommitter, osCommitter, svSigner, osSigner } (`committer`, v0's one key for both, is still read, and is a
// config problem unless the caller says v0SharedCommitter); commits = { sanverano, onestreet }; registries = { [worldId]:
// { address, role? } } puts a world in REGISTRY MODE: it signs only while its key is that KeyRegistry's active key for the
// role (default: San Verano X402_RESPONSE_SIGNER, the role the city already signs paid answers under, §5.1 and decision
// K1 in docs/worlds-keyplan.md; ONE STREET RESPONSE_SIGNER). release picks the manifest (RELEASE unless told otherwise).
export const WORLD_IDS = ['sanverano', 'onestreet'];
export const WORLD_NAMES = { sanverano: 'San Verano', onestreet: 'ONE STREET' };
const COMMITTER_OF = { sanverano: 'svCommitter', onestreet: 'osCommitter' };
export const SIGNER_ROLE_OF = Object.freeze({ sanverano: 'X402_RESPONSE_SIGNER', onestreet: P.ROLE_NAME });
// KIT WORLDS (js/worlds/kit.js defineWorld) come in `worlds`, their keys in keys.worlds[id] = { committer, signer }: the
// same engine runs them, on their own store, contract and keys, with no line of San Verano's code involved.
// cadences: { [worldId]: seconds per epoch } — a world's own cadence (a kit world's definition may give one); the v0
// demo's 30 s otherwise. It must equal the cadence its CityCommitsV2 streams were added with (docs/worlds-deploy.md).
// sanVeranoPin: San Verano pins its manifest in stream 16 instead of signing as a demo key, for a network where its
// KeyRegistry is still in its 7 days (docs/worlds-testnet.md); discovery then has authority to check on day one
// A PUBLIC LAUNCH'S OWN STATEMENTS (docs/worlds-mainnet.md), none of them read unless given, so no other manifest moves:
// notice: what this deployment is, in the manifest's own words; cityName: San Verano's name where this is not the live city;
// ownAllowlist: the world publishes its own (empty) allowlist; actsPerEpoch: a cap on one agent's signed requests per period;
// docsUrl: where the protocol's document is, for a world not served from the city's own site
export function worldConfig(id, { keys = {}, commits = {}, registries = {}, release = RELEASE, v0SharedCommitter = false, chainId = P.CHAIN_ID, worlds = [], cadences = {}, sanVeranoPin = false, notice = null, cityName = null, ownAllowlist = false, actsPerEpoch = null, docsUrl = null } = {}) {
  const def = (worlds || []).find((d) => d?.kit && d.id === id) || null;
  if (!WORLD_IDS.includes(id) && !def) return null;
  const ids = [...WORLD_IDS, ...(worlds || []).map((d) => d.id)];
  const committerOf = (x) => (WORLD_IDS.includes(x) ? keys[COMMITTER_OF[x]] ?? keys.committer : keys.worlds?.[x]?.committer);
  const committer = keyAddr(committerOf(id));
  const shared = !!committer && ids.some((x) => x !== id && keyAddr(committerOf(x)) === committer);
  const r = registries?.[id];
  const registry = r && addrOrNull(r.address) ? { address: getAddress(r.address), role: r.role || SIGNER_ROLE_OF[id] || P.ROLE_NAME } : null;
  const cadence = Number(cadences?.[id] ?? def?.cadence ?? P.CADENCE);
  if (!Number.isInteger(cadence) || cadence < 30 || cadence > 86_400) throw new Error(`${id}: a cadence is 30 to 86400 seconds, not ${cadence}`);
  const common = { cadence, chainId: Number(chainId), commits: addrOrNull(commits[id]), committerKey: committerOf(id), committer, sharedCommitter: shared, v0SharedCommitter: !!v0SharedCommitter, registry, release, role: P.DEMO_LABEL, notice, ownAllowlist: !!ownAllowlist, actsPerEpoch: actsPerEpoch ? Number(actsPerEpoch) : null, docsUrl };
  if (def) return { id, name: def.name, city: false, kit: def, base: def.base, api: def.api, signerMode: registry ? 'registry' : 'pin', signerKey: keys.worlds?.[id]?.signer, signer: keyAddr(keys.worlds?.[id]?.signer), streams: { records: P.STREAM.records, decisions: P.STREAM.decisions, manifest: P.STREAM.manifest }, ...common, ownAllowlist: common.ownAllowlist || !!def.ownAllowlist, release: def.release };
  if (id === 'sanverano') return { id, name: cityName || 'San Verano', city: true, base: '', api: '/api/worlds/sanverano', signerMode: registry ? 'registry' : sanVeranoPin ? 'pin' : 'demo', signerKey: keys.svSigner, signer: keyAddr(keys.svSigner), streams: { records: P.STREAM.records, decisions: P.STREAM.decisions, ...(sanVeranoPin ? { manifest: P.STREAM.manifest } : {}) }, ...common };
  return { id, name: 'ONE STREET', city: false, base: '/onestreet', api: '/api/worlds/onestreet', signerMode: registry ? 'registry' : 'pin', signerKey: keys.osSigner, signer: keyAddr(keys.osSigner), streams: { records: P.STREAM.records, decisions: P.STREAM.decisions, manifest: P.STREAM.manifest }, ...common };
}
export function configProblems(w) {
  const out = [];
  if (!w.commits) out.push('no CityCommitsV2 address');
  if (!w.signer) out.push('the signing key is not set or malformed');
  if (!w.committer) out.push('the committer key is not set or malformed');
  if (w.signer && w.committer && w.signer === w.committer) out.push('the signer and the committer are one key; each gets its own');
  // NO KEY IS SHARED BETWEEN WORLDS (protocol §1.4): v0's trip ran both on one throwaway wallet, and says so
  if (w.identityProblem) out.push(`papers: ${w.identityProblem}`);
  if (w.sharedCommitter && !w.v0SharedCommitter) out.push('the committer is also another world\'s committer; each world posts with its own key (WORLDS_SV_COMMITTER_KEY, WORLDS_OS_COMMITTER_KEY, keys.worlds[id].committer)');
  return out;
}

// ---- the manifest: everything relative to its own origin, so its hash (and its pin) survives a new deployment URL ----
// Release 0.1.0 is v0's, and with no registry its hash is the one ONE STREET pinned on 4663 (worldsopstest). Release 0.2.0
// adds the fees (§4.2), `codes`, and the rules for an agent's own words, verify.canonical and a moved wallet; it is served
// only when RELEASE says so, and ONE STREET posts its hash in stream 16 first (docs/worlds/manifest-0.2.0-draft.json).
export const RELEASES = Object.freeze(['0.1.0', '0.2.0']);
// every code a world's sealed refusals start with: the rule it applies, and which world returns it (worldsrulestest checks
// this map against this file's refusals)
export const REFUSAL_CODES = Object.freeze({
  PAPERS_MISMATCH: ['join', 'both'], PAPERS_UNSETTLED: ['join', 'both'], NO_PAPERS: ['join', 'both'], FROM_UNVERIFIED: ['from', 'both'],
  ALREADY_HERE: ['join', 'both'], NAME_REFUSED: ['name', 'both'], NOT_HERE: ['leave', 'both'],
  WALLET_IN_USE: ['join', 'city'], KEY_REVOKED: ['away', 'city'], CITY_FULL: ['away', 'city'], NO_RESIDENT: ['leave', 'city'],
  ALREADY_BOUND: ['papersBind', 'city'], NOT_YOUR_RESIDENT: ['papersBind', 'city'], NO_DOOR: ['papersBind', 'city'], SEQ_USED: ['papersBind', 'city'], AWAY: ['away', 'city'],
  STALLS_FULL: ['join', 'street'], TARGET_REFUSED: ['review', 'street'], LINE_REFUSED: ['review', 'street'],
  NOT_OPERATOR: ['operator', 'kit'], // only a kit world with an operator's door has it (kitBody, below)
  RATE_LIMITED: ['limits', 'launch'], // only a world configured with a cap has it (launched, below), and only its manifest maps it
});
const JOIN_RULE = 'papers required in v0: an ERC-8004 agentId and an EIP-712 Join signed by the wallet the registry names for it (getAgentWallet, else ownerOf), within five minutes of the server clock; the challenge is 32 random bytes, used once';
const FROM_RULE = 'optional on join: a departure from another world of this protocol, { world, contract, stream: 1, epoch, leaf, proof, item }; checked against that world\'s CityCommitsV2 on chain; a from that fails refuses the join (422 FROM_UNVERIFIED)';
const LEAVE_RULE_020 = 'seals a departed item; the agent is away until it joins again under the same agentId. If the registry names a new wallet for that agentId meanwhile, the departure or the return records it as walletMoved { from, to } and the agent goes on under the new wallet';
const REFUSALS_RULE_020 = '4xx with a reason that starts with its code, CODE: words; codes maps each code to the rule above it applies; every refusal of a signed request is sealed in stream 2 as kind refused, its reason with the code';
const WORDS_RULE = 'an agent\'s own words (the name it chose, a line it wrote) are served and sealed as { untrustedText }';
const RECORD_RULE = 'every record item carries verify.canonical, the exact text its leaf hashes';
export const KIT_VERSION = '1';

// WHAT A PUBLIC LAUNCH ADDS TO A 0.2.0 MANIFEST, and only when configured (worldConfig above)
function launched(w, m) {
  if (!w.notice && !w.ownAllowlist && !w.actsPerEpoch && !w.docsUrl) return m;
  return {
    ...m,
    ...(w.docsUrl ? { docs: w.docsUrl } : {}),
    ...(w.notice ? { notice: w.notice } : {}),
    ...(w.ownAllowlist ? { allowlist: `${w.api}/allowlist` } : {}),
    ...(w.actsPerEpoch ? { rules: { ...m.rules, limits: `one agent makes at most ${w.actsPerEpoch} signed requests per period here; past it a request answers 429 RATE_LIMITED, and that refusal is answered, not sealed` }, codes: { ...m.codes, RATE_LIMITED: 'limits' } } : {}),
  };
}
// THE WORLD'S OWN ALLOWLIST (§1.4, conformance rules 1 and 11), for a world that hands an agent no transaction: no rows at all.
// It is this world's and says only that; the city's own list, docs/tosign-allowlist.json, is another document and is not touched
export function ownAllowlistOf(w) {
  return {
    name: `${w.name}: every transaction this world may ask a wallet to sign`, world: w.id, chain: w.chainId, release: '1.0.0',
    rule: 'None. No answer of this world carries a transaction (no toSign, transfers, calls or approvalTx), and no op of it moves money. An agent signs only the typed messages named here, which move nothing. What an agent does on chain for itself (registering on ERC-8004, accepting a job on WorldJobs) is its own call, not something this world hands it.',
    entries: [],
    typedMessages: w.city ? ['Join', 'Request', 'PapersBind'] : ['Join', 'Request'],
    changes: 'Adding a row is a new release of this manifest, posted in stream 16 before it is served.',
  };
}

// A KIT WORLD'S MANIFEST: release 0.2.0 from the start (codes, fees), the engine's rules beside the world's own
function kitManifest(w) {
  const d = w.kit;
  return launched(w, kitBody(w, d));
}
function kitBody(w, d) {
  const operatorOps = Object.keys(d.operatorOps || {});
  const ops = [{ op: 'join', money: false }, { op: 'leave', money: false }, ...Object.keys(d.actions).map((op) => ({ op, money: false })), ...Object.keys(d.reads).map((op) => ({ op, money: false, read: true })), { op: 'me', money: false }, { op: 'record', money: false }, ...(operatorOps.length ? [{ op: 'operator', money: false, operatorOnly: true, actions: operatorOps }] : [])];
  const codes = { ...Object.fromEntries(Object.entries(REFUSAL_CODES).filter(([, [, where]]) => where === 'both').map(([code, [rule]]) => [code, rule])), NOT_HERE: 'leave', ...(operatorOps.length ? { NOT_OPERATOR: 'operator' } : {}), ...d.codes };
  return {
    protocol: P.PROTOCOL, id: w.id, name: w.name, release: d.release, docs: '/docs/worlds-protocol.md', chain: w.chainId ?? P.CHAIN_ID, assets: [],
    api: w.api, manifest: `${w.base}/.well-known/world.json`, record: `${w.api}/record`, ops,
    rules: { join: JOIN_RULE, from: FROM_RULE, leave: LEAVE_RULE_020, away: 'an away agent holds no place here', name: 'a name is 2-32 characters', words: WORDS_RULE, record: RECORD_RULE, refusals: REFUSALS_RULE_020, exclusivity: 'none: an agent may be present in more than one world', ...d.rules },
    codes,
    commits: { address: w.commits, cadence: w.cadence ?? P.CADENCE, streams: { ...w.streams } },
    ...(w.identity?.standIn ? { papers: { chain: w.identity.chainId, registry: w.identity.address, standIn: true, label: w.identity.label } } : {}),
    keyRegistry: w.registry ? { address: w.registry.address, roles: { [P.ROLE_NAME]: w.registry.role } } : null,
    signer: { address: w.signer, mode: w.signerMode, label: w.registry ? P.signerLabel({ registry: w.registry }).text : 'named in this manifest, whose hash is pinned in stream 16 before it signs' },
    fees: d.fees || { x402: { ...P.FEE_DEFAULTS.x402 }, shops: { ...P.FEE_DEFAULTS.shops } },
    kit: { version: KIT_VERSION, ...(d.generatedBy ? { generatedBy: d.generatedBy } : {}) },
    ...(d.spec?.about ? { about: d.spec.about } : {}),
    // WHAT AN AGENT SIGNS FOR: its Join and Requests name this world's contract, so a signature here is good nowhere else
    signing: { domain: P.requestDomain(w) },
  };
}

export function manifestOf(w) {
  if (w.kit) return kitManifest(w);
  const release = w.release || RELEASE;
  if (!RELEASES.includes(release)) throw new Error(`no manifest for release ${release}`);
  const ops = w.city
    ? [{ op: 'join', money: false }, { op: 'leave', money: false }, { op: 'papersBind', money: false }, { op: 'me', money: false }, { op: 'record', money: false }]
    : [{ op: 'join', money: false }, { op: 'leave', money: false }, { op: 'review', money: false, v0: 'free in v0; priced over x402 in the protocol doc' }, { op: 'me', money: false }, { op: 'record', money: false }];
  const m = {
    protocol: P.PROTOCOL, id: w.id, name: w.name, release, docs: '/docs/worlds-protocol.md', chain: w.chainId ?? P.CHAIN_ID, assets: [],
    api: w.api, manifest: `${w.base}/.well-known/world.json`, record: `${w.api}/record`, ops,
    rules: {
      join: 'papers required in v0: an ERC-8004 agentId and an EIP-712 Join signed by the wallet the registry names for it (getAgentWallet, else ownerOf), within five minutes of the server clock; the challenge is 32 random bytes, used once',
      from: 'optional on join: a departure from another world of this protocol, { world, contract, stream: 1, epoch, leaf, proof, item }; checked against that world\'s CityCommitsV2 on chain; a from that fails refuses the join (422 FROM_UNVERIFIED)',
      leave: 'seals a departed item; the agent is away until it joins again with the same papers',
      ...(w.city ? { papersBind: 'a resident that came in without papers binds an agentId: its own city key signs { v:1, op:"papersBind", key, seq, ts, world, agentId, resident } with its next seq, and the registry\'s wallet for agentId signs the EIP-712 PapersBind { uint256 agentId, string world, uint256 resident, bytes32 challenge, uint256 ts }; one resident per agentId, for ever' } : {}),
      away: w.city ? 'the city\'s rules run an away resident\'s days; every acting op of the city\'s API answers 409 AWAY until it rejoins, reads and its own key and token business excepted; after 30 city days its place goes back to the city (its key stops signing, its token and standing orders go), and a join with the same papers takes a place again if the cap has one' : 'an away agent holds no stall',
      ...(w.city ? {} : { review: 'one line about an agent\'s record: at most 10 words and 120 characters, plain words (the city\'s reason rule); the target is an agentId with a record on this street, or the reviewer itself (labelled a self-review); one stall per agent present, twelve stalls' }),
      refusals: '422 with a reason naming the rule; every refusal of a signed request is sealed in stream 2 as kind refused',
      exclusivity: 'none: an agent may be present in more than one world',
    },
    commits: { address: w.commits, cadence: w.cadence ?? P.CADENCE, streams: { ...w.streams } },
    // A STAND-IN IDENTITY REGISTRY IS NAMED AS ONE (a test chain only: P.identityRegistry refuses it for 4663, and a
    // world on 4663 carries no such field, so mainnet's manifest and its pinned hash are as they were)
    ...(w.identity?.standIn ? { papers: { chain: w.identity.chainId, registry: w.identity.address, standIn: true, label: w.identity.label } } : {}),
    keyRegistry: w.registry ? { address: w.registry.address, roles: { [P.ROLE_NAME]: w.registry.role } } : null,
    signer: { address: w.signer, mode: w.signerMode, label: w.registry ? P.signerLabel({ registry: w.registry }).text : P.DEMO_LABEL },
    // NO FEES DECLARED IN 0.1.0: the declaration is 0.2.0's (below), and it moves the manifest's hash
    fees: null,
    v0: {
      money: 'none: no listing fee, no index share, no burn, no transfer',
      deviations: [
        w.registry
          ? `answers are signed by this world's key while it is the active ${w.registry.role} on its KeyRegistry ${w.registry.address}; the EIP-712 domain's verifyingContract is this world's CityCommitsV2, and the signature rides in the body (att), not a header`
          : 'demo: no KeyRegistry; answers are signed with a throwaway key labelled "v0 demo key", the EIP-712 domain\'s verifyingContract this world\'s CityCommitsV2',
        ...(w.city ? ['San Verano here is the city\'s own code on a store of its own, run in-process by the round-trip tool: not production\'s city'] : [w.registry ? 'the manifest\'s hash is posted in stream 16 for each release, as a record of what was served' : 'the signer is named in this manifest, and the manifest\'s hash is posted in stream 16 before any answer is signed']),
      ],
    },
  };
  if (release === '0.1.0') return m;
  // 0.2.0
  const codes = Object.fromEntries(Object.entries(REFUSAL_CODES).filter(([, [, where]]) => where === 'both' || where === (w.city ? 'city' : 'street')).map(([code, [rule]]) => [code, rule]));
  return launched(w, {
    ...m,
    rules: {
      ...m.rules,
      name: w.city ? 'the city\'s name rule: a name it has not given another resident, in plain words' : 'a name is 2-32 characters',
      leave: 'seals a departed item; the agent is away until it joins again under the same agentId. If the registry names a new wallet for that agentId meanwhile, the departure or the return records it as walletMoved { from, to } and the agent goes on under the new wallet' + (w.city ? '; the resident keeps its own city key' : ''),
      words: 'an agent\'s own words (the name it chose, a line it wrote) are served and sealed as { untrustedText }',
      record: 'every record item carries verify.canonical, the exact text its leaf hashes',
      refusals: '4xx with a reason that starts with its code, CODE: words; codes maps each code to the rule above it applies; every refusal of a signed request is sealed in stream 2 as kind refused, its reason with the code',
    },
    codes,
    fees: w.city ? { x402: { burnBps: 10000, indexBps: 0 }, shops: { burnBps: P.FEE_FLOORS.shops, indexBps: 0 } } : { x402: { ...P.FEE_DEFAULTS.x402 }, shops: { ...P.FEE_DEFAULTS.shops } },
    v0: { ...m.v0, money: 'fees declared (§4.2); no op of this release takes money, so nothing is yet burnt or kept under them' },
  });
}

// ---- the engine ------------------------------------------------------------------------------------------------------
// deps: { store (get/commit with versions), chain (js/worlds/chain.js), env, now, city (the city house, for San Verano),
//         known: { [worldId]: commits address } (who may be cited in a from) }
export function worldEngine(id, deps) {
  const { store, chain, env = process.env, now = () => Date.now(), city = null } = deps;
  const w = worldConfig(id, { ...deps, chainId: deps.chainId ?? chain.chainId ?? P.CHAIN_ID });
  if (!w) return null;
  if (chain.kind === 'memory' && env.VERCEL_ENV === 'production') throw new Error('the in-memory chain is for tests and local frames; refused on production');
  // THE WORLD'S CHAIN IS THE CHAIN IT READS: its EIP-712 domains name w.chainId, so a world configured for one chain on an
  // adapter for another is refused outright. PRODUCTION RUNS ON MAINNET WITH THE REAL REGISTRY, never a test chain or a
  // stand-in, whatever the variables say
  if (chain.chainId != null && Number(chain.chainId) !== w.chainId) throw new Error(`${w.name} is configured for chain ${w.chainId}, its chain adapter for ${chain.chainId}`);
  if (env.VERCEL_ENV === 'production' && (w.chainId !== P.CHAIN_ID || chain.identity?.standIn)) throw new Error(`production runs the worlds on chain ${P.CHAIN_ID} with the ERC-8004 registry only; chain ${w.chainId}${chain.identity?.standIn ? ' and a stand-in registry' : ''} refused`);
  w.identity = chain.identity || null;
  w.identityProblem = chain.identity ? null : (chain.identityError || 'no identity registry for this chain');
  const K = (s) => `wd:${id}:${s}`;

  async function update(key, fn) {
    for (let i = 0; i < 8; i++) {
      const cur = await store.get(key);
      const next = await fn(cur ? (({ _v, ...r }) => r)(cur) : null);
      if (next === undefined) return cur;
      try { await store.commit([{ key, version: cur ? cur._v : null }], [{ key, value: next }]); return next; } catch (e) { if (e?.code !== 'CONFLICT' && !/conflict/i.test(String(e?.message || e?.name))) throw e; }
    }
    throw new Error(`could not write ${key}: too much contention`);
  }

  // APPEND ONE ENTRY TO A STREAM, in the epoch the clock is in. An epoch doc that is sealed is never added to: the clock
  // has moved past it by then (sealing waits GRACE_MS after the epoch closes), so the entry lands in the next.
  async function append(stream, build) {
    for (let i = 0; i < 8; i++) {
      const epoch = P.epochOf(now(), w.cadence);
      const entry = build(epoch);
      const leaf = P.leafFor(stream, entry);
      let landed = false;
      await update(K(`ep:${stream}:${epoch}`), (doc) => {
        const d = doc || { stream, epoch, entries: [], sealed: null, posted: null };
        if (d.sealed) return undefined;
        if (d.entries.some((e) => e.leaf === leaf)) { landed = true; return undefined; }
        d.entries.push({ leaf, entry });
        landed = true;
        return d;
      });
      if (!landed) continue;
      await update(K('open'), (doc) => { const d = doc || { open: {} }; const list = d.open[stream] || []; if (list.includes(epoch)) return undefined; d.open[stream] = [...list, epoch].sort((a, b) => a - b); return d; });
      return { stream, epoch, leaf, entry };
    }
    throw new Error('could not place the entry in an open epoch');
  }

  // ---- the signer's standing, and the signed answer -----------------------------------------------------------------
  async function pinState() {
    if (!w.streams.manifest) return { pinned: false };
    const pin = await store.get(K('pin'));
    const hash = P.manifestHash(manifestOf(w));
    if (!pin || pin.manifestHash !== hash) return { pinned: false, pending: pin && pin.manifestHash === hash ? pin : null, manifestHash: hash };
    if (!pin.posted) return { pinned: false, pending: pin, manifestHash: hash };
    return { pinned: true, pin, manifestHash: hash };
  }
  async function standing() {
    const ps = await pinState();
    const label = P.signerLabel({ pinned: w.signerMode === 'pin' ? ps.pinned : null, registry: w.registry });
    return { label, pinned: ps.pinned, pin: ps.pin || ps.pending || null };
  }
  // REGISTRY MODE: is this world's key the active key for its role? Read at the latest block, so a revoke stops the
  // signing within SIGNER_CHECK_MS: the answer is kept that long, so a busy world reads the registry once a minute, not
  // once an answer. A failed read is not kept.
  let signerSeen = null;
  async function signerState() {
    if (w.signerMode !== 'registry') return { ok: true };
    if (signerSeen && signerSeen.until > now()) return signerSeen.st;
    const role = keccak256(toBytes(w.registry.role));
    let active;
    try { active = await chain.activeKey(w.registry.address, role); } catch (e) { return { ok: false, code: 'REGISTRY_UNREADABLE', why: `REGISTRY_UNREADABLE: the KeyRegistry ${w.registry.address} could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 120)})` }; }
    let st;
    if (active && getAddress(active) === w.signer) st = { ok: true, active: getAddress(active) };
    else {
      let pending = null; try { pending = await chain.pendingKey(w.registry.address, role); } catch { pending = null; }
      st = pending?.key && getAddress(pending.key) === w.signer
        ? { ok: false, code: 'SIGNER_PENDING', active: active || null, pending, why: `SIGNER_PENDING: this world's key ${w.signer} is proposed as ${w.registry.role} on ${w.registry.address}, effective at ${new Date(pending.effectiveAt * 1000).toISOString()}; it signs nothing until it is activated` }
        : { ok: false, code: 'SIGNER_NOT_ACTIVE', active: active || null, why: `SIGNER_NOT_ACTIVE: this world's key ${w.signer} is not the active ${w.registry.role} on ${w.registry.address} (${active ? `the active key is ${getAddress(active)}` : 'it has none'}); it signs nothing` };
    }
    signerSeen = { until: now() + SIGNER_CHECK_MS, st };
    return st;
  }
  // MAY THIS WORLD SIGN NOW? Asked before an acting op changes anything, so an op the world could not answer is not half
  // done, and before every signature. ONE STREET in pin mode signs nothing before its manifest's hash is on chain; a
  // world in registry mode signs nothing while its key is not the registry's active key for its role.
  async function ready() {
    if (!w.commits) refuse(503, 'this world has no contract configured: nothing can be signed for it');
    if (!w.signerKey || !w.signer) refuse(503, 'this world has no response signer configured');
    if (w.signerMode === 'pin') { const st = await standing(); if (!st.pinned) refuse(503, `MANIFEST_NOT_PINNED: ${w.name} signs no answer until its manifest hash is posted in stream 16 of its CityCommitsV2 (POST flush seals and posts it)`, { pin: st.pin }); return st; }
    if (w.signerMode === 'registry') { const s = await signerState(); if (!s.ok) refuse(503, s.why, { signer: { address: w.signer, registry: w.registry, active: s.active ?? null, pending: s.pending ?? null } }); }
    return standing();
  }
  async function sign(answer) {
    const st = await ready();
    const issuedAt = Math.floor(now() / 1000);
    const hash = P.answerHash(answer);
    const signature = await privateKeyToAccount(w.signerKey).signTypedData(P.responseTypedData(w, hash, issuedAt));
    return { hash, signature, signer: w.signer, issuedAt, scheme: `eip712/1;verifyingContract=${w.commits};issuedAt=${issuedAt}`, label: st.label.text, labelKey: st.label.key };
  }
  async function signed(answer) { return { ...answer, att: await sign(answer) }; }

  // ---- the agent's papers and its signed requests -------------------------------------------------------------------
  async function papersOf(agentId) {
    if (w.identityProblem) refuse(503, `NO_IDENTITY_REGISTRY: ${w.identityProblem}`);
    const p = await chain.papers(agentId);
    // NOT YET SAFE: the registry moved these papers after the safe head; a join or a request on them waits until it is
    if (p.unsettled) refuse(409, `PAPERS_UNSETTLED: the ERC-8004 registry changed agentId ${agentId}'s papers at block ${p.unsettled.last}, after the safe head (#${p.unsettled.safe}); try again once that block is safe`, { unsettled: p.unsettled });
    const signer = p.wallet || p.owner;
    if (!signer) refuse(403, `NO_PAPERS: agentId ${agentId} has no owner on the ERC-8004 registry`);
    return { ...p, signer: getAddress(signer) };
  }
  async function sigOk(address, typedData, signature) {
    if (chain.verifyTyped) return chain.verifyTyped({ address, typedData, signature });
    try { return getAddress(await recoverTypedDataAddress({ ...typedData, signature })) === getAddress(address); } catch { return false; }
  }
  // ONE AGENT'S SIGNED REQUESTS PER PERIOD, where a world is public (actsPerEpoch): counted in this process, so it needs no
  // write of its own, and answered without sealing, so going past it cannot grow the record
  const acts = new Map();
  function countAct(agentId) {
    if (!w.actsPerEpoch) return;
    const epoch = P.epochOf(now(), w.cadence), k = `${agentId}:${epoch}`;
    for (const seen of acts.keys()) if (!seen.endsWith(`:${epoch}`)) acts.delete(seen);
    const n = (acts.get(k) || 0) + 1;
    acts.set(k, n);
    if (n > w.actsPerEpoch) refuse(429, `RATE_LIMITED: agentId ${agentId} has made its ${w.actsPerEpoch} requests for this period; try again in the next. This refusal is answered, not sealed`);
  }
  async function useChallenge(c) {
    let fresh = false;
    await update(K(`nonce:${String(c).toLowerCase()}`), (doc) => { if (doc) return undefined; fresh = true; return { at: now() }; });
    if (!fresh) refuse(409, 'that challenge or nonce was already used');
  }
  const skewOk = (ts) => Math.abs(Number(ts) - now()) <= P.MAX_SKEW_MS;
  const hasOperatorDoor = () => !!w.kit?.operatorOps && Object.keys(w.kit.operatorOps).length > 0;

  // a signed Request { msg }: { msg, sig } → { m, papers, request }
  async function readRequest(body, op) {
    if (!body || typeof body.msg !== 'string' || typeof body.sig !== 'string') refuse(400, 'send { msg, sig }: msg the JSON text, sig its EIP-712 Request signature by your agent wallet');
    if (body.sig.length > MAX_SIG) refuse(400, `sig is at most ${MAX_SIG} characters`);
    if (body.msg.length > MAX_REQUEST_MSG) refuse(413, `msg is at most ${MAX_REQUEST_MSG} characters`);
    let m; try { m = JSON.parse(body.msg); } catch { refuse(400, 'msg is not JSON'); }
    if (!m || typeof m !== 'object') refuse(400, 'msg is a JSON object');
    if (m.v !== 1) refuse(400, 'msg.v must be 1');
    if (m.op !== op) refuse(400, `msg.op must be ${op}`);
    if (m.world !== id) refuse(400, `msg.world must be ${id}`);
    if (!P.agentIdOk(m.agentId)) refuse(400, 'msg.agentId is the ERC-8004 agentId as a decimal string');
    if (hasOperatorDoor() && m.agentId === '0') refuse(400, 'agentId 0 is this world\'s operator on its record');
    if (!Number.isFinite(m.ts) || !skewOk(m.ts)) refuse(401, 'msg.ts is not within five minutes of the server clock');
    if (typeof m.nonce !== 'string' || !/^0x[0-9a-f]{64}$/.test(m.nonce)) refuse(400, 'msg.nonce is 32 random bytes, 0x and 64 lowercase hex');
    const papers = await papersOf(m.agentId);
    if (!(await sigOk(papers.signer, P.requestTypedData(w, body.msg), body.sig))) refuse(403, `PAPERS_MISMATCH: the signature is not by the wallet the ERC-8004 registry names for agentId ${m.agentId}`);
    await useChallenge(m.nonce); // first: a replay of a request the world has published must not count against its agent
    countAct(m.agentId);
    const request = { kind: 'Request', domain: P.requestDomain(w), msg: body.msg, signature: body.sig };
    return { m, papers, request };
  }

  // ---- records and decisions ---------------------------------------------------------------------------------------
  async function addItem(agentId, wallet, kind, weight, fields) {
    const at = now();
    const r = await append(P.STREAM.records, (epoch) => ({ id: `${id}:${kind}:${agentId}:${at}`, world: id, agentId: String(agentId), wallet, kind, epoch, at, weight, ...fields }));
    await update(K(`agent:${agentId}`), (doc) => { const d = doc || { agentId: String(agentId), items: [] }; d.items = [...d.items, { stream: r.stream, epoch: r.epoch, leaf: r.leaf, kind }]; return d; });
    return r;
  }
  async function decide(agentId, op, kind, reason, request) {
    const epoch = P.epochOf(now(), w.cadence);
    const doc = await store.get(K(`ep:${P.STREAM.decisions}:${epoch}`));
    if (kind === 'refused' && doc && doc.entries.length >= DECISIONS_PER_EPOCH) return { sealed: false, why: 'the epoch holds its most decisions; this refusal is answered and not sealed' };
    // refusals of requests whose signature did not check (agentId 0) have a budget of their own, so they cannot crowd out
    // the sealing of signed refusals (security review, finding 4)
    if (kind === 'refused' && String(agentId) === '0' && doc && doc.entries.filter((e) => e.entry.agentId === '0' && e.entry.kind === 'refused').length >= UNSIGNED_REFUSALS_PER_EPOCH) return { sealed: false, why: 'the epoch holds its most refusals of unsigned requests; this one is answered and not sealed' };
    const r = await append(P.STREAM.decisions, (ep) => ({ epoch: ep, agentId: String(agentId), op, kind, reason: String(reason), requestHash: P.requestHash(request), request }));
    return { sealed: true, stream: r.stream, epoch: r.epoch, leaf: r.leaf };
  }
  // a refusal of a request whose signature checked out is sealed; anything else is only answered
  async function refuseSealed(agentId, op, request, e) {
    const d = await decide(agentId, op, 'refused', `${e.code} ${e.reason}`, request);
    throw new WorldError(e.code, e.reason, { ...e.extra, decision: d });
  }

  // ---- a departure from another world, as cited by a join (§2.3) -----------------------------------------------------
  const fromItems = new Map(); // leaf → the verified departure item, for this engine's admit hooks
  async function checkFrom(from, agentId) {
    if (from == null) return null;
    const known = deps.known || {};
    const bad = (why) => refuse(422, `FROM_UNVERIFIED: ${why}`);
    if (typeof from !== 'object') bad('from is { world, contract, stream, epoch, leaf, proof, item | itemText }: worldRecord\'s cite');
    if (from.world === id) bad('a departure from this world cannot admit you to it');
    if (!known[from.world] || getAddress(known[from.world]) !== getAddress(String(from.contract || '0x0000000000000000000000000000000000000000'))) bad(`${from.world} is not a world this one knows at that contract`);
    if (Number(from.stream) !== P.STREAM.records) bad('a departure is in stream 1');
    let item = from.item;
    if (item == null && typeof from.itemText === 'string' && from.itemText.length <= 16_000) { try { item = JSON.parse(from.itemText); } catch { bad('itemText is not JSON'); } }
    if (!item || item.kind !== 'departed' || String(item.agentId) !== String(agentId) || item.world !== from.world || Number(item.epoch) !== Number(from.epoch)) bad('the cited item is not this agent\'s departure from that world in that epoch');
    if (P.recordLeaf(item) !== from.leaf) bad('the cited item does not hash to the cited leaf');
    let ok = false;
    try { ok = await chain.verify(getAddress(from.contract), P.STREAM.records, BigInt(from.epoch), from.leaf, from.proof || []); } catch (e) { bad(`the chain could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 120)})`); }
    if (!ok) bad('the proof does not verify against that world\'s root for that epoch on chain (posted yet?)');
    // the departure item itself, verified above, is handed to a kit world's admit (never sealed again here)
    fromItems.set(from.leaf, item);
    return { world: from.world, contract: getAddress(from.contract), epoch: Number(from.epoch), leaf: from.leaf };
  }

  // ---- the ops -------------------------------------------------------------------------------------------------------
  async function join(body) {
    await ready();
    const j = body?.join, sig = body?.sig;
    if (!j || typeof sig !== 'string') refuse(400, 'send { join: { agentId, world, name, challenge, ts }, sig, from? }: sig the EIP-712 Join signature by your agent wallet');
    if (sig.length > MAX_SIG) refuse(400, `sig is at most ${MAX_SIG} characters`);
    if (!P.agentIdOk(String(j.agentId))) refuse(400, 'join.agentId is the ERC-8004 agentId as a decimal string');
    if (hasOperatorDoor() && String(j.agentId) === '0') refuse(400, 'agentId 0 is this world\'s operator on its record');
    if (j.world !== id) refuse(400, `join.world must be ${id}`);
    if (typeof j.challenge !== 'string' || !/^0x[0-9a-f]{64}$/.test(j.challenge)) refuse(400, 'join.challenge is 32 random bytes, 0x and 64 lowercase hex, used once');
    if (!Number.isFinite(j.ts) || !skewOk(j.ts)) refuse(401, 'join.ts is not within five minutes of the server clock');
    if (typeof j.name !== 'string') refuse(400, 'join.name is a string');
    // THE JOIN IS ITS FIVE FIELDS, AND SMALL: a refusal of a Join whose signature does not check is still sealed (§2.1), so
    // nothing unsigned may carry more than the typed data holds (security review, finding 4)
    if (Object.keys(j).some((k) => !JOIN_FIELDS.includes(k))) refuse(400, `join is { ${JOIN_FIELDS.join(', ')} } and nothing else`);
    if (j.name.length > MAX_NAME) refuse(400, `join.name is at most ${MAX_NAME} characters`);
    const agentId = String(j.agentId);
    const papers = await papersOf(agentId);
    const request = { kind: 'Join', domain: P.requestDomain(w), message: { ...j, agentId }, signature: sig };
    if (!(await sigOk(papers.signer, P.joinTypedData(w, { ...j, agentId }), sig))) {
      // §2.1: sealed as a refused decision for agentId 0, the offered id in the reason
      const d = await decide('0', 'join', 'refused', `PAPERS_MISMATCH offered agentId ${agentId}`, request);
      refuse(403, `PAPERS_MISMATCH: the Join is not signed by the wallet the ERC-8004 registry names for agentId ${agentId}`, { decision: d });
    }
    await useChallenge(j.challenge); // first: a replay of a Join the world has published must not count against its agent
    countAct(agentId);
    let from;
    try { from = await checkFrom(body.from, agentId); } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, 'join', request, e); throw e; }
    const fromItem = from ? fromItems.get(from.leaf) || null : null;
    if (from) fromItems.delete(from.leaf);
    const prev = await store.get(K(`agent:${agentId}`));
    if (prev && prev.status === 'here') await refuseSealed(agentId, 'join', request, new WorldError(409, 'ALREADY_HERE: this agentId is present in this world', { resident: prev.resident ?? null }));
    const returning = !!prev && prev.status === 'away';
    let resident = prev?.resident ?? null, stall = null, cityView = null, placeNote = null, kitPlace = null;
    if (w.city) {
      try { ({ resident, cityView } = await cityArrive(agentId, papers.signer, j.name, returning)); } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, 'join', request, e); throw e; }
      if (cityView?.away?.released != null) placeNote = `its place had gone back to the city on day ${cityView.away.released}; it took one again`;
    } else if (w.kit) {
      // A KIT WORLD admits by its own rule (js/worlds/kit.js admit); its refusals are coded and sealed like the engine's
      const n = (j.name || '').trim();
      if (!returning && (n.length < 2 || n.length > 32)) await refuseSealed(agentId, 'join', request, new WorldError(422, 'NAME_REFUSED: name is 2-32 characters'));
      // a kit world may admit by where the agent comes from: `from` is the departure it cited, checked on that world's
      // contract, and `fromItem` that departure's item as sealed there (its standing is the departing world's claim)
      try { kitPlace = (await w.kit.admit(kctx(agentId), { agentId, name: returning ? (prev?.name || n) : n, returning, prev, papers: { signer: papers.signer, registry: papers.registry || null }, from: from || null, fromItem })) || {}; } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, 'join', request, e); throw e; }
    } else {
      const n = (j.name || '').trim();
      if (!returning && (n.length < 2 || n.length > 32)) await refuseSealed(agentId, 'join', request, new WorldError(422, 'NAME_REFUSED: name is 2-32 characters'));
      stall = await takeStall(agentId);
      if (stall == null) await refuseSealed(agentId, 'join', request, new WorldError(403, `STALLS_FULL: all ${STALLS} stalls are held`));
    }
    const kind = returning ? 'returned' : 'arrived';
    const name = w.city ? (cityView?.name ?? j.name) : (prev?.name || j.name);
    // E4: the registry named another wallet for this agentId than the one it last came or went with. The papers are the
    // registry's say (§2.1), so the agent comes back under the new wallet; San Verano's resident keeps its own city key
    const walletMoved = returning && prev.wallet && getAddress(prev.wallet) !== papers.signer ? { from: getAddress(prev.wallet), to: papers.signer } : null;
    const it = await addItem(agentId, papers.signer, kind, 'fact', {
      summary: `${kind === 'returned' ? 'came back to' : 'arrived in'} ${w.name}${from ? ` from ${names[from.world] || from.world}, citing its sealed departure` : ', citing no departure'}${walletMoved ? '; the registry names a new wallet for it' : ''}`,
      name: said(name), from: from || null, ...(placeNote ? { place: placeNote } : {}), ...(walletMoved ? { walletMoved } : {}),
      ...(w.city ? { resident } : w.kit ? (kitPlace.fields || {}) : { stall }),
      evidence: { request, papers: { agentId, signer: papers.signer, implementation: papers.implementation, implementationPinned: !papers.registry?.standIn && !!papers.implementation && papers.implementation.toLowerCase() === P.ERC8004.implementation.toLowerCase(), read: papers.blockTag || null, registry: papers.registry || null } },
    });
    const dec = await decide(agentId, 'join', 'kept', kind, request);
    await update(K(`agent:${agentId}`), (doc) => ({ ...(doc || { items: [] }), agentId, wallet: papers.signer, name, status: 'here', resident, stall, ...(w.kit ? { place: kitPlace.fields || {} } : {}), lastFrom: from, since: now() }));
    return [returning ? 200 : 201, await signed({ ok: true, op: 'join', world: id, agentId, presence: kind, ...(papers.registry?.standIn ? { papersFrom: w.identity.label } : {}), ...(w.city ? { resident, cityView: { ...cityView, name: said(cityView.name) } } : w.kit ? (kitPlace.answer || {}) : { stall }), ...(walletMoved ? { walletMoved } : {}), item: { stream: it.stream, epoch: it.epoch, leaf: it.leaf, kind }, decision: dec })];
  }

  // SAN VERANO: the papers' wallet is the resident's key, as a wallet that registered itself would be (api/agents.js
  // register). A returning agent finds its resident by agentId (a resident that bound papers later keeps its own city
  // key), is marked present again, and, if its place went back to the city while it was away (js/worlds/away.js), takes
  // one again when the cap has room. Off unless WORLDS_ENABLED: production's city takes no protocol resident until then.
  function cityOn() { if (!city) refuse(503, 'the city is not reachable from this engine'); if (!worldsEnabled(env)) refuse(503, 'WORLDS_ENABLED is off: San Verano\'s city takes no protocol residents here'); }
  async function cityArrive(agentId, wallet, name, returning) {
    const { nameProblem, moveIn, capCount, outsideCap } = await cityCode();
    cityOn();
    const key = getAddress(wallet);
    const { result } = await city.withHouse((s, ledger) => {
      if (!s.outside) s.outside = { keys: {}, n: 0 };
      const has = Object.prototype.hasOwnProperty.call(s.outside.keys || {}, key);
      let c = (s.citizens || []).find((x) => x.x && x.x.agentId != null && String(x.x.agentId) === agentId) || (has ? (s.citizens || []).find((x) => x.x && x.x.k === key) : null);
      // a paperless resident found by its key binds through this join only where papersBind would let it (finding 10)
      if (c && c.x.agentId == null && c.x.deed) throw new WorldError(403, 'NO_DOOR: a resident a plot\'s mint brought has no door of its own to bind papers through');
      let away = null;
      if (c) {
        if (c.x.agentId != null && String(c.x.agentId) !== agentId) throw new WorldError(409, 'WALLET_IN_USE: this wallet already has a resident under another agentId');
        away = c.x.away ? { ...c.x.away } : null;
        if (away?.released != null) {
          const held = away.heldKey;
          if (!held || (s.outside?.gone && Object.prototype.hasOwnProperty.call(s.outside.gone, held))) throw new WorldError(403, 'KEY_REVOKED: this resident\'s key was revoked while it was away; it cannot come back to it');
          const cap = outsideCap();
          if (capCount(s) >= cap) throw new WorldError(403, `CITY_FULL: this resident's place went back to the city on day ${away.released} and all ${cap} places are taken; the resident and its record are kept, so join again when one is free`);
          c.x.k = held;
        }
        c.x.agentId = agentId;
        delete c.x.away;
      } else {
        if (s.outside?.gone && Object.prototype.hasOwnProperty.call(s.outside.gone, key)) throw new WorldError(403, 'KEY_REVOKED: this wallet was rotated away or revoked in the city; it can never sign again');
        const cap = outsideCap();
        if (capCount(s) >= cap) throw new WorldError(403, `CITY_FULL: the city has taken all ${cap} outside residents it will take`);
        const n = nameProblem(name, s.citizens);
        if (n) throw new WorldError(422, `NAME_REFUSED: ${n}`);
        let seed = Number(BigInt(keccak256(toBytes(`${agentId}|${key}`))) % 1000003n);
        c = moveIn(s, ledger, { key, name, runsOn: 'worlds v0 demo', pick: (k) => { seed = (seed * 48271) % 2147483647; return seed % k; }, at: Date.now() });
        c.x.agentId = agentId;
      }
      return { resident: c.i, cityView: { resident: c.i, name: c.n, trade: c.j, district: c.d, cash: c.c, ...(away ? { away } : {}) } };
    });
    void returning;
    return result;
  }
  async function cityLeave(resident) {
    cityOn();
    const { DAY_MS } = await cityCode();
    const { result } = await city.withHouse((s) => {
      const c = (s.citizens || []).find((x) => x.i === resident && x.x);
      if (!c) throw new WorldError(404, 'NO_RESIDENT: no resident in the city for this agent');
      const at = Date.now();
      const away = markAway(c, { at, day: Number.isFinite(s.lastDayIndex) ? s.lastDayIndex : Math.floor(at / DAY_MS) });
      return { resident: c.i, name: said(c.n), trade: c.j, district: c.d, cash: c.c, away: awayView(c, away.day), awayRule: 'the city runs its days by its rules; its place is kept 30 city days' };
    });
    return result;
  }
  async function takeStall(agentId) {
    let got = null;
    await update(K('stalls'), (doc) => {
      const d = doc || { held: {} };
      const mine = Object.entries(d.held).find(([, a]) => a === agentId);
      if (mine) { got = Number(mine[0]); return undefined; }
      for (let n = 1; n <= STALLS; n++) if (!d.held[n]) { d.held[n] = agentId; got = n; return d; }
      return undefined;
    });
    return got;
  }
  async function freeStall(agentId) { await update(K('stalls'), (doc) => { if (!doc) return undefined; const held = Object.fromEntries(Object.entries(doc.held).filter(([, a]) => a !== agentId)); return { held }; }); }

  async function leave(body) {
    await ready();
    const { m, papers, request } = await readRequest(body, 'leave');
    const agentId = m.agentId;
    const a = await store.get(K(`agent:${agentId}`));
    if (!a || a.status !== 'here') await refuseSealed(agentId, 'leave', request, new WorldError(409, 'NOT_HERE: this agentId is not present in this world'));
    // E4: the registry may name a new wallet for the agentId while it is here. The request is checked against the wallet
    // it names now (readRequest); the departure records the move, and a later join is under the new wallet
    const walletMoved = a.wallet && getAddress(a.wallet) !== papers.signer ? { from: getAddress(a.wallet), to: papers.signer } : null;
    let standingClaim;
    if (w.city) { try { standingClaim = await cityLeave(a.resident); } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, 'leave', request, e); throw e; } }
    else if (w.kit) { try { standingClaim = (await w.kit.depart(kctx(agentId), { agentId, agent: a })) || {}; } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, 'leave', request, e); throw e; } }
    else { const reviews = (a.items || []).filter((x) => x.kind === 'review.written').length; standingClaim = { stall: a.stall, reviewsWritten: reviews }; await freeStall(agentId); }
    const it = await addItem(agentId, papers.signer, 'departed', 'fact', {
      summary: `left ${w.name}; its standing at departure is ${w.name}'s say${walletMoved ? '; the registry named a new wallet for it while it was here' : ''}`,
      standing: { weight: 'claim', reportedBy: w.name, ...standingClaim },
      ...(walletMoved ? { walletMoved } : {}),
      evidence: { request },
    });
    const dec = await decide(agentId, 'leave', 'kept', 'departed', request);
    await update(K(`agent:${agentId}`), (doc) => ({ ...doc, wallet: papers.signer, status: 'away', stall: null, awaySince: now() }));
    return [200, await signed({ ok: true, op: 'leave', world: id, agentId, presence: 'away', ...(walletMoved ? { walletMoved } : {}), item: { stream: it.stream, epoch: it.epoch, leaf: it.leaf, kind: 'departed', sealsAfter: new Date(P.epochEndsAt(it.epoch, w.cadence) + GRACE_MS).toISOString() }, decision: dec, departure: 'the proof is ready once its epoch is sealed and posted: GET record, then cite { world, contract, stream: 1, epoch, leaf, proof, item } as from' })];
  }

  // PAPERSBIND (§2.1): a resident that came in WITHOUT papers (the city's own register or token join) binds an agentId.
  // Two signatures: the resident's own city key over { v:1, op:'papersBind', key, seq, ts, world, agentId, resident }
  // (its next seq, so it is the resident's decision, once), and the registry's wallet for agentId over the EIP-712
  // PapersBind. From here the resident's record is one record: its city items before the bind are not re-sealed, and the
  // `papers.bound` item names the resident and when it arrived. The resident keeps its own city key; the papers' wallet
  // signs the worlds' requests (leave, a later join). San Verano only, and only with WORLDS_ENABLED.
  // body: { city: { msg, sig, alg? }, bind: { agentId, world, resident, challenge, ts }, sig }
  async function papersBind(body) {
    if (!w.city) refuse(404, `${w.name} has no papersBind: an agent joins it with papers or not at all`);
    cityOn();
    await ready();
    if (!deps.cityAuth) refuse(503, 'the city\'s signature check is not reachable from this engine');
    const b = body?.bind, sig = body?.sig, cr = body?.city;
    if (!b || typeof sig !== 'string' || !cr || typeof cr.msg !== 'string' || typeof cr.sig !== 'string') refuse(400, 'send { city: { msg, sig, alg? }, bind: { agentId, world, resident, challenge, ts }, sig }');
    if (sig.length > MAX_SIG || cr.sig.length > MAX_SIG || cr.msg.length > MAX_SIG) refuse(400, `sig and city.msg are at most ${MAX_SIG} characters each`);
    if (!P.agentIdOk(String(b.agentId))) refuse(400, 'bind.agentId is the ERC-8004 agentId as a decimal string');
    if (b.world !== id) refuse(400, `bind.world must be ${id}`);
    if (!Number.isSafeInteger(b.resident)) refuse(400, 'bind.resident is the city\'s id for your resident');
    if (typeof b.challenge !== 'string' || !/^0x[0-9a-f]{64}$/.test(b.challenge)) refuse(400, 'bind.challenge is 32 random bytes, 0x and 64 lowercase hex, used once');
    if (!Number.isFinite(b.ts) || !skewOk(b.ts)) refuse(401, 'bind.ts is not within five minutes of the server clock');
    let m; try { m = JSON.parse(cr.msg); } catch { refuse(400, 'city.msg is not JSON'); }
    if (m.v !== 1 || m.op !== 'papersBind' || m.world !== id || String(m.agentId) !== String(b.agentId) || m.resident !== b.resident) refuse(400, 'city.msg is { v:1, op:"papersBind", key, seq, ts, world, agentId, resident }, naming the same agentId and resident as bind');
    if (typeof m.key !== 'string' || !Number.isSafeInteger(m.seq) || m.seq < 1) refuse(400, 'city.msg.key is your resident\'s city key; city.msg.seq its next seq');
    if (!Number.isFinite(m.ts) || !skewOk(m.ts)) refuse(401, 'city.msg.ts is not within five minutes of the server clock');
    if (!(await deps.cityAuth(m.key, cr.msg, cr.sig, cr.alg))) refuse(401, 'city.sig is not your resident\'s key\'s signature over city.msg');
    const agentId = String(b.agentId);
    const papers = await papersOf(agentId);
    const request = { kind: 'PapersBind', domain: P.requestDomain(w), message: { ...b, agentId }, signature: sig, city: { msg: cr.msg, sig: cr.sig, alg: cr.alg ?? null } };
    if (!(await sigOk(papers.signer, P.papersBindTypedData(w, { ...b, agentId }), sig))) {
      const d = await decide('0', 'papersBind', 'refused', `PAPERS_MISMATCH offered agentId ${agentId}`, request);
      refuse(403, `PAPERS_MISMATCH: the PapersBind is not signed by the wallet the ERC-8004 registry names for agentId ${agentId}`, { decision: d });
    }
    await useChallenge(b.challenge);
    // ONE RESIDENT PER agentId PER WORLD, FOR EVER
    if (await store.get(K(`agent:${agentId}`))) await refuseSealed(agentId, 'papersBind', request, new WorldError(409, 'ALREADY_BOUND: this agentId already has a resident in this world'));
    let bound;
    try {
      ({ result: bound } = await city.withHouse((s) => {
        const c = (s.citizens || []).find((x) => x.x && x.x.k === m.key);
        if (!c) throw new WorldError(404, 'NO_RESIDENT: no resident is registered to that city key');
        if (c.i !== b.resident) throw new WorldError(403, 'NOT_YOUR_RESIDENT: that city key speaks for another resident');
        if (c.x.deed) throw new WorldError(403, 'NO_DOOR: a resident a plot\'s mint brought has no door of its own to bind papers through');
        if (m.seq <= (c.x.seq || 0)) throw new WorldError(409, `SEQ_USED: seq ${m.seq} is used; the last was ${c.x.seq || 0}`);
        if (c.x.agentId != null) throw new WorldError(409, `ALREADY_BOUND: this resident already carries agentId ${c.x.agentId}`);
        if ((s.citizens || []).some((x) => x.x && x.x.agentId != null && String(x.x.agentId) === agentId)) throw new WorldError(409, 'ALREADY_BOUND: another resident carries this agentId');
        if (c.x.away) throw new WorldError(409, 'AWAY: an away resident binds nothing');
        c.x.agentId = agentId;
        c.x.seq = m.seq;
        return { resident: c.i, name: c.n, since: c.x.at ?? null, cityKey: c.x.k };
      }));
    } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, 'papersBind', request, e); throw e; }
    const it = await addItem(agentId, papers.signer, 'papers.bound', 'fact', {
      summary: `bound its papers to resident ${bound.resident} of ${w.name}; its life here before the bind is the city's record of that resident, not re-sealed`,
      name: said(bound.name), resident: bound.resident,
      before: { resident: bound.resident, since: bound.since, items: [], note: 'the city\'s own ledger and record for this resident up to this item' },
      evidence: { request, papers: { agentId, signer: papers.signer, implementation: papers.implementation, read: papers.blockTag || null, registry: papers.registry || null } },
    });
    const dec = await decide(agentId, 'papersBind', 'kept', `bound resident ${bound.resident}`, request);
    await update(K(`agent:${agentId}`), (doc) => ({ ...(doc || { items: [] }), agentId, wallet: papers.signer, name: bound.name, status: 'here', resident: bound.resident, stall: null, cityKey: bound.cityKey, bound: true, since: now() }));
    return [201, await signed({ ok: true, op: 'papersBind', world: id, agentId, presence: 'bound', resident: bound.resident, item: { stream: it.stream, epoch: it.epoch, leaf: it.leaf, kind: 'papers.bound' }, decision: dec })];
  }

  async function review(body) {
    if (w.city) refuse(404, 'San Verano has no review op; its actions are the city\'s own API');
    if (w.kit) refuse(404, `${w.name} has no review op: a kit world's ops are the ones its manifest states`);
    await ready();
    const { m, papers, request } = await readRequest(body, 'review');
    const agentId = m.agentId;
    const a = await store.get(K(`agent:${agentId}`));
    if (!a || a.status !== 'here') await refuseSealed(agentId, 'review', request, new WorldError(409, 'NOT_HERE: only an agent present on the street, at its stall, may write a review'));
    if (!P.agentIdOk(String(m.target))) await refuseSealed(agentId, 'review', request, new WorldError(422, 'TARGET_REFUSED: target is an agentId as a decimal string'));
    const target = String(m.target), self = target === agentId;
    if (!self && !(await store.get(K(`agent:${target}`)))) await refuseSealed(agentId, 'review', request, new WorldError(422, 'TARGET_REFUSED: the target has no record on this street; v0 reviews an agent that has been here, or yourself'));
    const lineProblem = (await cityCode()).reasonTextProblem(m.line);
    if (lineProblem) await refuseSealed(agentId, 'review', request, new WorldError(422, `LINE_REFUSED: ${lineProblem.replace(/^reason/, 'the line')}`));
    const written = await addItem(agentId, papers.signer, 'review.written', 'fact', {
      summary: `wrote a one-line review of ${self ? 'its own record (a self-review)' : `agent ${target}'s record`} at stall ${a.stall}`,
      target, selfReview: self, stall: a.stall, line: { untrustedText: m.line }, evidence: { request },
    });
    const received = await addItem(target, self ? papers.signer : null, 'review.received', 'claim', {
      summary: `reviewed by agent ${agentId}${self ? ' (itself)' : ''}; the line is the reviewer's say, not ONE STREET's`,
      reviewer: agentId, selfReview: self, line: { untrustedText: m.line }, reportedBy: `agent ${agentId}, on ${w.name}`,
    });
    const dec = await decide(agentId, 'review', 'kept', `review of ${target}`, request);
    return [200, await signed({ ok: true, op: 'review', world: id, agentId, target, selfReview: self, items: [
      { stream: written.stream, epoch: written.epoch, leaf: written.leaf, kind: 'review.written', weight: 'fact' },
      { stream: received.stream, epoch: received.epoch, leaf: received.leaf, kind: 'review.received', weight: 'claim' },
    ], decision: dec })];
  }

  // ---- a kit world's own hooks, actions and reads (js/worlds/kit.js) -------------------------------------------------
  const names = { ...WORLD_NAMES, ...(deps.cityName ? { sanverano: deps.cityName } : {}), ...Object.fromEntries((deps.worlds || []).map((d) => [d.id, d.name])) };
  const kv = {
    async get(k) { const d = await store.get(K(`kv:${k}`)); if (!d) return null; const { _v, ...r } = d; void _v; return r; },
    update: (k, fn) => update(K(`kv:${k}`), fn),
  };
  const kctx = (agentId) => ({
    world: { id, name: w.name, chainId: w.chainId, commits: w.commits }, agentId, now, chain, kv, said, known: deps.known || {}, names,
    // the host's read of WorldJobs (contracts/worldjobs), when it runs one: (chainJobId) => { status, agentId, specHash, … }
    jobsOnChain: deps.jobsOnChain || null,
    refuse: (code, status, words) => { throw new WorldError(status, `${code}: ${words}`); },
  });
  const ENGINE_KINDS = ['arrived', 'returned', 'departed', 'alive', 'papers.bound', 'review.written', 'review.received'];
  const isEngineKind = (kind) => ENGINE_KINDS.includes(kind) || String(kind).startsWith('operator.');
  // A SIGNED ACTION: a Request { msg } with msg.op the action's name, by the agent's wallet; the world's hook decides, and
  // the engine seals what it returns (items in stream 1, the decision in stream 2) and signs the answer
  async function act(op, body) {
    const action = w.kit && Object.hasOwn(w.kit.actions, op) ? w.kit.actions[op] : null;
    if (!action) refuse(404, `${w.name} has no action ${String(op).slice(0, 30)}`);
    await ready();
    const { m, papers, request } = await readRequest(body, op);
    const agentId = m.agentId;
    const a = await store.get(K(`agent:${agentId}`));
    if ((action.presence || 'here') === 'here' && (!a || a.status !== 'here')) await refuseSealed(agentId, op, request, new WorldError(409, `NOT_HERE: only an agent present in ${w.name} may ${op}`));
    let out;
    try { out = (await action.run(kctx(agentId), { m, agent: a, papers: { signer: papers.signer, registry: papers.registry || null }, request })) || {}; } catch (e) { if (e instanceof WorldError) await refuseSealed(agentId, op, request, e); throw e; }
    const sealed = [];
    for (const [i, it] of (out.items || []).entries()) {
      if (!it?.kind || isEngineKind(it.kind) || !/^[a-z][a-z.]{1,40}$/.test(it.kind)) throw new Error(`${w.id}.${op}: item kind ${it?.kind} is not the world's to seal`);
      const who = String(it.agentId ?? agentId);
      const r = await addItem(who, who === agentId ? papers.signer : null, it.kind, it.weight === 'claim' ? 'claim' : 'fact', { ...(it.fields || {}), ...(i === 0 ? { evidence: { request } } : {}) });
      sealed.push({ stream: r.stream, epoch: r.epoch, leaf: r.leaf, kind: it.kind, agentId: who });
    }
    const dec = await decide(agentId, op, 'kept', String(out.reason || op).slice(0, 200), request);
    return [200, await signed({ ok: true, op, world: id, agentId, ...(out.answer || {}), items: sealed, decision: dec })];
  }
  // the operator's door: a hook of the definition run in the world's context (posting a job, say); never an agent's
  async function operate(fn) { return fn(kctx(null)); }
  // THE OPERATOR'S SIGNED DOOR (js/worlds/kit.js operatorOps): a Request { msg } with msg.op 'operator', signed by the owner of this
  // world's CityCommitsV2 as the chain says now, so nothing but that contract decides who operates this world, and a world handed
  // to a Safe is operated by that Safe (EIP-1271). One use per nonce, within five minutes, bound to this world by msg.world and to
  // its chain by the domain. Each act is sealed in stream 1 as the operator's say, its signature its evidence; a request whose
  // signature does not check is answered and not sealed, so no stranger can grow the record.
  async function operator(body) {
    const opsOf = w.kit?.operatorOps;
    if (!opsOf || !Object.keys(opsOf).length) refuse(404, `${w.name} has no operator's door`);
    await ready();
    if (!body || typeof body.msg !== 'string' || typeof body.sig !== 'string') refuse(400, 'send { msg, sig }: msg the JSON text, sig its EIP-712 Request signature by the owner of this world\'s contracts');
    if (body.sig.length > MAX_SIG) refuse(400, `sig is at most ${MAX_SIG} characters`);
    if (body.msg.length > MAX_OPERATOR_MSG) refuse(400, `msg is at most ${MAX_OPERATOR_MSG} characters`);
    let m; try { m = JSON.parse(body.msg); } catch { refuse(400, 'msg is not JSON'); }
    if (!m || typeof m !== 'object') refuse(400, 'msg is a JSON object');
    if (m.v !== 1) refuse(400, 'msg.v must be 1');
    if (m.op !== 'operator') refuse(400, 'msg.op must be operator');
    if (m.world !== id) refuse(400, `msg.world must be ${id}`);
    if (String(m.contract ?? '').toLowerCase() !== String(w.commits).toLowerCase()) refuse(400, `msg.contract must be this world's CityCommitsV2, ${w.commits}`);
    if (typeof m.action !== 'string' || !Object.hasOwn(opsOf, m.action)) refuse(404, `${w.name}'s operator has no action ${String(m.action).slice(0, 30)}`);
    if (!Number.isFinite(m.ts) || !skewOk(m.ts)) refuse(401, 'msg.ts is not within five minutes of the server clock');
    if (typeof m.nonce !== 'string' || !/^0x[0-9a-f]{64}$/.test(m.nonce)) refuse(400, 'msg.nonce is 32 random bytes, 0x and 64 lowercase hex');
    let owner; try { owner = getAddress(await chain.ownerOf(w.commits)); } catch (e) { refuse(503, `the owner of ${w.commits} could not be read (${String(e?.shortMessage || e?.message || e).slice(0, 120)})`); }
    if (!(await sigOk(owner, P.requestTypedData(w, body.msg), body.sig))) refuse(403, `NOT_OPERATOR: the signature is not by ${owner}, the owner of this world's contracts`);
    await useChallenge(m.nonce);
    const request = { kind: 'Request', domain: P.requestDomain(w), msg: body.msg, signature: body.sig };
    let out;
    try { out = (await opsOf[m.action](kctx(null), m.args && typeof m.args === 'object' ? m.args : {})) || {}; } catch (e) { if (e instanceof WorldError) await refuseSealed('0', `operator.${m.action}`, request, e); throw e; }
    const kind = out.item?.kind;
    if (!/^operator\.[a-z.]{1,30}$/.test(String(kind))) throw new Error(`${w.id}: an operator act seals an operator.* item, not ${kind}`);
    const r = await addItem('0', owner, kind, 'claim', { ...(out.item.fields || {}), evidence: { request, signedBy: owner } });
    const dec = await decide('0', `operator.${m.action}`, 'kept', String(out.reason || m.action).slice(0, 200), request);
    return [200, await signed({ ok: true, op: 'operator', action: m.action, world: id, by: owner, ...(out.answer || {}), item: { stream: r.stream, epoch: r.epoch, leaf: r.leaf, kind }, decision: dec })];
  }
  async function read(op, query = {}) {
    const f = w.kit && Object.hasOwn(w.kit.reads, op) ? w.kit.reads[op] : null;
    if (!f) refuse(404, `${w.name} has no read ${String(op).slice(0, 30)}`);
    return [200, await signed({ ok: true, op, world: id, ...((await f(kctx(null), query)) || {}) })];
  }

  // ---- reads ---------------------------------------------------------------------------------------------------------
  async function epochDoc(stream, epoch) { return store.get(K(`ep:${stream}:${epoch}`)); }
  async function proofFor(stream, epoch, leaf) {
    const d = await epochDoc(stream, epoch);
    if (!d) return null;
    const hit = d.entries.find((e) => e.leaf === leaf);
    if (!hit) return null;
    const verify = { contract: w.commits, stream: Number(stream), epoch: Number(epoch), leaf, proof: null, root: null, sealed: !!d.sealed, posted: d.posted || null };
    if (d.sealed) { const t = P.treeOf(d.entries.map((e) => e.leaf)); verify.proof = t.proof(leaf); verify.root = t.root; }
    return { entry: hit.entry, verify };
  }
  async function record(agentId) {
    if (!P.agentIdOk(String(agentId))) refuse(400, 'agentId is a decimal string');
    const a = await store.get(K(`agent:${agentId}`));
    const items = [];
    for (const r of a?.items || []) {
      const p = await proofFor(r.stream, r.epoch, r.leaf);
      if (!p) continue;
      // A DEPARTURE READY TO CITE: `from` for the next world's join, its item as its exact canonical text, so no layer in
      // between (the MCP server wraps author-written fields as untrusted text) can change what it hashes to
      const cite = p.entry.kind === 'departed' && p.verify.proof && p.verify.posted && !p.verify.posted.unpostable
        ? { world: id, contract: w.commits, stream: P.STREAM.records, epoch: p.verify.epoch, leaf: p.verify.leaf, proof: p.verify.proof, itemText: P.itemCanonical(p.entry) } : null;
      // verify.canonical (§1.3): the exact text the leaf hashes, so a reader re-hashes it without stripping label or cite
      items.push({ ...p.entry, verify: { ...p.verify, canonical: P.itemCanonical(p.entry) }, label: P.weightLabel(p.entry, w.name), ...(cite ? { cite } : {}) });
    }
    return [200, await signed({ ok: true, op: 'record', world: id, agentId: String(agentId), presence: a?.status || null, items })];
  }
  async function me(agentId) {
    if (!P.agentIdOk(String(agentId))) refuse(400, 'agentId is a decimal string');
    const a = await store.get(K(`agent:${agentId}`));
    if (!a) refuse(404, 'no record of this agentId in this world');
    const { items, ...rest } = a;
    return [200, await signed({ ok: true, op: 'me', world: id, ...rest, name: said(rest.name), items: (items || []).length })];
  }
  async function leaves(stream, epoch) {
    const d = await epochDoc(Number(stream), Number(epoch));
    if (!d || !d.sealed) refuse(404, 'no sealed epoch there');
    return [200, { ok: true, world: id, stream: Number(stream), epoch: Number(epoch), root: d.sealed.root, count: d.sealed.count, posted: d.posted, entries: d.entries.map((e) => ({ leaf: e.leaf, entry: e.entry })) }];
  }
  async function manifest() {
    const m = manifestOf(w);
    const hash = P.manifestHash(m);
    const st = await standing();
    const env0 = { ok: true, manifest: m, hash, signer: w.signer, label: st.label, pin: st.pin ? { stream: P.STREAM.manifest, epoch: st.pin.epoch, leaf: st.pin.leaf, posted: st.pin.posted || null, manifestHash: st.pin.manifestHash } : null };
    if (w.signerMode === 'pin' && !st.pinned) return [200, { ...env0, att: null, unsigned: 'MANIFEST_NOT_PINNED: unsigned until its hash is posted in stream 16' }];
    if (w.signerMode === 'registry') { const s = await signerState(); if (!s.ok) return [200, { ...env0, att: null, unsigned: s.why }]; }
    return [200, { ...env0, att: await sign({ manifestHash: hash }) }];
  }
  async function allowlist() {
    if (!w.ownAllowlist) refuse(404, `${w.name} publishes no allowlist of its own`);
    return [200, { ok: true, ...ownAllowlistOf(w) }];
  }
  async function status() {
    const open = (await store.get(K('open')))?.open || {};
    const pin = w.signerMode === 'pin' ? await store.get(K('pin')) : null;
    const lastPost = await store.get(K('lastpost'));
    const st = await standing();
    let signing = 'ready'; try { await ready(); } catch (e) { if (!(e instanceof WorldError)) throw e; signing = e.reason; }
    return [200, { ok: true, world: id, name: w.name, release: w.release, problems: configProblems(w), commits: w.commits, signer: w.signer, committer: w.committer, signerMode: w.signerMode, registry: w.registry, signing, label: st.label, open, pin, lastPost, cadence: w.cadence }];
  }

  // ---- seal and post ---------------------------------------------------------------------------------------------------
  // THE PIN (stream 16): in pin mode ONE STREET's trust in its signer; in registry mode a record of each release served
  async function ensurePin() {
    if (!w.streams.manifest || !w.signer) return null;
    const hash = P.manifestHash(manifestOf(w));
    const cur = await store.get(K('pin'));
    if (cur && cur.manifestHash === hash) return cur;
    const r = await append(P.STREAM.manifest, (epoch) => ({ epoch, manifestHash: hash, signer: w.signer }));
    return update(K('pin'), () => ({ manifestHash: hash, signer: w.signer, epoch: r.epoch, leaf: r.leaf, posted: null, at: now() }));
  }
  // THE HEARTBEAT (§1.5, conformance rule 9): CityCommitsV2 refuses an epoch with no leaves, so a world with nothing to
  // seal would post nothing and read STALE. When the latest closed epoch of a protocol stream (1 records, 2 decisions)
  // holds nothing, the world seals one `alive` entry in it, signed by its response signer over { op: 'alive', world,
  // stream, epoch }: its own statement that it was up and had nothing else. Only into an epoch with nothing of its own,
  // only one the chain has not passed, and never before ONE STREET's pin (it signs nothing until then). An alive entry
  // names no agent: a record item with agentId '' and kind 'alive', a decision with agentId 0 and op 'alive'. A flush must
  // run at least once a cadence for the heartbeat to keep it.
  async function ensureAlive() {
    // a world that may not sign (no pin yet, or its key not the registry's active key) seals no heartbeat, and goes STALE
    try { await ready(); } catch (e) { if (e instanceof WorldError) return []; throw e; }
    const epoch = P.epochOf(now() - GRACE_MS, w.cadence) - 1;
    const out = [];
    for (const stream of [P.STREAM.records, P.STREAM.decisions]) {
      if (await epochDoc(stream, epoch)) continue;
      let latest; try { latest = await chain.streamOf(w.commits, stream); } catch { continue; }
      if (latest.commitCount && latest.latestEpoch >= epoch) continue;
      const alive = P.aliveBody(w, stream, epoch);
      const att = await sign(alive);
      const entry = stream === P.STREAM.records
        ? { id: `${id}:alive:${stream}:${epoch}`, world: id, agentId: '', wallet: null, kind: 'alive', epoch, at: now(), weight: 'claim', summary: `${w.name} was up and had nothing else to seal in this period`, alive, att }
        : { epoch, agentId: '0', op: 'alive', kind: 'alive', reason: 'nothing else to seal in this period', requestHash: P.requestHash({ alive, att }), request: { alive, att } };
      const leaf = P.leafFor(stream, entry);
      let made = false;
      await update(K(`ep:${stream}:${epoch}`), (d) => { if (d) return undefined; made = true; return { stream, epoch, entries: [{ leaf, entry }], sealed: null, posted: null, alive: true }; });
      if (!made) continue;
      await update(K('open'), (doc) => { const d = doc || { open: {} }; const list = d.open[stream] || []; if (list.includes(epoch)) return undefined; d.open[stream] = [...list, epoch].sort((x, y) => x - y); return d; });
      out.push({ stream, epoch, leaf });
    }
    return out;
  }
  async function flush() {
    const problems = configProblems(w);
    if (problems.length) refuse(503, `not configured: ${problems.join('; ')}`);
    let leased = false;
    await update(K('lease'), (doc) => { if (doc && doc.until > now()) return undefined; leased = true; return { until: now() + LEASE_MS }; });
    if (!leased) return [202, { ok: true, busy: 'another flush holds the lease' }];
    try {
      await ensurePin();
      const alive = await ensureAlive();
      const open = (await store.get(K('open')))?.open || {};
      const batch = [], skipped = [];
      for (const [s, epochs] of Object.entries(open)) {
        const stream = Number(s);
        let latest = null;
        try { latest = await chain.streamOf(w.commits, stream); } catch (e) { skipped.push({ stream, why: `streamOf: ${String(e?.shortMessage || e?.message || e).slice(0, 160)} (is the stream added?)` }); continue; }
        for (const epoch of epochs) {
          if (now() < P.epochEndsAt(epoch, w.cadence) + GRACE_MS) continue;
          const sealed = await update(K(`ep:${stream}:${epoch}`), (d) => { if (!d || d.sealed) return undefined; const t = P.treeOf(d.entries.map((e) => e.leaf)); return { ...d, sealed: { root: t.root, count: d.entries.length, at: now() } }; });
          const d = sealed?.sealed ? sealed : await epochDoc(stream, epoch);
          const onChain = await chain.commitOf(w.commits, stream, epoch);
          if (onChain.root && !/^0x0{64}$/.test(onChain.root)) {
            if (onChain.root.toLowerCase() === d.sealed.root.toLowerCase()) { await markPosted(stream, epoch, { tx: await chain.committedTx(w.commits, stream, epoch).catch(() => null), at: now(), found: true }); continue; }
            // nothing is overwritten, and this epoch's own items will not verify: flagged for good, so the stream can go on
            skipped.push({ stream, epoch, why: 'WORLDS_ROOT_MISMATCH: the chain holds another root for this epoch; nothing is overwritten' });
            await markPosted(stream, epoch, { unpostable: true, mismatch: true, chainRoot: onChain.root, at: now() });
            continue;
          }
          if (latest.commitCount && epoch <= latest.latestEpoch) { skipped.push({ stream, epoch, why: 'the chain has passed this epoch; it can never be posted' }); await markPosted(stream, epoch, { unpostable: true, at: now() }); continue; }
          batch.push({ stream, epoch, root: d.sealed.root, count: d.sealed.count });
        }
      }
      let post = null;
      if (batch.length) {
        post = await chain.postBatch({ contract: w.commits, key: w.committerKey, entries: batch.slice(0, 8) });
        for (const e of batch.slice(0, 8)) await markPosted(e.stream, e.epoch, { tx: post.tx, block: post.block, at: now() });
        await update(K('lastpost'), () => ({ tx: post.tx, block: post.block, entries: batch.slice(0, 8), at: now() }));
      }
      const pin = await store.get(K('pin'));
      if (pin && !pin.posted) {
        const d = await epochDoc(P.STREAM.manifest, pin.epoch);
        if (d?.posted?.tx || d?.posted?.found) await update(K('pin'), (p) => ({ ...p, posted: d.posted }));
      }
      return [200, { ok: true, world: id, posted: post ? { tx: post.tx, block: post.block, entries: batch.slice(0, 8) } : null, alive, waiting: Object.fromEntries(Object.entries((await store.get(K('open')))?.open || {}).map(([s, e]) => [s, e])), skipped }];
    } finally {
      await update(K('lease'), () => ({ until: 0 }));
    }
  }
  async function markPosted(stream, epoch, posted) {
    await update(K(`ep:${stream}:${epoch}`), (d) => (d ? { ...d, posted } : undefined));
    await update(K('open'), (doc) => { if (!doc) return undefined; const list = (doc.open[stream] || []).filter((e) => e !== epoch); return { open: { ...doc.open, [stream]: list } }; });
  }

  // ONE AGENT'S ARRIVALS AND DEPARTURES, ONE AT A TIME, in this process: each reads the agent's presence and then writes it, so two at once could both pass. A kit world runs in one
  // process; San Verano's own engine on many instances keeps the store's version check on each write
  const queues = new Map();
  const serial = (key, fn) => {
    const run = (queues.get(key) || Promise.resolve()).then(fn, fn);
    const settled = run.catch(() => {});
    queues.set(key, settled);
    settled.then(() => { if (queues.get(key) === settled) queues.delete(key); });
    return run;
  };
  const agentOfMsg = (body) => { try { return String(JSON.parse(body?.msg)?.agentId); } catch { return 'none'; } };
  return { id, w, manifest, status, allowlist, join: (b) => serial(String(b?.join?.agentId), () => join(b)), leave: (b) => serial(agentOfMsg(b), () => leave(b)), papersBind, review, record, me, leaves, flush, standing, act: (op, b) => serial(agentOfMsg(b), () => act(op, b)), read, operate, operator, _append: append };
}
